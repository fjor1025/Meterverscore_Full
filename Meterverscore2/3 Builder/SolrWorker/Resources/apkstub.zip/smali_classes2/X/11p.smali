.class public final LX/11p;
.super LX/0V7;
.source ""


# instance fields
.field public final A00:LX/0Y8;

.field public final A01:LX/08S;

.field public final A02:LX/3J5;

.field public final A03:LX/2sJ;

.field public final A04:LX/2au;

.field public final A05:LX/1ZI;

.field public final A06:LX/454;


# direct methods
.method public constructor <init>(LX/3J5;LX/2sJ;LX/2au;LX/1ZI;LX/454;)V
    .locals 1

    invoke-static {p2, p5, p1, p3}, LX/0yK;->A0f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-direct {p0}, LX/0V7;-><init>()V

    iput-object p4, p0, LX/11p;->A05:LX/1ZI;

    iput-object p2, p0, LX/11p;->A03:LX/2sJ;

    iput-object p5, p0, LX/11p;->A06:LX/454;

    iput-object p1, p0, LX/11p;->A02:LX/3J5;

    iput-object p3, p0, LX/11p;->A04:LX/2au;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/11p;->A01:LX/08S;

    iput-object v0, p0, LX/11p;->A00:LX/0Y8;

    const/16 v0, 0x23

    invoke-static {p5, p0, v0}, LX/3fE;->A00(LX/454;Ljava/lang/Object;I)V

    return-void
.end method
