.class public final LX/11o;
.super LX/0V7;
.source ""


# instance fields
.field public final A00:LX/08S;

.field public final A01:LX/08S;

.field public final A02:LX/3J5;

.field public final A03:LX/1ZI;

.field public final A04:LX/4LC;

.field public final A05:LX/454;


# direct methods
.method public constructor <init>(LX/3J5;LX/1ZI;LX/454;)V
    .locals 2

    invoke-static {p2, p3, p1}, LX/0yK;->A0Y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-direct {p0}, LX/0V7;-><init>()V

    iput-object p2, p0, LX/11o;->A03:LX/1ZI;

    iput-object p3, p0, LX/11o;->A05:LX/454;

    iput-object p1, p0, LX/11o;->A02:LX/3J5;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/11o;->A00:LX/08S;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/11o;->A01:LX/08S;

    invoke-static {}, LX/0yU;->A0H()LX/4LC;

    move-result-object v0

    iput-object v0, p0, LX/11o;->A04:LX/4LC;

    iget-object v1, p0, LX/11o;->A05:LX/454;

    const/4 v0, 0x3

    invoke-static {v1, p0, v0}, LX/3hS;->A00(LX/454;Ljava/lang/Object;I)V

    return-void
.end method
