.class public abstract LX/11F;
.super Landroidx/constraintlayout/widget/ConstraintLayout;
.source ""

# interfaces
.implements LX/468;


# instance fields
.field public A00:LX/5p7;

.field public A01:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    invoke-direct {p0, p1, p2}, Landroidx/constraintlayout/widget/ConstraintLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    iget-boolean v0, p0, LX/11F;->A01:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p0, LX/11F;->A01:Z

    invoke-virtual {p0}, LX/11F;->generatedComponent()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/5jV;

    move-object v1, p0

    check-cast v1, Lcom/gbwhatsapp/settings/SettingsRowBanner;

    check-cast v0, LX/4UR;

    iget-object v0, v0, LX/4UR;->A0J:LX/3GZ;

    invoke-static {v0}, LX/3GZ;->A2s(LX/3GZ;)LX/34x;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/settings/SettingsRowBanner;->A00:LX/34x;

    :cond_0
    return-void
.end method


# virtual methods
.method public final generatedComponent()Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, LX/11F;->A00:LX/5p7;

    if-nez v0, :cond_0

    new-instance v0, LX/5p7;

    invoke-direct {v0, p0}, LX/5p7;-><init>(Landroid/view/View;)V

    iput-object v0, p0, LX/11F;->A00:LX/5p7;

    :cond_0
    invoke-virtual {v0}, LX/5p7;->generatedComponent()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method
