.class public LX/11T;
.super LX/08e;
.source ""


# instance fields
.field public final synthetic A00:Landroid/content/Intent;

.field public final synthetic A01:LX/26T;

.field public final synthetic A02:Lcom/gbwhatsapp/conversation/conversationrow/MessageSelectionViewModel;

.field public final synthetic A03:LX/3ep;

.field public final synthetic A04:LX/1ZJ;

.field public final synthetic A05:LX/6Dn;


# direct methods
.method public constructor <init>(Landroid/content/Intent;LX/0wY;LX/26T;Lcom/gbwhatsapp/conversation/conversationrow/MessageSelectionViewModel;LX/3ep;LX/1ZJ;LX/6Dn;)V
    .locals 1

    const/4 v0, 0x0

    iput-object p3, p0, LX/11T;->A01:LX/26T;

    iput-object p7, p0, LX/11T;->A05:LX/6Dn;

    iput-object p6, p0, LX/11T;->A04:LX/1ZJ;

    iput-object p5, p0, LX/11T;->A03:LX/3ep;

    iput-object p1, p0, LX/11T;->A00:Landroid/content/Intent;

    iput-object p4, p0, LX/11T;->A02:Lcom/gbwhatsapp/conversation/conversationrow/MessageSelectionViewModel;

    invoke-direct {p0, v0, p2}, LX/08e;-><init>(Landroid/os/Bundle;LX/0wY;)V

    return-void
.end method


# virtual methods
.method public A02(LX/0Yd;Ljava/lang/Class;Ljava/lang/String;)LX/0V7;
    .locals 49

    move-object/from16 v2, p0

    iget-object v1, v2, LX/11T;->A01:LX/26T;

    iget-object v0, v2, LX/11T;->A05:LX/6Dn;

    move-object/from16 v26, v0

    iget-object v0, v2, LX/11T;->A04:LX/1ZJ;

    move-object/from16 v23, v0

    iget-object v0, v2, LX/11T;->A03:LX/3ep;

    move-object/from16 v21, v0

    iget-object v0, v2, LX/11T;->A00:Landroid/content/Intent;

    move-object/from16 v20, v0

    iget-object v0, v2, LX/11T;->A02:Lcom/gbwhatsapp/conversation/conversationrow/MessageSelectionViewModel;

    move-object/from16 v22, v0

    iget-object v1, v1, LX/26T;->A00:LX/5qP;

    iget-object v0, v1, LX/5qP;->A01:LX/4UO;

    move-object/from16 v48, v0

    iget-object v0, v1, LX/5qP;->A03:LX/3GZ;

    invoke-static {v0}, LX/3GZ;->A44(LX/3GZ;)LX/1Pl;

    move-result-object v37

    iget-object v1, v0, LX/3GZ;->AVx:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, LX/2rp;

    invoke-static {v0}, LX/3GZ;->A3B(LX/3GZ;)LX/3Qa;

    move-result-object v28

    invoke-static {v0}, LX/3GZ;->A85(LX/3GZ;)LX/2pv;

    move-result-object v42

    invoke-static {v0}, LX/3GZ;->A8i(LX/3GZ;)LX/454;

    move-result-object v44

    invoke-static {v0}, LX/3GZ;->A38(LX/3GZ;)LX/2ss;

    move-result-object v27

    iget-object v1, v0, LX/3GZ;->ATp:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, LX/2rr;

    invoke-static {v0}, LX/3GZ;->A2s(LX/3GZ;)LX/34x;

    move-result-object v25

    iget-object v1, v0, LX/3GZ;->A4v:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, LX/2WJ;

    invoke-static {v0}, LX/3GZ;->A04(LX/3GZ;)LX/2sr;

    move-result-object v18

    iget-object v1, v0, LX/3GZ;->ANL:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, LX/2rb;

    invoke-virtual {v0}, LX/3GZ;->AoZ()LX/2dh;

    move-result-object v40

    iget-object v1, v0, LX/3GZ;->AKE:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, LX/2pO;

    iget-object v1, v0, LX/3GZ;->A6t:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, LX/2A9;

    iget-object v1, v0, LX/3GZ;->A8K:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LX/2rQ;

    iget-object v1, v0, LX/3GZ;->A00:LX/38w;

    iget-object v2, v1, LX/38w;->A4A:LX/41P;

    invoke-interface {v2}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, LX/5Rk;

    iget-object v2, v1, LX/38w;->A2r:LX/41P;

    invoke-interface {v2}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LX/2A8;

    iget-object v2, v0, LX/3GZ;->ABC:LX/41P;

    invoke-interface {v2}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LX/36j;

    iget-object v2, v0, LX/3GZ;->AJV:LX/41P;

    invoke-interface {v2}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LX/1lZ;

    invoke-static {v0}, LX/3GZ;->A2l(LX/3GZ;)LX/2sJ;

    move-result-object v24

    iget-object v1, v1, LX/38w;->A7X:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LX/5Qr;

    iget-object v1, v0, LX/3GZ;->A96:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LX/2g3;

    iget-object v1, v0, LX/3GZ;->A9A:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LX/2pN;

    invoke-static {v0}, LX/3GZ;->A3H(LX/3GZ;)LX/1cx;

    move-result-object v31

    iget-object v4, v0, LX/3GZ;->A38:LX/41P;

    invoke-interface {v4}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, LX/5pD;->A02(Ljava/lang/Object;)LX/5pD;

    move-result-object v17

    iget-object v4, v0, LX/3GZ;->A4t:LX/41P;

    invoke-static {v4}, LX/3jM;->A00(LX/41P;)LX/8oO;

    move-result-object v47

    invoke-virtual {v0}, LX/3GZ;->Agk()LX/7Xb;

    move-result-object v19

    new-instance v0, LX/4Mb;

    move-object/from16 v16, p1

    move-object/from16 v29, v2

    move-object/from16 v30, v1

    move-object/from16 v32, v14

    move-object/from16 v33, v15

    move-object/from16 v34, v21

    move-object/from16 v35, v11

    move-object/from16 v36, v9

    move-object/from16 v38, v23

    move-object/from16 v39, v12

    move-object/from16 v41, v6

    move-object/from16 v43, v5

    move-object/from16 v45, v8

    move-object/from16 v46, v26

    move-object v14, v0

    move-object/from16 v15, v20

    move-object/from16 v20, v7

    move-object/from16 v21, v10

    move-object/from16 v23, v3

    move-object/from16 v26, v13

    invoke-direct/range {v14 .. v47}, LX/4Mb;-><init>(Landroid/content/Intent;LX/0Yd;LX/5pD;LX/2sr;LX/7Xb;LX/2A8;LX/2A9;Lcom/gbwhatsapp/conversation/conversationrow/MessageSelectionViewModel;LX/5Qr;LX/2sJ;LX/34x;LX/2WJ;LX/2ss;LX/3Qa;LX/2g3;LX/2pN;LX/1cx;LX/2rr;LX/2rp;LX/3ep;LX/2pO;LX/2rQ;LX/1Pl;LX/1ZJ;LX/2rb;LX/2dh;LX/36j;LX/2pv;LX/1lZ;LX/454;LX/5Rk;LX/6Dn;LX/8oO;)V

    move-object/from16 v1, v48

    invoke-virtual {v1, v0}, LX/4UO;->AEZ(LX/4Mb;)V

    return-object v0
.end method
