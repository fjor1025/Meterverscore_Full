.class public LX/11e;
.super LX/0V7;
.source ""


# instance fields
.field public A00:LX/1ZI;

.field public final A01:LX/08S;

.field public final A02:LX/2so;


# direct methods
.method public constructor <init>(LX/2so;)V
    .locals 1

    invoke-direct {p0}, LX/0V7;-><init>()V

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/11e;->A01:LX/08S;

    iput-object p1, p0, LX/11e;->A02:LX/2so;

    return-void
.end method
