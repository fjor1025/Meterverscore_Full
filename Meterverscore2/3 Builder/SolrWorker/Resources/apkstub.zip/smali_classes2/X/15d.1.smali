.class public abstract LX/15d;
.super LX/7Of;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LX/7Of;-><init>()V

    return-void
.end method
