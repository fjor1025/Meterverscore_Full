.class public final LX/15j;
.super LX/6gn;
.source ""

# interfaces
.implements LX/8mP;


# direct methods
.method public constructor <init>()V
    .locals 1

    sget-object v0, LX/1Co;->DEFAULT_INSTANCE:LX/1Co;

    invoke-direct {p0, v0}, LX/6gn;-><init>(LX/6gE;)V

    return-void
.end method
