.class public LX/15R;
.super LX/2uw;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LX/2uw;-><init>()V

    return-void
.end method
