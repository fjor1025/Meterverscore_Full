.class public abstract LX/0ye;
.super Landroid/app/Service;
.source ""


# instance fields
.field public A00:LX/3xU;

.field public A01:LX/34x;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public attachBaseContext(Landroid/content/Context;)V
    .locals 3

    const-class v0, Lcom/gbwhatsapp/android/di/BaseEntryPoint;

    invoke-static {p1, v0}, LX/245;->A02(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/gbwhatsapp/android/di/BaseEntryPoint;

    invoke-interface {v1}, Lcom/gbwhatsapp/android/di/BaseEntryPoint;->Bql()LX/34x;

    move-result-object v0

    iput-object v0, p0, LX/0ye;->A01:LX/34x;

    check-cast v1, LX/3GZ;

    iget-object v0, v1, LX/3GZ;->Ac2:LX/3GZ;

    iget-object v0, v0, LX/3GZ;->A00:LX/38w;

    iget-object v0, v0, LX/38w;->ACR:LX/3GZ;

    invoke-static {v0}, LX/3GZ;->A2t(LX/3GZ;)LX/34x;

    move-result-object v0

    new-instance v2, LX/3Fx;

    invoke-direct {v2, v0}, LX/3Fx;-><init>(LX/34x;)V

    iput-object v2, p0, LX/0ye;->A00:LX/3xU;

    iget-object v1, p0, LX/0ye;->A01:LX/34x;

    new-instance v0, LX/0za;

    invoke-direct {v0, p1, v2, v1}, LX/0za;-><init>(Landroid/content/Context;LX/3xU;LX/34x;)V

    invoke-super {p0, v0}, Landroid/app/Service;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method
