.class public LX/15K;
.super LX/30n;
.source ""


# instance fields
.field public final synthetic A00:LX/30f;

.field public final synthetic A01:Ljava/util/Map;


# direct methods
.method public constructor <init>(LX/30f;LX/7SB;Ljava/util/Map;Ljava/util/Map;)V
    .locals 0

    iput-object p1, p0, LX/15K;->A00:LX/30f;

    iput-object p4, p0, LX/15K;->A01:Ljava/util/Map;

    invoke-direct {p0, p2, p3}, LX/30n;-><init>(LX/7SB;Ljava/util/Map;)V

    return-void
.end method
