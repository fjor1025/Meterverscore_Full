.class public LX/102;
.super Landroid/os/Handler;
.source ""


# instance fields
.field public final synthetic A00:Lcom/gbwhatsapp/authentication/VerifyTwoFactorAuthCodeDialogFragment;


# direct methods
.method public constructor <init>(Landroid/os/Looper;Lcom/gbwhatsapp/authentication/VerifyTwoFactorAuthCodeDialogFragment;)V
    .locals 0

    iput-object p2, p0, LX/102;->A00:Lcom/gbwhatsapp/authentication/VerifyTwoFactorAuthCodeDialogFragment;

    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 4

    iget v0, p1, Landroid/os/Message;->what:I

    if-nez v0, :cond_0

    iget-object v3, p0, LX/102;->A00:Lcom/gbwhatsapp/authentication/VerifyTwoFactorAuthCodeDialogFragment;

    iget v0, v3, Lcom/gbwhatsapp/authentication/VerifyTwoFactorAuthCodeDialogFragment;->A00:I

    if-nez v0, :cond_0

    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-object v1, v3, Lcom/gbwhatsapp/authentication/VerifyTwoFactorAuthCodeDialogFragment;->A07:LX/454;

    const/4 v0, 0x6

    invoke-static {v3, v2, v0}, LX/3hW;->A00(Ljava/lang/Object;Ljava/lang/String;I)LX/3hW;

    move-result-object v0

    invoke-interface {v1, v0}, LX/454;->Bit(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method
