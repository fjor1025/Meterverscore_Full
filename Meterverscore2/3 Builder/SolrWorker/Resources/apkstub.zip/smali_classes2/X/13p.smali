.class public final LX/13p;
.super LX/9HK;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LX/9HK;-><init>()V

    return-void
.end method
