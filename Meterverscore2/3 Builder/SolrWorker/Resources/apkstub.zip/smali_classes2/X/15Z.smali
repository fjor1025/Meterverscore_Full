.class public final LX/15Z;
.super LX/15d;
.source ""


# instance fields
.field public final synthetic A00:LX/31h;


# direct methods
.method public constructor <init>(LX/31h;)V
    .locals 0

    iput-object p1, p0, LX/15Z;->A00:LX/31h;

    invoke-direct {p0}, LX/15d;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic A00(Ljava/lang/Object;I)V
    .locals 3

    iget-object v2, p0, LX/15Z;->A00:LX/31h;

    iget-object v0, v2, LX/31h;->A0C:LX/8oO;

    invoke-static {v0}, LX/0yP;->A0X(LX/8oO;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LX/302;

    const-string/jumbo v0, "status_fragment"

    invoke-virtual {v1, v0}, LX/302;->A02(Ljava/lang/String;)V

    iget-object v0, v2, LX/31h;->A0J:LX/8oO;

    invoke-static {v0}, LX/0yR;->A0e(LX/8oO;)LX/5hQ;

    move-result-object v2

    const-string v1, "SEE_CROSSPOST_ERROR"

    const-string v0, "Error code: -1, error subcode: null"

    invoke-virtual {v2, v1, v0}, LX/5hQ;->A06(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
