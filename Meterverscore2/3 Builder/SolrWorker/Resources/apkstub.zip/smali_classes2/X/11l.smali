.class public final LX/11l;
.super LX/0V7;
.source ""


# instance fields
.field public final A00:LX/08S;

.field public final A01:LX/3J5;

.field public final A02:LX/2kp;

.field public final A03:LX/1ZI;

.field public final A04:LX/454;


# direct methods
.method public constructor <init>(LX/3J5;LX/2kp;LX/1ZI;LX/454;)V
    .locals 2

    const/4 v0, 0x2

    invoke-static {p4, p1, p2, v0}, LX/0yK;->A0b(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-direct {p0}, LX/0V7;-><init>()V

    iput-object p3, p0, LX/11l;->A03:LX/1ZI;

    iput-object p4, p0, LX/11l;->A04:LX/454;

    iput-object p1, p0, LX/11l;->A01:LX/3J5;

    iput-object p2, p0, LX/11l;->A02:LX/2kp;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/11l;->A00:LX/08S;

    iget-object v1, p0, LX/11l;->A04:LX/454;

    const/16 v0, 0x28

    invoke-static {v1, p0, v0}, LX/3fE;->A00(LX/454;Ljava/lang/Object;I)V

    return-void
.end method
