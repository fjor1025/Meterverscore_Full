.class public LX/12w;
.super LX/0Ve;
.source ""


# instance fields
.field public final A00:Landroid/widget/ImageView;

.field public final A01:Landroid/widget/TextView;

.field public final A02:Landroid/widget/TextView;

.field public final A03:Lcom/gbwhatsapp/TextEmojiLabel;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 1

    invoke-direct {p0, p1}, LX/0Ve;-><init>(Landroid/view/View;)V

    const v0, 0x7f0b158c

    invoke-static {p1, v0}, LX/0yQ;->A0O(Landroid/view/View;I)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, LX/12w;->A01:Landroid/widget/TextView;

    const v0, 0x7f0b158a

    invoke-static {p1, v0}, LX/0yR;->A0Q(Landroid/view/View;I)Lcom/gbwhatsapp/TextEmojiLabel;

    move-result-object v0

    iput-object v0, p0, LX/12w;->A03:Lcom/gbwhatsapp/TextEmojiLabel;

    const v0, 0x7f0b158d

    invoke-static {p1, v0}, LX/0yQ;->A0O(Landroid/view/View;I)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, LX/12w;->A02:Landroid/widget/TextView;

    const v0, 0x7f0b1585

    invoke-static {p1, v0}, LX/0yU;->A05(Landroid/view/View;I)Landroid/widget/ImageView;

    move-result-object v0

    iput-object v0, p0, LX/12w;->A00:Landroid/widget/ImageView;

    return-void
.end method
