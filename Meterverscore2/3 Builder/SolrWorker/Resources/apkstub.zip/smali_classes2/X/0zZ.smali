.class public abstract LX/0zZ;
.super Landroid/content/ContentProvider;
.source ""


# instance fields
.field public A00:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    return-void
.end method

.method public static A00(Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;)LX/31X;
    .locals 0

    invoke-virtual {p0}, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A08()LX/8oO;

    move-result-object p0

    invoke-interface {p0}, LX/8oO;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LX/31X;

    return-object p0
.end method

.method public static A01(LX/41P;)LX/8oO;
    .locals 2

    const/4 v1, 0x0

    invoke-static {p0}, LX/3jM;->A00(LX/41P;)LX/8oO;

    move-result-object v0

    invoke-static {v0, v1}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    return-object v0
.end method


# virtual methods
.method public declared-synchronized A07()V
    .locals 11

    monitor-enter p0

    :try_start_0
    iget-boolean v0, p0, LX/0zZ;->A00:Z

    if-nez v0, :cond_c

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "WaBaseContentProvider/ensureInitialized called for "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, LX/0yO;->A0k(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    invoke-static {}, LX/32b;->A02()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, LX/38Z;->A00()V

    sget-object v0, LX/38Z;->A00:Landroid/os/ConditionVariable;

    invoke-virtual {v0}, Landroid/os/ConditionVariable;->block()V

    :cond_0
    move-object v1, p0

    instance-of v0, p0, Lcom/whatsapp/stickers/storage/WhitelistPackQueryContentProvider;

    if-eqz v0, :cond_1

    check-cast v1, Lcom/whatsapp/stickers/storage/WhitelistPackQueryContentProvider;

    invoke-virtual {v1}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, LX/245;->A00(Landroid/content/Context;)LX/3GZ;

    move-result-object v0

    iget-object v0, v0, LX/3GZ;->AYK:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2zG;

    iput-object v0, v1, Lcom/whatsapp/stickers/storage/WhitelistPackQueryContentProvider;->A01:LX/2zG;

    :goto_0
    const/4 v0, 0x1

    iput-boolean v0, p0, LX/0zZ;->A00:Z

    goto/16 :goto_1

    :cond_1
    instance-of v0, p0, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;

    if-eqz v0, :cond_2

    check-cast v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;

    invoke-virtual {v1}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, LX/245;->A01(Landroid/content/Context;)LX/3GZ;

    move-result-object v2

    invoke-static {v2}, LX/3GZ;->A04(LX/3GZ;)LX/2sr;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A01:LX/2sr;

    invoke-static {v2}, LX/3GZ;->A02(LX/3GZ;)LX/3HW;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A00:LX/3HW;

    iget-object v0, v2, LX/3GZ;->AUO:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/3RL;

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A02:LX/3RL;

    iget-object v0, v2, LX/3GZ;->A9m:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/31l;

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A06:LX/31l;

    iget-object v0, v2, LX/3GZ;->A1t:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/0No;

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A03:LX/0No;

    iget-object v0, v2, LX/3GZ;->A8m:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/0XV;

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A05:LX/0XV;

    iget-object v0, v2, LX/3GZ;->Ac2:LX/3GZ;

    iget-object v0, v0, LX/3GZ;->A00:LX/38w;

    iget-object v0, v0, LX/38w;->ACB:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/36v;

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A0B:LX/36v;

    iget-object v0, v2, LX/3GZ;->A53:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/1Mu;

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A0A:LX/1Mu;

    invoke-static {v2}, LX/3GZ;->A2q(LX/3GZ;)LX/354;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A08:LX/354;

    invoke-static {v2}, LX/3GZ;->A2p(LX/3GZ;)LX/34r;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A07:LX/34r;

    iget-object v0, v2, LX/3GZ;->A8l:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/0S0;

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A04:LX/0S0;

    iget-object v0, v2, LX/3GZ;->AWg:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/1Ms;

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A0C:LX/1Ms;

    iget-object v0, v2, LX/3GZ;->AaU:LX/41P;

    invoke-static {v0}, LX/3jM;->A00(LX/41P;)LX/8oO;

    move-result-object v0

    invoke-interface {v0}, LX/8oO;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2oI;

    iput-object v0, v1, Lcom/gbwhatsapp/registration/directmigration/MigrationContentProvider;->A09:LX/2oI;

    goto/16 :goto_0

    :cond_2
    instance-of v0, p0, Lcom/gbwhatsapp/registration/autoconf/LoginStatusContentProvider;

    if-eqz v0, :cond_3

    check-cast v1, Lcom/gbwhatsapp/registration/autoconf/LoginStatusContentProvider;

    invoke-virtual {v1}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_7

    invoke-static {v0}, LX/245;->A01(Landroid/content/Context;)LX/3GZ;

    move-result-object v3

    invoke-virtual {v3}, LX/3GZ;->Auu()LX/1Pl;

    move-result-object v0

    const/4 v2, 0x0

    invoke-static {v0, v2}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/registration/autoconf/LoginStatusContentProvider;->A03:LX/1Pl;

    invoke-static {v3}, LX/3GZ;->A04(LX/3GZ;)LX/2sr;

    move-result-object v0

    invoke-static {v0, v2}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/registration/autoconf/LoginStatusContentProvider;->A00:LX/2sr;

    invoke-static {v3}, LX/3GZ;->A2m(LX/3GZ;)LX/2iX;

    move-result-object v0

    invoke-static {v0, v2}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/registration/autoconf/LoginStatusContentProvider;->A01:LX/2iX;

    invoke-static {v3}, LX/3GZ;->A2q(LX/3GZ;)LX/354;

    move-result-object v0

    invoke-static {v0, v2}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/registration/autoconf/LoginStatusContentProvider;->A02:LX/354;

    goto/16 :goto_0

    :cond_3
    instance-of v0, p0, Lcom/gbwhatsapp/migration/export/api/ExportMigrationContentProvider;

    if-eqz v0, :cond_4

    check-cast v1, Lcom/gbwhatsapp/migration/export/api/ExportMigrationContentProvider;

    invoke-virtual {v1}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_8

    invoke-static {v0}, LX/245;->A01(Landroid/content/Context;)LX/3GZ;

    move-result-object v2

    invoke-virtual {v2}, LX/3GZ;->Auu()LX/1Pl;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/migration/export/api/ExportMigrationContentProvider;->A02:LX/1Pl;

    invoke-static {v2}, LX/3GZ;->A00(LX/3GZ;)LX/2qa;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/migration/export/api/ExportMigrationContentProvider;->A01:LX/2qa;

    iget-object v0, v2, LX/3GZ;->Ac2:LX/3GZ;

    iget-object v3, v0, LX/3GZ;->A00:LX/38w;

    iget-object v0, v3, LX/38w;->A4C:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/1o2;

    iput-object v0, v1, Lcom/gbwhatsapp/migration/export/api/ExportMigrationContentProvider;->A05:LX/1o2;

    iget-object v4, v3, LX/38w;->ACR:LX/3GZ;

    iget-object v0, v4, LX/3GZ;->A72:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LX/2qa;

    invoke-static {v4}, LX/3GZ;->A8h(LX/3GZ;)LX/454;

    move-result-object v10

    iget-object v0, v4, LX/3GZ;->A9N:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LX/2sG;

    iget-object v0, v4, LX/3GZ;->AMf:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LX/33w;

    iget-object v0, v4, LX/3GZ;->AMe:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LX/2ql;

    iget-object v0, v4, LX/3GZ;->A9Q:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, LX/2q1;

    new-instance v4, LX/2RE;

    invoke-direct/range {v4 .. v10}, LX/2RE;-><init>(LX/2qa;LX/2ql;LX/2sG;LX/2q1;LX/33w;LX/454;)V

    iput-object v4, v1, Lcom/gbwhatsapp/migration/export/api/ExportMigrationContentProvider;->A03:LX/2RE;

    iget-object v0, v3, LX/38w;->A4F:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2LB;

    iput-object v0, v1, Lcom/gbwhatsapp/migration/export/api/ExportMigrationContentProvider;->A06:LX/2LB;

    iget-object v0, v2, LX/3GZ;->A9U:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/317;

    iput-object v0, v1, Lcom/gbwhatsapp/migration/export/api/ExportMigrationContentProvider;->A04:LX/317;

    const/4 v0, -0x1

    new-instance v4, Landroid/content/UriMatcher;

    invoke-direct {v4, v0}, Landroid/content/UriMatcher;-><init>(I)V

    sget-object v3, LX/260;->A03:Ljava/lang/String;

    const-string v2, "files"

    const/4 v0, 0x1

    invoke-virtual {v4, v3, v2, v0}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const-string v2, "file/#"

    const/4 v0, 0x2

    invoke-virtual {v4, v3, v2, v0}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    iput-object v4, v1, Lcom/gbwhatsapp/migration/export/api/ExportMigrationContentProvider;->A00:Landroid/content/UriMatcher;

    goto/16 :goto_0

    :cond_4
    instance-of v0, p0, Lcom/gbwhatsapp/instrumentation/api/InstrumentationProvider;

    if-eqz v0, :cond_5

    check-cast v1, Lcom/gbwhatsapp/instrumentation/api/InstrumentationProvider;

    invoke-virtual {v1}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_9

    invoke-static {v0}, LX/245;->A01(Landroid/content/Context;)LX/3GZ;

    move-result-object v2

    iget-object v0, v2, LX/3GZ;->AHm:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2zW;

    iput-object v0, v1, Lcom/gbwhatsapp/instrumentation/api/InstrumentationProvider;->A02:LX/2zW;

    iget-object v0, v2, LX/3GZ;->AHc:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2Kl;

    iput-object v0, v1, Lcom/gbwhatsapp/instrumentation/api/InstrumentationProvider;->A00:LX/2Kl;

    iget-object v0, v2, LX/3GZ;->AHn:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/1o3;

    iput-object v0, v1, Lcom/gbwhatsapp/instrumentation/api/InstrumentationProvider;->A03:LX/1o3;

    iget-object v0, v2, LX/3GZ;->ATS:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2io;

    iput-object v0, v1, Lcom/gbwhatsapp/instrumentation/api/InstrumentationProvider;->A04:LX/2io;

    iget-object v0, v2, LX/3GZ;->Ac2:LX/3GZ;

    iget-object v0, v0, LX/3GZ;->A00:LX/38w;

    iget-object v0, v0, LX/38w;->A2k:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2Gf;

    iput-object v0, v1, Lcom/gbwhatsapp/instrumentation/api/InstrumentationProvider;->A01:LX/2Gf;

    goto/16 :goto_0

    :cond_5
    instance-of v0, p0, Lcom/gbwhatsapp/contentprovider/MediaProvider;

    if-eqz v0, :cond_6

    check-cast v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;

    invoke-virtual {v1}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_a

    iput-object v0, v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;->A00:Landroid/content/Context;

    invoke-static {v0}, LX/245;->A01(Landroid/content/Context;)LX/3GZ;

    move-result-object v2

    invoke-virtual {v2}, LX/3GZ;->Bp5()LX/2sJ;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;->A05:LX/2sJ;

    invoke-static {v2}, LX/3GZ;->A02(LX/3GZ;)LX/3HW;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;->A01:LX/3HW;

    invoke-static {v2}, LX/3GZ;->A22(LX/3GZ;)LX/3J5;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;->A02:LX/3J5;

    invoke-static {v2}, LX/3GZ;->A24(LX/3GZ;)LX/352;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;->A03:LX/352;

    invoke-static {v2}, LX/3GZ;->A85(LX/3GZ;)LX/2pv;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;->A08:LX/2pv;

    iget-object v0, v2, LX/3GZ;->AJf:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/31u;

    iput-object v0, v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;->A06:LX/31u;

    iget-object v0, v2, LX/3GZ;->AVU:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2dS;

    iput-object v0, v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;->A07:LX/2dS;

    iget-object v0, v2, LX/3GZ;->A6s:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/31p;

    iput-object v0, v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;->A04:LX/31p;

    iget-object v0, v2, LX/3GZ;->A9n:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/30k;

    iput-object v0, v1, Lcom/gbwhatsapp/contentprovider/MediaProvider;->A09:LX/30k;

    goto/16 :goto_0

    :cond_6
    check-cast v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;

    invoke-virtual {v1}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_b

    invoke-static {v0}, LX/245;->A01(Landroid/content/Context;)LX/3GZ;

    move-result-object v4

    invoke-static {v4}, LX/3GZ;->A8i(LX/3GZ;)LX/454;

    move-result-object v0

    const/4 v3, 0x0

    invoke-static {v0, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A08:LX/454;

    iget-object v0, v4, LX/3GZ;->AUJ:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/34b;

    invoke-static {v0, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A05:LX/34b;

    invoke-static {v4}, LX/3GZ;->A2u(LX/3GZ;)LX/30C;

    move-result-object v0

    invoke-static {v0, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A02:LX/30C;

    iget-object v0, v4, LX/3GZ;->AS0:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0M:LX/8oO;

    iget-object v0, v4, LX/3GZ;->AaH:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0P:LX/8oO;

    iget-object v0, v4, LX/3GZ;->AXS:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0O:LX/8oO;

    iget-object v0, v4, LX/3GZ;->AJO:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0L:LX/8oO;

    iget-object v0, v4, LX/3GZ;->A1g:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0F:LX/8oO;

    iget-object v0, v4, LX/3GZ;->A0Q:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0A:LX/8oO;

    iget-object v0, v4, LX/3GZ;->AIs:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0K:LX/8oO;

    iget-object v0, v4, LX/3GZ;->AWz:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0N:LX/8oO;

    iget-object v0, v4, LX/3GZ;->AaC:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/1NB;

    invoke-static {v0, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A09:LX/1NB;

    invoke-static {v4}, LX/3GZ;->A08(LX/3GZ;)LX/1cv;

    move-result-object v0

    invoke-static {v0, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A00:LX/1cv;

    iget-object v0, v4, LX/3GZ;->A5I:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0H:LX/8oO;

    iget-object v0, v4, LX/3GZ;->AJ8:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/3bx;

    invoke-static {v0, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A07:LX/3bx;

    iget-object v0, v4, LX/3GZ;->A53:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0G:LX/8oO;

    iget-object v0, v4, LX/3GZ;->A12:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0E:LX/8oO;

    invoke-static {v4}, LX/3GZ;->A3I(LX/3GZ;)LX/3jF;

    move-result-object v0

    invoke-static {v0, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A03:LX/3jF;

    invoke-static {v4}, LX/3GZ;->A2q(LX/3GZ;)LX/354;

    move-result-object v0

    invoke-static {v0, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A01:LX/354;

    iget-object v0, v4, LX/3GZ;->ARv:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/3QY;

    invoke-static {v0, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A04:LX/3QY;

    iget-object v0, v4, LX/3GZ;->A0S:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0B:LX/8oO;

    iget-object v0, v4, LX/3GZ;->A0T:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0C:LX/8oO;

    iget-object v0, v4, LX/3GZ;->Ac2:LX/3GZ;

    iget-object v2, v0, LX/3GZ;->A00:LX/38w;

    iget-object v0, v2, LX/38w;->A6I:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0I:LX/8oO;

    iget-object v0, v4, LX/3GZ;->AIk:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2Ow;

    invoke-static {v0, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A06:LX/2Ow;

    iget-object v0, v4, LX/3GZ;->A0V:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0D:LX/8oO;

    iget-object v0, v2, LX/38w;->A6H:LX/41P;

    invoke-static {v0}, LX/0zZ;->A01(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/accountswitching/AccountSwitchingContentProvider;->A0J:LX/8oO;

    goto/16 :goto_0

    :cond_7
    const-string v0, "Context is not attached."

    invoke-static {v0}, LX/001;->A0i(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0

    :cond_8
    const-string v0, "Context is not attached."

    invoke-static {v0}, LX/001;->A0i(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0

    :cond_9
    const-string v0, "Context is not attached."

    invoke-static {v0}, LX/001;->A0i(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0

    :cond_a
    const-string v0, "Cannot find context from the provider."

    invoke-static {v0}, LX/001;->A0i(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0

    :cond_b
    const-string v0, "Context is not attached."

    invoke-static {v0}, LX/001;->A0i(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_c
    :goto_1
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final onCreate()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method
