.class public LX/12c;
.super LX/0V7;
.source ""

# interfaces
.implements LX/6Dp;


# instance fields
.field public A00:I

.field public A01:I

.field public A02:LX/3ep;

.field public A03:LX/1ZI;

.field public final A04:LX/08S;

.field public final A05:LX/08S;

.field public final A06:LX/08S;

.field public final A07:LX/08S;

.field public final A08:LX/08S;

.field public final A09:LX/08S;

.field public final A0A:LX/08S;

.field public final A0B:LX/08S;

.field public final A0C:LX/08S;

.field public final A0D:LX/08S;

.field public final A0E:LX/08S;

.field public final A0F:LX/08S;

.field public final A0G:LX/08S;

.field public final A0H:LX/08S;

.field public final A0I:LX/3by;

.field public final A0J:LX/2sr;

.field public final A0K:LX/1cz;

.field public final A0L:LX/3J5;

.field public final A0M:LX/352;

.field public final A0N:LX/2sJ;

.field public final A0O:LX/2ss;

.field public final A0P:LX/1bz;

.field public final A0Q:LX/2oL;

.field public final A0R:LX/2sk;

.field public final A0S:LX/1Pl;

.field public final A0T:LX/44u;

.field public final A0U:LX/2B4;

.field public final A0V:LX/3QV;

.field public final A0W:LX/3zY;

.field public final A0X:LX/2ic;

.field public final A0Y:LX/3QW;

.field public final A0Z:LX/3YE;

.field public final A0a:LX/34u;

.field public final A0b:LX/2dn;

.field public final A0c:LX/3xt;

.field public final A0d:Lcom/gbwhatsapp/reporttoadmin/xmpp/RtaXmppClient;

.field public final A0e:LX/2rM;

.field public final A0f:LX/4LC;

.field public final A0g:LX/4LC;

.field public final A0h:LX/4LC;

.field public final A0i:LX/454;


# direct methods
.method public constructor <init>(LX/26N;LX/3by;LX/2sr;LX/1cz;LX/3J5;LX/352;LX/2sJ;LX/2ss;LX/1bz;LX/2oL;LX/2sk;LX/1Pl;LX/44u;LX/3QV;LX/2ic;LX/3QW;LX/1ZI;LX/34u;LX/2dn;Lcom/gbwhatsapp/reporttoadmin/xmpp/RtaXmppClient;LX/2rM;LX/454;)V
    .locals 9

    invoke-direct {p0}, LX/0V7;-><init>()V

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A0B:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A0G:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A06:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A0C:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A05:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A08:LX/08S;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/12c;->A04:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A0H:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A07:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A0F:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A0A:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A0E:LX/08S;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A09:LX/08S;

    new-instance v0, LX/4LC;

    invoke-direct {v0, v1}, LX/4LC;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A0f:LX/4LC;

    new-instance v0, LX/08S;

    invoke-direct {v0, v1}, LX/08S;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A0D:LX/08S;

    new-instance v0, LX/4LC;

    invoke-direct {v0, v1}, LX/4LC;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12c;->A0g:LX/4LC;

    invoke-static {}, LX/0yU;->A0H()LX/4LC;

    move-result-object v0

    iput-object v0, p0, LX/12c;->A0h:LX/4LC;

    const/4 v0, 0x0

    iput v0, p0, LX/12c;->A00:I

    iput v0, p0, LX/12c;->A01:I

    const/4 v0, 0x1

    new-instance v1, LX/47D;

    invoke-direct {v1, p0, v0}, LX/47D;-><init>(Ljava/lang/Object;I)V

    iput-object v1, p0, LX/12c;->A0W:LX/3zY;

    new-instance v7, LX/2B4;

    invoke-direct {v7, p0}, LX/2B4;-><init>(LX/12c;)V

    iput-object v7, p0, LX/12c;->A0U:LX/2B4;

    new-instance v0, LX/3ZA;

    invoke-direct {v0, p0}, LX/3ZA;-><init>(LX/12c;)V

    iput-object v0, p0, LX/12c;->A0c:LX/3xt;

    move-object/from16 v0, p17

    iput-object v0, p0, LX/12c;->A03:LX/1ZI;

    move-object/from16 v0, p7

    iput-object v0, p0, LX/12c;->A0N:LX/2sJ;

    move-object/from16 v0, p12

    iput-object v0, p0, LX/12c;->A0S:LX/1Pl;

    iput-object p2, p0, LX/12c;->A0I:LX/3by;

    iput-object p3, p0, LX/12c;->A0J:LX/2sr;

    move-object/from16 v0, p22

    iput-object v0, p0, LX/12c;->A0i:LX/454;

    move-object/from16 v0, p8

    iput-object v0, p0, LX/12c;->A0O:LX/2ss;

    move-object/from16 v0, p13

    iput-object v0, p0, LX/12c;->A0T:LX/44u;

    move-object/from16 v0, p18

    iput-object v0, p0, LX/12c;->A0a:LX/34u;

    move-object/from16 v0, p21

    iput-object v0, p0, LX/12c;->A0e:LX/2rM;

    iput-object p6, p0, LX/12c;->A0M:LX/352;

    iput-object p5, p0, LX/12c;->A0L:LX/3J5;

    move-object/from16 v0, p14

    iput-object v0, p0, LX/12c;->A0V:LX/3QV;

    move-object/from16 v0, p16

    iput-object v0, p0, LX/12c;->A0Y:LX/3QW;

    move-object/from16 v0, p19

    iput-object v0, p0, LX/12c;->A0b:LX/2dn;

    move-object/from16 v0, p9

    iput-object v0, p0, LX/12c;->A0P:LX/1bz;

    move-object/from16 v0, p20

    iput-object v0, p0, LX/12c;->A0d:Lcom/gbwhatsapp/reporttoadmin/xmpp/RtaXmppClient;

    move-object/from16 v2, p15

    iput-object v2, p0, LX/12c;->A0X:LX/2ic;

    move-object/from16 v0, p11

    iput-object v0, p0, LX/12c;->A0R:LX/2sk;

    iput-object p4, p0, LX/12c;->A0K:LX/1cz;

    move-object/from16 v0, p10

    iput-object v0, p0, LX/12c;->A0Q:LX/2oL;

    iget-object v0, p1, LX/26N;->A00:LX/5qP;

    iget-object v0, v0, LX/5qP;->A03:LX/3GZ;

    invoke-static {v0}, LX/3GZ;->A44(LX/3GZ;)LX/1Pl;

    move-result-object v5

    invoke-static {v0}, LX/3GZ;->A2l(LX/3GZ;)LX/2sJ;

    move-result-object v4

    invoke-static {v0}, LX/3GZ;->A4B(LX/3GZ;)LX/44u;

    move-result-object v6

    invoke-static {v0}, LX/3GZ;->A5p(LX/3GZ;)LX/34u;

    move-result-object v8

    new-instance v3, LX/3YE;

    invoke-direct/range {v3 .. v8}, LX/3YE;-><init>(LX/2sJ;LX/1Pl;LX/44u;LX/2B4;LX/34u;)V

    iput-object v3, p0, LX/12c;->A0Z:LX/3YE;

    invoke-virtual {v2, v1}, LX/2ic;->A00(LX/3zY;)V

    iget-object v1, p0, LX/12c;->A0i:LX/454;

    const/16 v0, 0x14

    invoke-static {v1, p0, v0}, LX/3fE;->A00(LX/454;Ljava/lang/Object;I)V

    return-void
.end method


# virtual methods
.method public A0F()V
    .locals 2

    iget-object v1, p0, LX/12c;->A0X:LX/2ic;

    iget-object v0, p0, LX/12c;->A0W:LX/3zY;

    invoke-virtual {v1, v0}, LX/2ic;->A01(LX/3zY;)V

    return-void
.end method

.method public B15(LX/4VJ;Ljava/util/List;)V
    .locals 17

    move-object/from16 v4, p0

    iget-object v5, v4, LX/12c;->A0R:LX/2sk;

    iget-object v14, v4, LX/12c;->A03:LX/1ZI;

    iget-object v6, v5, LX/2sk;->A09:LX/34v;

    invoke-virtual {v6, v14}, LX/34v;->A07(LX/1Z5;)LX/34y;

    move-result-object v0

    invoke-virtual {v0}, LX/34y;->A05()LX/6fe;

    move-result-object v0

    invoke-static {}, LX/001;->A0z()Ljava/util/HashSet;

    move-result-object v7

    invoke-virtual {v0}, LX/8MC;->iterator()LX/8GM;

    move-result-object v3

    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {v3}, LX/0yS;->A0C(Ljava/util/Iterator;)LX/30T;

    move-result-object v1

    iget-object v2, v1, LX/30T;->A03:Lcom/whatsapp/jid/UserJid;

    iget-object v0, v4, LX/12c;->A0J:LX/2sr;

    invoke-virtual {v0, v2}, LX/2sr;->A0Z(LX/1ZJ;)Z

    move-result v0

    if-nez v0, :cond_0

    iget v1, v1, LX/30T;->A01:I

    if-eqz v1, :cond_0

    const/4 v0, 0x2

    invoke-static {v1, v0}, LX/000;->A1U(II)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {v7, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    move-object/from16 v0, p2

    invoke-static {v0}, LX/002;->A07(Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-interface {v1, v7}, Ljava/util/List;->removeAll(Ljava/util/Collection;)Z

    invoke-static {v7}, LX/002;->A07(Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-interface {v3, v0}, Ljava/util/List;->removeAll(Ljava/util/Collection;)Z

    invoke-virtual {v1}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {v3}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    if-nez v0, :cond_2

    return-void

    :cond_2
    iget-object v0, v4, LX/12c;->A0K:LX/1cz;

    invoke-virtual {v0}, LX/1cz;->A0D()Z

    move-result v0

    const/4 v2, 0x0

    move-object/from16 v7, p1

    if-nez v0, :cond_4

    invoke-static {v7}, LX/1cz;->A01(Landroid/content/Context;)Z

    move-result v0

    const v1, 0x7f1212db

    if-eqz v0, :cond_3

    const v1, 0x7f1212dc

    :cond_3
    iget-object v0, v4, LX/12c;->A0I:LX/3by;

    invoke-virtual {v0, v1, v2}, LX/3by;->A0M(II)V

    return-void

    :cond_4
    iget-object v0, v5, LX/2sk;->A04:LX/2ss;

    invoke-virtual {v0, v14}, LX/2ss;->A06(Lcom/whatsapp/jid/GroupJid;)I

    move-result v2

    const/4 v0, 0x1

    if-ne v2, v0, :cond_7

    iget-object v5, v5, LX/2sk;->A0D:LX/1Pl;

    const/16 v2, 0x677

    sget-object v0, LX/2vP;->A02:LX/2vP;

    invoke-virtual {v5, v0, v2}, LX/2sp;->A0M(LX/2vP;I)I

    move-result v5

    :goto_1
    invoke-virtual {v6, v14}, LX/34v;->A07(LX/1Z5;)LX/34y;

    move-result-object v0

    invoke-virtual {v0}, LX/34y;->A0E()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result v2

    invoke-virtual {v1}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    add-int/2addr v2, v0

    invoke-virtual {v3}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    sub-int/2addr v2, v0

    if-ge v5, v2, :cond_8

    iget-object v0, v4, LX/12c;->A0e:LX/2rM;

    invoke-virtual {v0, v14}, LX/2rM;->A06(LX/1ZI;)Z

    move-result v0

    if-eqz v0, :cond_5

    const/16 v1, 0xbcb

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    :goto_2
    sget-object v0, LX/3QV;->A1I:Landroid/os/Handler;

    invoke-static {v0, v3, v1}, LX/0yN;->A0r(Landroid/os/Handler;Ljava/lang/Object;I)V

    return-void

    :cond_5
    invoke-static {}, LX/001;->A0y()Ljava/util/HashMap;

    move-result-object v3

    invoke-virtual {v1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/16 v0, 0x1a3

    invoke-static {v1, v3, v0}, LX/0yM;->A1F(Ljava/lang/Object;Ljava/util/AbstractMap;I)V

    goto :goto_3

    :cond_6
    const/16 v1, 0xbbb

    goto :goto_2

    :cond_7
    invoke-virtual {v5, v14}, LX/2sk;->A02(LX/1ZI;)I

    move-result v0

    add-int/lit8 v5, v0, -0x1

    goto :goto_1

    :cond_8
    iget-object v0, v4, LX/12c;->A0i:LX/454;

    iget-object v11, v4, LX/12c;->A0N:LX/2sJ;

    iget-object v8, v4, LX/12c;->A0I:LX/3by;

    iget-object v9, v4, LX/12c;->A0L:LX/3J5;

    iget-object v10, v4, LX/12c;->A0M:LX/352;

    iget-object v12, v4, LX/12c;->A0V:LX/3QV;

    iget-object v13, v4, LX/12c;->A0Y:LX/3QW;

    new-instance v6, LX/1nE;

    move-object v15, v1

    move-object/from16 v16, v3

    invoke-direct/range {v6 .. v16}, LX/1nE;-><init>(LX/4VJ;LX/3by;LX/3J5;LX/352;LX/2sJ;LX/3QV;LX/3QW;LX/1ZI;Ljava/util/List;Ljava/util/List;)V

    invoke-static {v6, v0}, LX/0yQ;->A1H(LX/7jt;LX/454;)V

    return-void
.end method

.method public B2y()Ljava/util/List;
    .locals 5

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v4

    iget-object v0, p0, LX/12c;->A0R:LX/2sk;

    iget-object v1, p0, LX/12c;->A03:LX/1ZI;

    iget-object v0, v0, LX/2sk;->A09:LX/34v;

    invoke-static {v0, v1}, LX/34v;->A01(LX/34v;LX/1Z5;)LX/8GM;

    move-result-object v3

    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {v3}, LX/0yS;->A0C(Ljava/util/Iterator;)LX/30T;

    move-result-object v2

    iget v1, v2, LX/30T;->A01:I

    if-eqz v1, :cond_0

    const/4 v0, 0x2

    invoke-static {v1, v0}, LX/000;->A1U(II)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, LX/12c;->A0J:LX/2sr;

    iget-object v1, v2, LX/30T;->A03:Lcom/whatsapp/jid/UserJid;

    invoke-virtual {v0, v1}, LX/2sr;->A0Z(LX/1ZJ;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {v4, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    return-object v4
.end method

.method public B2z()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A04:LX/08S;

    return-object v0
.end method

.method public B7D()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A05:LX/08S;

    return-object v0
.end method

.method public B7E()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A06:LX/08S;

    return-object v0
.end method

.method public B7F()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A07:LX/08S;

    return-object v0
.end method

.method public B7G()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A08:LX/08S;

    return-object v0
.end method

.method public B7H()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A09:LX/08S;

    return-object v0
.end method

.method public B7I()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A0A:LX/08S;

    return-object v0
.end method

.method public B7J()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A0B:LX/08S;

    return-object v0
.end method

.method public B7K()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A0C:LX/08S;

    return-object v0
.end method

.method public B7M()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A0E:LX/08S;

    return-object v0
.end method

.method public B7N()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A0F:LX/08S;

    return-object v0
.end method

.method public B7O()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A0G:LX/08S;

    return-object v0
.end method

.method public B7P()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A0H:LX/08S;

    return-object v0
.end method

.method public BAs()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A0D:LX/08S;

    return-object v0
.end method

.method public BBg()LX/4LC;
    .locals 1

    iget-object v0, p0, LX/12c;->A0f:LX/4LC;

    return-object v0
.end method

.method public BBh()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12c;->A0g:LX/4LC;

    return-object v0
.end method

.method public BBi()LX/4LC;
    .locals 1

    iget-object v0, p0, LX/12c;->A0h:LX/4LC;

    return-object v0
.end method

.method public BOS()V
    .locals 4

    iget v3, p0, LX/12c;->A00:I

    if-lez v3, :cond_0

    iget v0, p0, LX/12c;->A01:I

    if-le v3, v0, :cond_0

    iget-object v2, p0, LX/12c;->A0h:LX/4LC;

    new-instance v1, LX/2GZ;

    invoke-direct {v1, v0, v3}, LX/2GZ;-><init>(II)V

    :goto_0
    invoke-virtual {v2, v1}, LX/0Y8;->A0F(Ljava/lang/Object;)V

    return-void

    :cond_0
    iget-object v2, p0, LX/12c;->A0Z:LX/3YE;

    iget-object v1, p0, LX/12c;->A03:LX/1ZI;

    const/4 v0, 0x0

    invoke-virtual {v2, v1, v0}, LX/3YE;->A01(LX/1ZI;Z)V

    iget-object v2, p0, LX/12c;->A0B:LX/08S;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_0
.end method

.method public BOV()V
    .locals 3

    iget-object v2, p0, LX/12c;->A0Z:LX/3YE;

    iget-object v1, p0, LX/12c;->A03:LX/1ZI;

    const/4 v0, 0x0

    invoke-virtual {v2, v1, v0}, LX/3YE;->A01(LX/1ZI;Z)V

    iget-object v1, p0, LX/12c;->A0B:LX/08S;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v1, v0}, LX/0Y8;->A0F(Ljava/lang/Object;)V

    return-void
.end method

.method public BYL()V
    .locals 1

    iget-object v0, p0, LX/12c;->A0B:LX/08S;

    invoke-static {v0}, LX/0yT;->A1Q(LX/0Y8;)V

    return-void
.end method

.method public BYN()V
    .locals 1

    iget-object v0, p0, LX/12c;->A0B:LX/08S;

    invoke-static {v0}, LX/0yT;->A1Q(LX/0Y8;)V

    return-void
.end method

.method public BYf(Z)V
    .locals 4

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "GroupPermissionsActivity report to admin dialog result "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p1, :cond_1

    const-string/jumbo v0, "off"

    :goto_0
    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, p0, LX/12c;->A0D:LX/08S;

    xor-int/lit8 v0, p1, 0x1

    invoke-static {v1, v0}, LX/0yN;->A0y(LX/0Y8;Z)V

    if-eqz p1, :cond_0

    iget-object v3, p0, LX/12c;->A0d:Lcom/gbwhatsapp/reporttoadmin/xmpp/RtaXmppClient;

    iget-object v2, p0, LX/12c;->A03:LX/1ZI;

    iget-object v1, p0, LX/12c;->A0c:LX/3xt;

    const/4 v0, 0x0

    invoke-virtual {v3, v2, v1, v0}, Lcom/gbwhatsapp/reporttoadmin/xmpp/RtaXmppClient;->A03(LX/1ZI;LX/3xt;Z)V

    :cond_0
    return-void

    :cond_1
    const-string v0, "On"

    goto :goto_0
.end method

.method public BqM(IZ)V
    .locals 15

    const/4 v0, 0x1

    move/from16 v3, p1

    move/from16 v2, p2

    if-eq v3, v0, :cond_8

    const/4 v0, 0x2

    if-eq v3, v0, :cond_b

    const/4 v0, 0x3

    if-eq v3, v0, :cond_4

    const/4 v1, 0x4

    iget-object v0, p0, LX/12c;->A02:LX/3ep;

    if-eq v3, v1, :cond_2

    if-eqz v0, :cond_0

    iget-boolean v0, v0, LX/3ep;->A0r:Z

    if-eq v0, v2, :cond_0

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "GroupPermissionsActivity report to admin toggled "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p2, :cond_1

    const-string v0, "On"

    :goto_0
    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    if-eqz p2, :cond_7

    iget-object v0, p0, LX/12c;->A0D:LX/08S;

    invoke-static {v0}, LX/0yT;->A1Q(LX/0Y8;)V

    iget-object v3, p0, LX/12c;->A0d:Lcom/gbwhatsapp/reporttoadmin/xmpp/RtaXmppClient;

    iget-object v2, p0, LX/12c;->A03:LX/1ZI;

    iget-object v1, p0, LX/12c;->A0c:LX/3xt;

    const/4 v0, 0x1

    invoke-virtual {v3, v2, v1, v0}, Lcom/gbwhatsapp/reporttoadmin/xmpp/RtaXmppClient;->A03(LX/1ZI;LX/3xt;Z)V

    :cond_0
    return-void

    :cond_1
    const-string v0, "Off"

    goto :goto_0

    :cond_2
    if-eqz v0, :cond_0

    iget v0, v0, LX/3ep;->A05:I

    invoke-static {v0}, LX/001;->A1T(I)Z

    move-result v0

    if-eq v0, v2, :cond_0

    iget-object v0, p0, LX/12c;->A0a:LX/34u;

    new-instance v7, LX/3XL;

    invoke-direct {v7, v0}, LX/3XL;-><init>(LX/34u;)V

    iget-object v5, p0, LX/12c;->A03:LX/1ZI;

    if-eqz p2, :cond_3

    const-string v4, "all_member_add"

    :goto_1
    new-instance v0, LX/2Ue;

    invoke-direct {v0, p0}, LX/2Ue;-><init>(LX/12c;)V

    iput-object v0, v7, LX/3XL;->A00:LX/2Ue;

    iget-object v6, v7, LX/3XL;->A01:LX/34u;

    invoke-virtual {v6}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v9

    const-string/jumbo v1, "member_add_mode"

    const/4 v0, 0x0

    new-instance v3, LX/381;

    invoke-direct {v3, v1, v4, v0}, LX/381;-><init>(Ljava/lang/String;Ljava/lang/String;[LX/3C7;)V

    invoke-static {}, LX/0yU;->A0j()[LX/3C7;

    move-result-object v1

    const-string v0, "id"

    invoke-static {v0, v9, v1}, LX/3C7;->A06(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-static {}, LX/3C7;->A01()LX/3C7;

    move-result-object v0

    invoke-static {v1, v0}, LX/3C7;->A0G([Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v5, v3, v1}, LX/381;->A0B(Lcom/whatsapp/jid/Jid;LX/381;[LX/3C7;)LX/381;

    move-result-object v8

    const/16 v10, 0x150

    const-wide/16 v11, 0x0

    invoke-virtual/range {v6 .. v12}, LX/34u;->A0E(LX/43r;LX/381;Ljava/lang/String;IJ)V

    new-instance v1, LX/1Qc;

    invoke-direct {v1}, LX/1Qc;-><init>()V

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iput-object v0, v1, LX/1Qc;->A00:Ljava/lang/Boolean;

    iget-object v0, p0, LX/12c;->A0T:LX/44u;

    invoke-interface {v0, v1}, LX/44u;->Bfn(LX/3eo;)V

    return-void

    :cond_3
    const-string v4, "admin_add"

    goto :goto_1

    :cond_4
    iget-object v0, p0, LX/12c;->A02:LX/3ep;

    if-eqz v0, :cond_0

    iget-boolean v0, v0, LX/3ep;->A14:Z

    if-eq v0, v2, :cond_0

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "GroupPermissionsActivity require membership approval toggled "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p2, :cond_5

    const-string v0, "On"

    :goto_2
    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    if-eqz p2, :cond_6

    iget-object v2, p0, LX/12c;->A0Z:LX/3YE;

    iget-object v1, p0, LX/12c;->A03:LX/1ZI;

    const/4 v0, 0x1

    invoke-virtual {v2, v1, v0}, LX/3YE;->A01(LX/1ZI;Z)V

    iget-object v0, p0, LX/12c;->A0B:LX/08S;

    goto :goto_3

    :cond_5
    const-string v0, "Off"

    goto :goto_2

    :cond_6
    iget-object v0, p0, LX/12c;->A0f:LX/4LC;

    goto :goto_3

    :cond_7
    iget-object v0, p0, LX/12c;->A0g:LX/4LC;

    :goto_3
    invoke-static {v0}, LX/0yT;->A1Q(LX/0Y8;)V

    return-void

    :cond_8
    xor-int/lit8 v0, p2, 0x1

    iget-object v1, p0, LX/12c;->A02:LX/3ep;

    if-eqz v1, :cond_a

    iget-boolean v1, v1, LX/3ep;->A15:Z

    if-eq v1, v0, :cond_a

    iget-object v8, p0, LX/12c;->A0Y:LX/3QW;

    iget-object v4, p0, LX/12c;->A03:LX/1ZI;

    iget-object v3, p0, LX/12c;->A0V:LX/3QV;

    iget-object v2, p0, LX/12c;->A0P:LX/1bz;

    const/4 v5, 0x0

    const/16 v7, 0x9f

    new-instance v1, LX/1Ey;

    move-object v6, v5

    invoke-direct/range {v1 .. v7}, LX/1Ey;-><init>(LX/1bz;LX/3QV;LX/1ZI;Ljava/lang/String;Ljava/util/List;I)V

    if-eqz v0, :cond_9

    const-string/jumbo v12, "locked"

    :goto_4
    move-object v11, v1

    move-object v9, v4

    move-object v10, v1

    move-object v13, v5

    move v14, v7

    invoke-virtual/range {v8 .. v14}, LX/3QW;->A0D(LX/1ZI;LX/40K;Ljava/lang/Runnable;Ljava/lang/String;[LX/3C7;I)V

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "GroupXmppMethods/set-restrict-mode; restrictModeEnabled="

    goto :goto_6

    :cond_9
    const-string/jumbo v12, "unlocked"

    goto :goto_4

    :cond_a
    const-string v0, "EditGroupInfoDialogFragment/onPositiveButtonClick: skip request, values are equal"

    goto :goto_7

    :cond_b
    xor-int/lit8 v0, p2, 0x1

    iget-object v1, p0, LX/12c;->A02:LX/3ep;

    if-eqz v1, :cond_d

    iget-boolean v1, v1, LX/3ep;->A0f:Z

    if-eq v1, v0, :cond_d

    iget-object v8, p0, LX/12c;->A0Y:LX/3QW;

    iget-object v4, p0, LX/12c;->A03:LX/1ZI;

    iget-object v3, p0, LX/12c;->A0V:LX/3QV;

    iget-object v2, p0, LX/12c;->A0P:LX/1bz;

    const/4 v5, 0x0

    const/16 v7, 0xa1

    new-instance v1, LX/1Ey;

    move-object v6, v5

    invoke-direct/range {v1 .. v7}, LX/1Ey;-><init>(LX/1bz;LX/3QV;LX/1ZI;Ljava/lang/String;Ljava/util/List;I)V

    if-eqz v0, :cond_c

    const-string v12, "announcement"

    :goto_5
    move-object v11, v1

    move-object v9, v4

    move-object v10, v1

    move-object v13, v5

    move v14, v7

    invoke-virtual/range {v8 .. v14}, LX/3QW;->A0D(LX/1ZI;LX/40K;Ljava/lang/Runnable;Ljava/lang/String;[LX/3C7;I)V

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "GroupXmppMethods/set-announcements-only; announcementsEnabled="

    :goto_6
    invoke-static {v1, v2, v0}, LX/0yL;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;Z)Ljava/lang/String;

    move-result-object v0

    :goto_7
    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    return-void

    :cond_c
    const-string/jumbo v12, "not_announcement"

    goto :goto_5

    :cond_d
    const-string v0, "SendMessagesDialogFragment/onPositiveButtonClick: skip request, values are equal"

    goto :goto_7
.end method
