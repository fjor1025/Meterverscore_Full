.class public LX/109;
.super Landroid/os/Handler;
.source ""


# instance fields
.field public final synthetic A00:LX/2z2;


# direct methods
.method public constructor <init>(Landroid/os/Looper;LX/2z2;)V
    .locals 0

    iput-object p2, p0, LX/109;->A00:LX/2z2;

    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 1

    iget-object v0, p0, LX/109;->A00:LX/2z2;

    invoke-virtual {v0}, LX/2z2;->A00()V

    return-void
.end method
