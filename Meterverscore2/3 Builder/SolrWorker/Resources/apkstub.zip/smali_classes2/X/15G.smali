.class public final LX/15G;
.super LX/156;
.source ""


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    const-string/jumbo v0, "lib-main"

    invoke-direct {p0, p1, v0}, LX/156;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method
