.class public LX/10p;
.super Landroid/widget/FrameLayout;
.source ""

# interfaces
.implements LX/468;


# instance fields
.field public A00:LX/5pD;

.field public A01:LX/5pD;

.field public A02:LX/5pD;

.field public A03:LX/5pD;

.field public A04:LX/5pD;

.field public A05:LX/5pD;

.field public A06:LX/3FT;

.field public A07:LX/28g;

.field public A08:LX/2sr;

.field public A09:LX/3RL;

.field public A0A:LX/2PV;

.field public A0B:LX/1IN;

.field public A0C:LX/2Eq;

.field public A0D:LX/2vh;

.field public A0E:LX/2oW;

.field public A0F:LX/31p;

.field public A0G:LX/2sJ;

.field public A0H:LX/2iX;

.field public A0I:LX/354;

.field public A0J:LX/1Pl;

.field public A0K:LX/44u;

.field public A0L:LX/2Uf;

.field public A0M:LX/96T;

.field public A0N:LX/1d6;

.field public A0O:LX/9AB;

.field public A0P:LX/2fS;

.field public A0Q:LX/5SJ;

.field public A0R:LX/34j;

.field public A0S:LX/2LW;

.field public A0T:LX/5X7;

.field public A0U:LX/454;

.field public A0V:LX/5p7;

.field public A0W:Z

.field public final A0X:LX/43C;

.field public final A0Y:LX/43C;

.field public final A0Z:LX/43C;

.field public final A0a:LX/43C;

.field public final A0b:LX/43C;

.field public final A0c:LX/3Fh;

.field public final A0d:LX/1IO;

.field public final A0e:LX/1IQ;

.field public final A0f:LX/1IR;

.field public final A0g:LX/3Fd;

.field public final A0h:LX/3Fb;

.field public final A0i:LX/3Fg;

.field public final A0j:LX/3Fe;

.field public final A0k:[I


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/0eh;)V
    .locals 19

    const/4 v1, 0x0

    const/4 v0, 0x0

    move-object/from16 v5, p0

    move-object/from16 v2, p1

    invoke-direct {v5, v2, v1, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    iget-boolean v0, v5, LX/10p;->A0W:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, v5, LX/10p;->A0W:Z

    invoke-virtual {v5}, LX/10p;->generatedComponent()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/5jV;

    check-cast v0, LX/4UR;

    invoke-virtual {v0, v5}, LX/4UR;->A58(LX/10p;)V

    :cond_0
    const/16 v0, 0xd

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iput-object v0, v5, LX/10p;->A0k:[I

    const/4 v0, 0x1

    new-instance v1, LX/49R;

    invoke-direct {v1, v5, v0}, LX/49R;-><init>(Ljava/lang/Object;I)V

    iget-object v3, v5, LX/10p;->A0K:LX/44u;

    iget-object v2, v5, LX/10p;->A0I:LX/354;

    new-instance v0, LX/2Vn;

    invoke-direct {v0, v2, v3}, LX/2Vn;-><init>(LX/354;LX/44u;)V

    new-instance v2, LX/11M;

    invoke-direct {v2, v5}, LX/11M;-><init>(LX/10p;)V

    invoke-static {v5, v2}, LX/0Zj;->A0O(Landroid/view/View;LX/0XR;)V

    iget-object v8, v5, LX/10p;->A0J:LX/1Pl;

    iget-object v4, v5, LX/10p;->A01:LX/5pD;

    iget-object v3, v5, LX/10p;->A00:LX/5pD;

    new-instance v2, LX/3Fb;

    invoke-direct {v2, v4, v3, v5, v8}, LX/3Fb;-><init>(LX/5pD;LX/5pD;LX/10p;LX/1Pl;)V

    iput-object v2, v5, LX/10p;->A0h:LX/3Fb;

    iget-object v6, v5, LX/10p;->A0B:LX/1IN;

    iget-object v9, v5, LX/10p;->A0U:LX/454;

    iget-object v7, v5, LX/10p;->A0C:LX/2Eq;

    new-instance v4, LX/1IO;

    invoke-direct/range {v4 .. v9}, LX/1IO;-><init>(LX/10p;LX/1IN;LX/2Eq;LX/1Pl;LX/454;)V

    iput-object v4, v5, LX/10p;->A0d:LX/1IO;

    iget-object v7, v5, LX/10p;->A0G:LX/2sJ;

    iget-object v9, v5, LX/10p;->A0J:LX/1Pl;

    iget-object v10, v5, LX/10p;->A0K:LX/44u;

    iget-object v11, v5, LX/10p;->A0L:LX/2Uf;

    iget-object v8, v5, LX/10p;->A0I:LX/354;

    iget-object v6, v5, LX/10p;->A0F:LX/31p;

    new-instance v4, LX/3Fi;

    invoke-direct/range {v4 .. v11}, LX/3Fi;-><init>(LX/10p;LX/31p;LX/2sJ;LX/354;LX/1Pl;LX/44u;LX/2Uf;)V

    iput-object v4, v5, LX/10p;->A0Z:LX/43C;

    iget-object v2, v5, LX/10p;->A07:LX/28g;

    new-instance v13, LX/38u;

    invoke-direct {v13}, LX/38u;-><init>()V

    iget-object v2, v2, LX/28g;->A00:LX/5qN;

    iget-object v3, v2, LX/5qN;->A03:LX/3GZ;

    invoke-static {v3}, LX/3GZ;->A44(LX/3GZ;)LX/1Pl;

    move-result-object v11

    iget-object v2, v3, LX/3GZ;->A5n:LX/41P;

    invoke-interface {v2}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LX/2pp;

    iget-object v2, v3, LX/3GZ;->A00:LX/38w;

    invoke-static {v2}, LX/38w;->A1B(LX/38w;)LX/2mt;

    move-result-object v8

    invoke-static {v2}, LX/38w;->A5T(LX/38w;)LX/5Zk;

    move-result-object v14

    invoke-static {v3}, LX/3GZ;->A04(LX/3GZ;)LX/2sr;

    move-result-object v6

    invoke-static {v3}, LX/3GZ;->A06(LX/3GZ;)LX/2hh;

    move-result-object v7

    invoke-static {v3}, LX/3GZ;->A4B(LX/3GZ;)LX/44u;

    move-result-object v12

    invoke-static {v3}, LX/3GZ;->A2q(LX/3GZ;)LX/354;

    move-result-object v10

    new-instance v4, LX/3Fj;

    invoke-direct/range {v4 .. v14}, LX/3Fj;-><init>(Landroid/view/ViewGroup;LX/2sr;LX/2hh;LX/2mt;LX/2pp;LX/354;LX/1Pl;LX/44u;LX/38u;LX/5Zk;)V

    iput-object v4, v5, LX/10p;->A0b:LX/43C;

    iget-object v6, v5, LX/10p;->A0G:LX/2sJ;

    iget-object v9, v5, LX/10p;->A0J:LX/1Pl;

    iget-object v7, v5, LX/10p;->A0H:LX/2iX;

    iget-object v3, v5, LX/10p;->A02:LX/5pD;

    iget-object v8, v5, LX/10p;->A0I:LX/354;

    iget-object v4, v5, LX/10p;->A03:LX/5pD;

    iget-object v10, v5, LX/10p;->A0O:LX/9AB;

    new-instance v2, LX/3Fg;

    invoke-direct/range {v2 .. v10}, LX/3Fg;-><init>(LX/5pD;LX/5pD;LX/10p;LX/2sJ;LX/2iX;LX/354;LX/1Pl;LX/9AB;)V

    iput-object v2, v5, LX/10p;->A0i:LX/3Fg;

    iget-object v3, v5, LX/10p;->A0K:LX/44u;

    iget-object v11, v5, LX/10p;->A06:LX/3FT;

    new-instance v10, LX/3Ff;

    move-object v12, v5

    move-object v13, v8

    move-object v14, v9

    move-object v15, v3

    move-object/from16 v16, v1

    invoke-direct/range {v10 .. v16}, LX/3Ff;-><init>(LX/3FT;LX/10p;LX/354;LX/1Pl;LX/44u;LX/41P;)V

    iput-object v10, v5, LX/10p;->A0a:LX/43C;

    iget-object v4, v5, LX/10p;->A09:LX/3RL;

    new-instance v2, LX/3Fa;

    invoke-direct {v2, v5, v4, v0}, LX/3Fa;-><init>(LX/10p;LX/3RL;LX/2Vn;)V

    iput-object v2, v5, LX/10p;->A0X:LX/43C;

    iget-object v4, v5, LX/10p;->A0Q:LX/5SJ;

    iget-object v2, v5, LX/10p;->A0R:LX/34j;

    iget-object v0, v5, LX/10p;->A0P:LX/2fS;

    new-instance v12, LX/3Fe;

    move-object v13, v5

    move-object v15, v0

    move-object/from16 v16, v4

    move-object/from16 v17, v2

    move-object/from16 v18, v1

    invoke-direct/range {v12 .. v18}, LX/3Fe;-><init>(LX/10p;LX/1Pl;LX/2fS;LX/5SJ;LX/34j;LX/41P;)V

    iput-object v12, v5, LX/10p;->A0j:LX/3Fe;

    iget-object v2, v5, LX/10p;->A0M:LX/96T;

    new-instance v0, LX/1IQ;

    invoke-direct {v0, v5, v2}, LX/1IQ;-><init>(LX/10p;LX/9QT;)V

    iput-object v0, v5, LX/10p;->A0e:LX/1IQ;

    iget-object v2, v5, LX/10p;->A0N:LX/1d6;

    new-instance v0, LX/1IR;

    invoke-direct {v0, v5, v2}, LX/1IR;-><init>(LX/10p;LX/1d6;)V

    iput-object v0, v5, LX/10p;->A0f:LX/1IR;

    new-instance v0, LX/2D1;

    invoke-direct {v0, v8}, LX/2D1;-><init>(LX/354;)V

    new-instance v2, LX/2Ni;

    invoke-direct {v2, v8, v9, v3, v0}, LX/2Ni;-><init>(LX/354;LX/1Pl;LX/44u;LX/2D1;)V

    iget-object v0, v5, LX/10p;->A0T:LX/5X7;

    new-instance v12, LX/3Fd;

    move-object/from16 v13, p2

    move-object v14, v5

    move-object v15, v6

    move-object/from16 v16, v0

    move-object/from16 v17, v2

    invoke-direct/range {v12 .. v17}, LX/3Fd;-><init>(LX/0eh;LX/10p;LX/2sJ;LX/5X7;LX/2Ni;)V

    iput-object v12, v5, LX/10p;->A0g:LX/3Fd;

    iget-object v2, v5, LX/10p;->A04:LX/5pD;

    invoke-virtual {v2}, LX/5pD;->A07()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {v2}, LX/5pD;->A04()Ljava/lang/Object;

    const-string v0, "create"

    invoke-static {v0}, LX/001;->A0j(Ljava/lang/String;)Ljava/lang/NullPointerException;

    move-result-object v0

    throw v0

    :cond_1
    iget-object v2, v5, LX/10p;->A05:LX/5pD;

    invoke-virtual {v2}, LX/5pD;->A07()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {v2}, LX/5pD;->A04()Ljava/lang/Object;

    const-string v0, "create"

    invoke-static {v0}, LX/001;->A0j(Ljava/lang/String;)Ljava/lang/NullPointerException;

    move-result-object v0

    throw v0

    :cond_2
    new-instance v2, LX/29K;

    invoke-direct {v2, v8}, LX/29K;-><init>(LX/354;)V

    new-instance v0, LX/3Fc;

    invoke-direct {v0, v5, v2, v9, v1}, LX/3Fc;-><init>(LX/10p;LX/29K;LX/1Pl;LX/41P;)V

    iput-object v0, v5, LX/10p;->A0Y:LX/43C;

    iget-object v0, v5, LX/10p;->A0D:LX/2vh;

    new-instance v4, LX/3Fh;

    move-object v6, v11

    move-object v7, v0

    move-object v10, v3

    invoke-direct/range {v4 .. v10}, LX/3Fh;-><init>(Landroid/widget/FrameLayout;LX/3FT;LX/2vh;LX/354;LX/1Pl;LX/44u;)V

    iput-object v4, v5, LX/10p;->A0c:LX/3Fh;

    return-void

    :array_0
    .array-data 4
        0x24
        0x21
        0xc
        0x28
        0x25
        0x1b
        0x1
        0xb
        0x14
        0xd
        0xe
        0x15
        0x2c
    .end array-data
.end method

.method private getBannerType()I
    .locals 7

    iget-object v4, p0, LX/10p;->A0k:[I

    array-length v3, v4

    const/4 v6, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v3, :cond_a

    aget v1, v4, v2

    iget-object v0, p0, LX/10p;->A08:LX/2sr;

    invoke-virtual {v0}, LX/2sr;->A0X()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    if-eq v1, v0, :cond_1

    const/16 v0, 0x2c

    if-eq v1, v0, :cond_2

    rsub-int/lit8 v1, v1, 0xb

    if-eqz v1, :cond_7

    :cond_0
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    if-eq v1, v5, :cond_6

    const/16 v5, 0x14

    if-eq v1, v5, :cond_5

    const/16 v0, 0x1b

    if-eq v1, v0, :cond_9

    const/16 v5, 0x21

    if-ne v1, v5, :cond_2

    iget-object v0, p0, LX/10p;->A0Y:LX/43C;

    :goto_2
    invoke-interface {v0}, LX/43C;->BmU()Z

    move-result v0

    :goto_3
    if-eqz v0, :cond_0

    return v5

    :cond_2
    const/16 v5, 0x2c

    if-eq v1, v5, :cond_4

    const/16 v5, 0x24

    if-eq v1, v5, :cond_3

    const/16 v5, 0x25

    if-eq v1, v5, :cond_8

    packed-switch v1, :pswitch_data_0

    goto :goto_1

    :cond_3
    iget-object v0, p0, LX/10p;->A0c:LX/3Fh;

    invoke-virtual {v0}, LX/3Fh;->A01()Z

    move-result v0

    goto :goto_3

    :cond_4
    iget-object v0, p0, LX/10p;->A0b:LX/43C;

    goto :goto_2

    :cond_5
    iget-object v0, p0, LX/10p;->A0e:LX/1IQ;

    iget-object v0, v0, LX/3Fk;->A02:LX/9QT;

    invoke-virtual {v0}, LX/9QT;->A05()Z

    move-result v0

    goto :goto_3

    :cond_6
    iget-object v0, p0, LX/10p;->A0Z:LX/43C;

    goto :goto_2

    :pswitch_0
    iget-object v0, p0, LX/10p;->A0f:LX/1IR;

    iget-object v0, v0, LX/3Fk;->A02:LX/9QT;

    invoke-virtual {v0}, LX/9QT;->A05()Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xe

    return v0

    :pswitch_1
    iget-object v0, p0, LX/10p;->A0X:LX/43C;

    invoke-interface {v0}, LX/43C;->BmU()Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xd

    return v0

    :pswitch_2
    iget-object v0, p0, LX/10p;->A0j:LX/3Fe;

    invoke-virtual {v0}, LX/3Fe;->BmU()Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xc

    return v0

    :cond_7
    :pswitch_3
    iget-object v0, p0, LX/10p;->A0a:LX/43C;

    invoke-interface {v0}, LX/43C;->BmU()Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xb

    return v0

    :cond_8
    iget-object v1, p0, LX/10p;->A0A:LX/2PV;

    if-eqz v1, :cond_0

    iget-object v0, p0, LX/10p;->A0d:LX/1IO;

    iget-object v1, v1, LX/2PV;->A00:LX/3y1;

    invoke-virtual {v0}, LX/3Fl;->A04()Z

    move-result v0

    if-eqz v0, :cond_0

    if-eqz v1, :cond_0

    return v5

    :cond_9
    iget-object v0, p0, LX/10p;->A0g:LX/3Fd;

    iget-object v0, v0, LX/3Fd;->A02:LX/10p;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    goto/16 :goto_1

    :cond_a
    return v6

    :pswitch_data_0
    .packed-switch 0xb
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public A00(II)V
    .locals 2

    new-instance v1, LX/1SE;

    invoke-direct {v1}, LX/1SE;-><init>()V

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iput-object v0, v1, LX/1SE;->A00:Ljava/lang/Integer;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iput-object v0, v1, LX/1SE;->A01:Ljava/lang/Integer;

    iget-object v0, p0, LX/10p;->A0K:LX/44u;

    invoke-interface {v0, v1}, LX/44u;->Bfl(LX/3eo;)V

    return-void
.end method

.method public A01(LX/2PV;)V
    .locals 12

    iput-object p1, p0, LX/10p;->A0A:LX/2PV;

    iget-object v0, p0, LX/10p;->A0i:LX/3Fg;

    invoke-virtual {v0}, LX/3Fg;->BEE()V

    iget-object v7, p0, LX/10p;->A0Z:LX/43C;

    invoke-interface {v7}, LX/43C;->BEE()V

    iget-object v6, p0, LX/10p;->A0a:LX/43C;

    invoke-interface {v6}, LX/43C;->BEE()V

    iget-object v11, p0, LX/10p;->A0d:LX/1IO;

    invoke-virtual {v11}, LX/3Fl;->BEE()V

    iget-object v10, p0, LX/10p;->A0j:LX/3Fe;

    invoke-virtual {v10}, LX/3Fe;->BEE()V

    iget-object v4, p0, LX/10p;->A0X:LX/43C;

    invoke-interface {v4}, LX/43C;->BEE()V

    iget-object v3, p0, LX/10p;->A0f:LX/1IR;

    invoke-virtual {v3}, LX/3Fk;->BEE()V

    iget-object v1, p0, LX/10p;->A0e:LX/1IQ;

    invoke-virtual {v1}, LX/3Fk;->BEE()V

    iget-object v9, p0, LX/10p;->A0g:LX/3Fd;

    invoke-virtual {v9}, LX/3Fd;->BEE()V

    iget-object v8, p0, LX/10p;->A0b:LX/43C;

    invoke-interface {v8}, LX/43C;->BEE()V

    iget-object v5, p0, LX/10p;->A0Y:LX/43C;

    invoke-interface {v5}, LX/43C;->BEE()V

    iget-object v0, p0, LX/10p;->A0c:LX/3Fh;

    invoke-virtual {v0}, LX/3Fh;->BEE()V

    invoke-direct {p0}, LX/10p;->getBannerType()I

    move-result v2

    iget-object v0, p0, LX/10p;->A08:LX/2sr;

    invoke-virtual {v0}, LX/2sr;->A0X()Z

    const/16 v0, 0x25

    if-ne v2, v0, :cond_0

    if-eqz p1, :cond_a

    invoke-virtual {v11, p1}, LX/3Fl;->A02(LX/2PV;)V

    return-void

    :cond_0
    const/16 v0, 0xc

    if-ne v2, v0, :cond_1

    invoke-virtual {v10}, LX/3Fe;->Bpq()V

    return-void

    :cond_1
    const/16 v0, 0x1b

    if-ne v2, v0, :cond_2

    invoke-virtual {v9}, LX/3Fd;->Bpq()V

    return-void

    :cond_2
    const/16 v0, 0x2c

    if-ne v2, v0, :cond_3

    invoke-interface {v8}, LX/43C;->Bpq()V

    return-void

    :cond_3
    if-eqz v2, :cond_4

    const/4 v0, 0x1

    if-eq v2, v0, :cond_7

    const/16 v0, 0xb

    if-eq v2, v0, :cond_8

    const/16 v0, 0x14

    if-eq v2, v0, :cond_6

    const/16 v0, 0x21

    if-eq v2, v0, :cond_9

    const/16 v0, 0xd

    if-eq v2, v0, :cond_5

    const/16 v0, 0xe

    if-ne v2, v0, :cond_a

    invoke-virtual {v3}, LX/3Fk;->Bpq()V

    :cond_4
    :goto_0
    invoke-virtual {v3, v2}, LX/3Fk;->A02(I)V

    invoke-virtual {v1, v2}, LX/3Fk;->A02(I)V

    return-void

    :cond_5
    move-object v5, v4

    goto :goto_1

    :cond_6
    invoke-virtual {v1}, LX/3Fk;->Bpq()V

    goto :goto_0

    :cond_7
    move-object v5, v7

    goto :goto_1

    :cond_8
    move-object v5, v6

    :cond_9
    :goto_1
    invoke-interface {v5}, LX/43C;->Bpq()V

    goto :goto_0

    :cond_a
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "Unhandled banner type: "

    invoke-static {v0, v1, v2}, LX/0yK;->A05(Ljava/lang/String;Ljava/lang/StringBuilder;I)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0
.end method

.method public A02(LX/2PV;)Z
    .locals 7

    iput-object p1, p0, LX/10p;->A0A:LX/2PV;

    iget-object v0, p0, LX/10p;->A08:LX/2sr;

    invoke-virtual {v0}, LX/2sr;->A0X()Z

    const/4 v6, 0x1

    iget-object v0, p0, LX/10p;->A08:LX/2sr;

    invoke-virtual {v0}, LX/2sr;->A0X()Z

    iget-object v0, p0, LX/10p;->A08:LX/2sr;

    invoke-virtual {v0}, LX/2sr;->A0X()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, LX/10p;->A0R:LX/34j;

    invoke-virtual {v0}, LX/34j;->A01()LX/1e0;

    move-result-object v0

    if-eqz v0, :cond_1

    :cond_0
    return v6

    :cond_1
    iget-object v0, p0, LX/10p;->A08:LX/2sr;

    invoke-virtual {v0}, LX/2sr;->A0X()Z

    iget-object v0, p0, LX/10p;->A08:LX/2sr;

    invoke-virtual {v0}, LX/2sr;->A0X()Z

    iget-object v5, p0, LX/10p;->A0I:LX/354;

    invoke-static {v5}, LX/0yM;->A0C(LX/354;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v4, "education_banner_count"

    const/4 v3, 0x0

    invoke-interface {v0, v4, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    const/4 v0, 0x3

    if-lt v1, v0, :cond_2

    const/4 v0, 0x7

    invoke-static {v0}, LX/0yP;->A07(I)J

    move-result-wide v1

    const-string v0, "education_banner_timestamp"

    invoke-virtual {v5, v0, v1, v2}, LX/354;->A1c(Ljava/lang/String;J)Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-static {v5, v4, v3}, LX/0yK;->A0P(LX/354;Ljava/lang/String;I)V

    :cond_2
    iget-object v1, p0, LX/10p;->A02:LX/5pD;

    invoke-virtual {v1}, LX/5pD;->A07()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {v1}, LX/5pD;->A04()Ljava/lang/Object;

    const-string v0, "getSmbBannerType"

    invoke-static {v0}, LX/001;->A0j(Ljava/lang/String;)Ljava/lang/NullPointerException;

    move-result-object v0

    throw v0

    :cond_3
    invoke-direct {p0}, LX/10p;->getBannerType()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v6, 0x0

    return v6

    :cond_4
    return v3
.end method

.method public final generatedComponent()Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, LX/10p;->A0V:LX/5p7;

    if-nez v0, :cond_0

    new-instance v0, LX/5p7;

    invoke-direct {v0, p0}, LX/5p7;-><init>(Landroid/view/View;)V

    iput-object v0, p0, LX/10p;->A0V:LX/5p7;

    :cond_0
    invoke-virtual {v0}, LX/5p7;->generatedComponent()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method
