.class public LX/0zd;
.super Landroid/database/AbstractCursor;
.source ""


# instance fields
.field public A00:Ljava/util/Map;

.field public A01:Ljava/util/Map;

.field public final A02:I

.field public final A03:I

.field public final A04:I

.field public final A05:I

.field public final A06:I

.field public final A07:I

.field public final A08:LX/2sV;

.field public final A09:LX/352;

.field public final A0A:LX/2rn;

.field public final A0B:LX/2Kl;

.field public final A0C:LX/2Ge;

.field public final A0D:LX/2YS;

.field public final A0E:LX/2eU;

.field public final A0F:LX/340;

.field public final A0G:LX/8si;

.field public final A0H:LX/2on;

.field public final A0I:Ljava/util/List;

.field public final A0J:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final A0K:[Ljava/lang/String;


# direct methods
.method public constructor <init>(LX/2sV;LX/352;LX/2rn;LX/2Kl;LX/2Ge;LX/2YR;LX/2YS;LX/2eU;LX/340;LX/8si;LX/2on;Ljava/util/List;[Ljava/lang/String;)V
    .locals 14

    invoke-direct {p0}, Landroid/database/AbstractCursor;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, LX/0zd;->A00:Ljava/util/Map;

    iput-object v0, p0, LX/0zd;->A01:Ljava/util/Map;

    invoke-static {}, LX/0yU;->A0c()Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v0

    iput-object v0, p0, LX/0zd;->A0J:Ljava/util/concurrent/atomic/AtomicInteger;

    const-string v8, "_id"

    const-string v9, "display_name"

    const-string v10, "is_group"

    const-string v11, "call_rank"

    const-string/jumbo v12, "message_rank"

    const-string/jumbo v13, "primary_profile_picture_bytestream"

    move-object/from16 v7, p13

    if-nez p13, :cond_1

    filled-new-array/range {v8 .. v13}, [Ljava/lang/String;

    move-result-object v1

    :goto_0
    move-object/from16 v0, p6

    iget-object v0, v0, LX/2YR;->A01:LX/2Kl;

    iget-object v2, v0, LX/2Kl;->A00:LX/3RL;

    sget-object v0, LX/3RL;->A0v:LX/1El;

    invoke-virtual {v2, v0}, LX/3RL;->A08(LX/1El;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    new-instance v1, Ljava/util/LinkedList;

    invoke-direct {v1, v0}, Ljava/util/LinkedList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v1, v11}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v1, v12}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    const/4 v0, 0x0

    invoke-static {v1, v0}, LX/0yO;->A1b(Ljava/util/AbstractCollection;I)[Ljava/lang/String;

    move-result-object v1

    :cond_0
    iput-object v1, p0, LX/0zd;->A0K:[Ljava/lang/String;

    iput-object p1, p0, LX/0zd;->A08:LX/2sV;

    invoke-static/range {p12 .. p12}, LX/002;->A07(Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, p0, LX/0zd;->A0I:Ljava/util/List;

    move-object/from16 v0, p10

    iput-object v0, p0, LX/0zd;->A0G:LX/8si;

    move-object/from16 v0, p2

    iput-object v0, p0, LX/0zd;->A09:LX/352;

    move-object/from16 v0, p3

    iput-object v0, p0, LX/0zd;->A0A:LX/2rn;

    move-object/from16 v0, p11

    iput-object v0, p0, LX/0zd;->A0H:LX/2on;

    move-object/from16 v0, p4

    iput-object v0, p0, LX/0zd;->A0B:LX/2Kl;

    move-object/from16 v0, p5

    iput-object v0, p0, LX/0zd;->A0C:LX/2Ge;

    move-object/from16 v0, p7

    iput-object v0, p0, LX/0zd;->A0D:LX/2YS;

    move-object/from16 v0, p9

    iput-object v0, p0, LX/0zd;->A0F:LX/340;

    move-object/from16 v0, p8

    iput-object v0, p0, LX/0zd;->A0E:LX/2eU;

    invoke-static {v8, v1}, LX/37k;->A00(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v0

    iput v0, p0, LX/0zd;->A04:I

    invoke-static {v9, v1}, LX/37k;->A00(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v0

    iput v0, p0, LX/0zd;->A03:I

    invoke-static {v10, v1}, LX/37k;->A00(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v0

    iput v0, p0, LX/0zd;->A05:I

    invoke-static {v11, v1}, LX/37k;->A00(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v0

    iput v0, p0, LX/0zd;->A02:I

    invoke-static {v12, v1}, LX/37k;->A00(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v0

    iput v0, p0, LX/0zd;->A06:I

    invoke-static {v13, v1}, LX/37k;->A00(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v0

    iput v0, p0, LX/0zd;->A07:I

    return-void

    :cond_1
    filled-new-array/range {v8 .. v13}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LX/0yM;->A0f([Ljava/lang/Object;)Ljava/util/HashSet;

    move-result-object v6

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v5

    array-length v4, v7

    const/4 v3, 0x0

    const/4 v2, 0x0

    :goto_1
    if-ge v2, v4, :cond_3

    aget-object v1, p13, v2

    invoke-virtual {v6, v1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {v5, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    invoke-static {v5, v3}, LX/0yO;->A1b(Ljava/util/AbstractCollection;I)[Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_0
.end method


# virtual methods
.method public final A00(I)LX/3ep;
    .locals 2

    if-ltz p1, :cond_0

    iget-object v1, p0, LX/0zd;->A0I:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/3ep;

    return-object v0

    :cond_0
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "Position: "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ", size = "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, LX/0zd;->A0I:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    invoke-static {v1, v0}, LX/001;->A0n(Ljava/lang/StringBuilder;I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LX/001;->A0i(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0
.end method

.method public getColumnNames()[Ljava/lang/String;
    .locals 1

    iget-object v0, p0, LX/0zd;->A0K:[Ljava/lang/String;

    return-object v0
.end method

.method public getCount()I
    .locals 1

    iget-object v0, p0, LX/0zd;->A0I:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public getDouble(I)D
    .locals 1

    invoke-static {}, LX/0yT;->A19()Ljava/lang/UnsupportedOperationException;

    move-result-object v0

    throw v0
.end method

.method public getFloat(I)F
    .locals 1

    invoke-static {}, LX/0yT;->A19()Ljava/lang/UnsupportedOperationException;

    move-result-object v0

    throw v0
.end method

.method public getInt(I)I
    .locals 13

    const/4 v0, -0x1

    if-eq p1, v0, :cond_d

    invoke-virtual {p0}, Landroid/database/AbstractCursor;->getPosition()I

    move-result v0

    invoke-virtual {p0, v0}, LX/0zd;->A00(I)LX/3ep;

    move-result-object v5

    iget v0, p0, LX/0zd;->A05:I

    if-ne p1, v0, :cond_0

    invoke-virtual {v5}, LX/3ep;->A0V()Z

    move-result v0

    return v0

    :cond_0
    iget v0, p0, LX/0zd;->A02:I

    const v12, 0x7fffffff

    if-ne p1, v0, :cond_5

    iget-object v4, p0, LX/0zd;->A00:Ljava/util/Map;

    if-nez v4, :cond_4

    iget-object v4, p0, LX/0zd;->A0C:LX/2Ge;

    iget-object v0, p0, LX/0zd;->A0H:LX/2on;

    iget-object v9, v0, LX/2on;->A01:Ljava/lang/String;

    const/4 v6, 0x0

    invoke-static {v9, v6}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iget-object v7, v4, LX/2Ge;->A01:LX/2YR;

    iget-object v0, v7, LX/2YR;->A01:LX/2Kl;

    iget-object v1, v0, LX/2Kl;->A00:LX/3RL;

    sget-object v0, LX/3RL;->A0v:LX/1El;

    invoke-virtual {v1, v0}, LX/3RL;->A08(LX/1El;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, v7, LX/2YR;->A00:LX/2sJ;

    invoke-virtual {v0}, LX/2sJ;->A0H()J

    move-result-wide v10

    iget-object v8, v7, LX/2YR;->A02:LX/2zW;

    const-string/jumbo v3, "metadata/last_call_ranking_time"

    invoke-static {v9, v3}, LX/2zW;->A00(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v8}, LX/2zW;->A01()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-static {v0, v1}, LX/0yM;->A07(Landroid/content/SharedPreferences;Ljava/lang/String;)J

    move-result-wide v0

    sub-long/2addr v10, v0

    const-wide/32 v1, 0x5265c00

    cmp-long v0, v10, v1

    if-ltz v0, :cond_2

    invoke-static {v9, v3}, LX/2zW;->A00(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v8}, LX/2zW;->A01()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    iget-object v0, v8, LX/2zW;->A01:LX/2sJ;

    invoke-virtual {v0}, LX/2sJ;->A0H()J

    move-result-wide v0

    invoke-static {v2, v3, v0, v1}, LX/0yL;->A0r(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;J)V

    iget-object v2, v4, LX/2Ge;->A00:LX/2sa;

    new-instance v1, LX/3Ld;

    invoke-direct {v1}, LX/3Ld;-><init>()V

    const/16 v0, 0x3e8

    invoke-virtual {v2, v1, v6, v0}, LX/2sa;->A04(LX/3z8;II)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v7}, LX/2YR;->A00()J

    move-result-wide v2

    invoke-static {v0, v6}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    new-instance v1, LX/242;

    invoke-direct {v1, v0, v6}, LX/242;-><init>(Ljava/lang/Object;I)V

    new-instance v0, LX/3vF;

    invoke-direct {v0, v4, v2, v3}, LX/3vF;-><init>(LX/2Ge;J)V

    invoke-static {v0, v1}, LX/67t;->A02(LX/8wI;LX/41Q;)LX/41Q;

    move-result-object v2

    const/16 v1, 0x1a

    new-instance v0, LX/47i;

    invoke-direct {v0, v1}, LX/47i;-><init>(I)V

    new-instance v1, LX/3jY;

    invoke-direct {v1, v0, v2}, LX/3jY;-><init>(Ljava/util/Comparator;LX/41Q;)V

    new-instance v0, LX/3ud;

    invoke-direct {v0, v4}, LX/3ud;-><init>(LX/2Ge;)V

    new-instance v2, LX/3jX;

    invoke-direct {v2, v0, v1}, LX/3jX;-><init>(LX/8wI;LX/41Q;)V

    const/16 v1, 0x32

    instance-of v0, v2, LX/46F;

    if-eqz v0, :cond_1

    check-cast v2, LX/46F;

    invoke-interface {v2, v1}, LX/46F;->Bow(I)LX/41Q;

    move-result-object v1

    :goto_0
    new-instance v0, LX/3jW;

    invoke-direct {v0, v1}, LX/3jW;-><init>(LX/41Q;)V

    invoke-static {}, LX/0yT;->A1C()Ljava/util/LinkedHashMap;

    move-result-object v4

    new-instance v3, LX/49B;

    invoke-direct {v3, v0}, LX/49B;-><init>(LX/3jW;)V

    :goto_1
    invoke-virtual {v3}, LX/49B;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {v3}, LX/49B;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LX/2pi;

    iget-object v0, v2, LX/2pi;->A01:Ljava/lang/Object;

    invoke-static {v0}, LX/7nJ;->A0O(Ljava/lang/Object;)V

    check-cast v0, LX/3en;

    iget-object v0, v0, LX/3en;->A0E:LX/3Bv;

    iget-object v1, v0, LX/3Bv;->A01:Lcom/whatsapp/jid/UserJid;

    invoke-static {v1}, LX/7nJ;->A0O(Ljava/lang/Object;)V

    iget v0, v2, LX/2pi;->A00:I

    invoke-static {v1, v4, v0}, LX/0yM;->A1F(Ljava/lang/Object;Ljava/util/AbstractMap;I)V

    goto :goto_1

    :cond_1
    new-instance v1, LX/3jZ;

    invoke-direct {v1, v2}, LX/3jZ;-><init>(LX/41Q;)V

    goto :goto_0

    :cond_2
    invoke-static {}, LX/5r1;->A04()Ljava/util/Map;

    move-result-object v4

    :cond_3
    iput-object v4, p0, LX/0zd;->A00:Ljava/util/Map;

    :cond_4
    iget-object v1, v5, LX/3ep;->A0I:LX/1ZJ;

    invoke-interface {v4, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    iget-object v0, p0, LX/0zd;->A00:Ljava/util/Map;

    goto/16 :goto_5

    :cond_5
    iget v0, p0, LX/0zd;->A06:I

    if-ne p1, v0, :cond_c

    iget-object v0, p0, LX/0zd;->A01:Ljava/util/Map;

    if-nez v0, :cond_a

    iget-object v6, p0, LX/0zd;->A0D:LX/2YS;

    iget-object v0, p0, LX/0zd;->A0H:LX/2on;

    iget-object v9, v0, LX/2on;->A01:Ljava/lang/String;

    const/4 v0, 0x0

    invoke-static {v9, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iget-object v2, v6, LX/2YS;->A02:LX/2YR;

    iget-object v0, v2, LX/2YR;->A01:LX/2Kl;

    iget-object v1, v0, LX/2Kl;->A00:LX/3RL;

    sget-object v0, LX/3RL;->A0v:LX/1El;

    invoke-virtual {v1, v0}, LX/3RL;->A08(LX/1El;)Z

    move-result v0

    if-eqz v0, :cond_8

    iget-object v0, v2, LX/2YR;->A00:LX/2sJ;

    invoke-virtual {v0}, LX/2sJ;->A0H()J

    move-result-wide v7

    iget-object v4, v2, LX/2YR;->A02:LX/2zW;

    const-string/jumbo v3, "metadata/last_message_ranking_time"

    invoke-static {v9, v3}, LX/2zW;->A00(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4}, LX/2zW;->A01()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-static {v0, v1}, LX/0yM;->A07(Landroid/content/SharedPreferences;Ljava/lang/String;)J

    move-result-wide v0

    sub-long/2addr v7, v0

    const-wide/32 v1, 0x5265c00

    cmp-long v0, v7, v1

    if-ltz v0, :cond_8

    invoke-static {v9, v3}, LX/2zW;->A00(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4}, LX/2zW;->A01()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    iget-object v0, v4, LX/2zW;->A01:LX/2sJ;

    invoke-virtual {v0}, LX/2sJ;->A0H()J

    move-result-wide v0

    invoke-static {v2, v3, v0, v1}, LX/0yL;->A0r(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;J)V

    iget-object v1, v6, LX/2YS;->A00:LX/2sA;

    const/4 v0, 0x0

    invoke-virtual {v1, v0}, LX/2sA;->A08(Z)V

    iget-object v0, v6, LX/2YS;->A01:LX/2ss;

    invoke-virtual {v0}, LX/2ss;->A0F()Ljava/util/Collection;

    move-result-object v0

    invoke-static {v0}, LX/0yP;->A0j(Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v7

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v0, v1

    check-cast v0, LX/31w;

    invoke-virtual {v0}, LX/31w;->A05()LX/1ZJ;

    move-result-object v0

    instance-of v0, v0, Lcom/whatsapp/jid/UserJid;

    invoke-static {v1, v3, v7, v0}, LX/0yO;->A1J(Ljava/lang/Object;Ljava/util/AbstractCollection;Ljava/util/AbstractCollection;I)V

    goto :goto_2

    :cond_6
    invoke-virtual {v6, v3}, LX/2YS;->A00(Ljava/util/List;)Ljava/util/Map;

    move-result-object v4

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v3

    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_7
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v0, v1

    check-cast v0, LX/31w;

    invoke-virtual {v0}, LX/31w;->A05()LX/1ZJ;

    move-result-object v0

    instance-of v0, v0, Lcom/whatsapp/jid/GroupJid;

    if-eqz v0, :cond_7

    invoke-virtual {v3, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_8
    invoke-static {}, LX/5r1;->A04()Ljava/util/Map;

    move-result-object v1

    invoke-static {}, LX/5r1;->A04()Ljava/util/Map;

    move-result-object v0

    new-instance v2, LX/2jq;

    invoke-direct {v2, v1, v0}, LX/2jq;-><init>(Ljava/util/Map;Ljava/util/Map;)V

    goto :goto_4

    :cond_9
    invoke-virtual {v6, v3}, LX/2YS;->A00(Ljava/util/List;)Ljava/util/Map;

    move-result-object v0

    new-instance v2, LX/2jq;

    invoke-direct {v2, v4, v0}, LX/2jq;-><init>(Ljava/util/Map;Ljava/util/Map;)V

    :goto_4
    iget-object v0, v2, LX/2jq;->A01:Ljava/util/Map;

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1, v0}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    iput-object v1, p0, LX/0zd;->A01:Ljava/util/Map;

    iget-object v0, v2, LX/2jq;->A00:Ljava/util/Map;

    invoke-virtual {v1, v0}, Ljava/util/AbstractMap;->putAll(Ljava/util/Map;)V

    :cond_a
    iget-object v1, v5, LX/3ep;->A0I:LX/1ZJ;

    iget-object v0, p0, LX/0zd;->A01:Ljava/util/Map;

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    iget-object v0, p0, LX/0zd;->A01:Ljava/util/Map;

    :goto_5
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, LX/001;->A0K(Ljava/lang/Object;)I

    move-result v12

    :cond_b
    return v12

    :cond_c
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "Column #"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " is not an int."

    invoke-static {v0, v1}, LX/000;->A0J(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0

    :cond_d
    const-string v0, "Invalid column index"

    invoke-static {v0}, LX/001;->A0i(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0
.end method

.method public getLong(I)J
    .locals 1

    invoke-static {}, LX/0yT;->A19()Ljava/lang/UnsupportedOperationException;

    move-result-object v0

    throw v0
.end method

.method public getShort(I)S
    .locals 1

    invoke-static {}, LX/0yT;->A19()Ljava/lang/UnsupportedOperationException;

    move-result-object v0

    throw v0
.end method

.method public getString(I)Ljava/lang/String;
    .locals 13

    const/4 v0, -0x1

    if-eq p1, v0, :cond_1b

    invoke-virtual {p0}, Landroid/database/AbstractCursor;->getPosition()I

    move-result v0

    invoke-virtual {p0, v0}, LX/0zd;->A00(I)LX/3ep;

    move-result-object v1

    iget v0, p0, LX/0zd;->A04:I

    if-ne p1, v0, :cond_0

    iget-object v3, p0, LX/0zd;->A0E:LX/2eU;

    iget-object v2, p0, LX/0zd;->A0H:LX/2on;

    const-class v0, LX/1ZJ;

    invoke-virtual {v1, v0}, LX/3ep;->A0H(Ljava/lang/Class;)Lcom/whatsapp/jid/Jid;

    move-result-object v0

    if-eqz v0, :cond_18

    iget-object v1, v3, LX/2eU;->A01:LX/34A;

    invoke-virtual {v0}, Lcom/whatsapp/jid/Jid;->getRawString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v2, v0}, LX/34A;->A03(LX/2on;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    iget v0, p0, LX/0zd;->A03:I

    if-ne p1, v0, :cond_2

    invoke-static {v1}, LX/3ep;->A06(LX/3ep;)Lcom/whatsapp/jid/UserJid;

    move-result-object v3

    if-eqz v3, :cond_1

    iget-object v2, p0, LX/0zd;->A08:LX/2sV;

    if-eqz v2, :cond_1

    iget-object v0, v2, LX/2sV;->A01:LX/2lc;

    invoke-virtual {v0}, LX/2lc;->A00()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {v3}, LX/7af;->A00(LX/1ZJ;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {v2, v3}, LX/2sV;->A01(Lcom/whatsapp/jid/UserJid;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    iget-object v2, p0, LX/0zd;->A09:LX/352;

    const/4 v0, 0x0

    invoke-virtual {v2, v1, v0}, LX/352;->A0G(LX/3ep;Z)LX/2Fm;

    move-result-object v0

    iget-object v0, v0, LX/2Fm;->A01:Ljava/lang/String;

    return-object v0

    :cond_2
    iget v0, p0, LX/0zd;->A05:I

    if-eq p1, v0, :cond_1a

    iget v0, p0, LX/0zd;->A02:I

    if-eq p1, v0, :cond_1a

    iget v0, p0, LX/0zd;->A06:I

    if-eq p1, v0, :cond_1a

    iget v0, p0, LX/0zd;->A07:I

    if-ne p1, v0, :cond_19

    iget-object v0, p0, LX/0zd;->A0B:LX/2Kl;

    iget-object v3, v0, LX/2Kl;->A01:LX/1Pl;

    const/16 v2, 0x14dc

    sget-object v0, LX/2vP;->A02:LX/2vP;

    invoke-virtual {v3, v0, v2}, LX/2sp;->A0W(LX/2vP;I)Z

    move-result v0

    if-eqz v0, :cond_18

    iget-object v0, v1, LX/3ep;->A0I:LX/1ZJ;

    if-eqz v0, :cond_18

    iget-object v0, p0, LX/0zd;->A0J:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v5

    iget-object v4, p0, LX/0zd;->A0G:LX/8si;

    const v3, 0x1d773f3d

    const/4 v2, 0x0

    invoke-interface {v4, v3, v5, v2}, LX/8si;->BJY(IIZ)V

    invoke-virtual {p0}, Landroid/database/AbstractCursor;->getPosition()I

    move-result v6

    if-gez v6, :cond_5

    const-string v6, "invalid"

    :goto_0
    const-string v0, "cursor_position"

    invoke-interface {v4, v3, v5, v0, v6}, LX/8si;->markerAnnotate(IILjava/lang/String;Ljava/lang/String;)V

    iget-object v0, v1, LX/3ep;->A0I:LX/1ZJ;

    instance-of v0, v0, Lcom/whatsapp/jid/PhoneUserJid;

    if-eqz v0, :cond_3

    invoke-static {v1}, LX/3ep;->A02(LX/3ep;)LX/1ZJ;

    move-result-object v0

    invoke-static {v0}, LX/37z;->A04(LX/1ZJ;)Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_3

    sget-object v0, LX/340;->A04:LX/8oO;

    invoke-interface {v0}, LX/8oO;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/regex/Pattern;

    invoke-static {v6, v0}, LX/001;->A1Y(Ljava/lang/CharSequence;Ljava/util/regex/Pattern;)Z

    move-result v0

    const/4 v6, 0x1

    if-nez v0, :cond_4

    :cond_3
    const/4 v6, 0x0

    :cond_4
    if-eqz v6, :cond_13

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const-string v0, "is_privacy_placeholder"

    invoke-interface {v4, v3, v5, v0, v2}, LX/8si;->markerAnnotate(IILjava/lang/String;Z)V

    iget-object v0, p0, LX/0zd;->A0A:LX/2rn;

    invoke-virtual {v0, v1}, LX/2rn;->A01(LX/3ep;)Ljava/io/File;

    move-result-object v1

    const-string v0, "get_file_end"

    invoke-interface {v4, v3, v5, v0}, LX/8si;->markerPoint(IILjava/lang/String;)V

    const/4 v6, 0x0

    if-eqz v1, :cond_12

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_12

    goto :goto_1

    :cond_5
    const/16 v0, 0xa

    if-ge v6, v0, :cond_6

    const-string v6, "<10"

    goto :goto_0

    :cond_6
    const/16 v0, 0x32

    if-ge v6, v0, :cond_7

    const-string v6, "<50"

    goto :goto_0

    :cond_7
    const/16 v0, 0x64

    if-ge v6, v0, :cond_8

    const-string v6, "<100"

    goto :goto_0

    :cond_8
    const/16 v0, 0x1f4

    if-ge v6, v0, :cond_9

    const-string v6, "<500"

    goto :goto_0

    :cond_9
    const/16 v0, 0x3e8

    if-ge v6, v0, :cond_a

    const-string v6, "<1000"

    goto :goto_0

    :cond_a
    const-string v6, ">=1000"

    goto :goto_0

    :goto_1
    :try_start_0
    invoke-static {v1}, LX/0yT;->A0g(Ljava/io/File;)Ljava/io/FileInputStream;

    move-result-object v7
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-virtual {v1}, Ljava/io/File;->length()J

    move-result-wide v0

    long-to-int v11, v0

    const-string v12, "file_size"

    int-to-long v0, v11

    const-wide/16 v9, 0x0

    cmp-long v8, v0, v9

    if-gez v8, :cond_b

    const-string v8, "Invalid"

    :goto_2
    invoke-interface {v4, v3, v5, v12, v8}, LX/8si;->markerAnnotate(IILjava/lang/String;Ljava/lang/String;)V

    goto :goto_3

    :cond_b
    const-wide/16 v9, 0x800

    cmp-long v8, v0, v9

    if-gez v8, :cond_c

    const-string v8, "<2KB"

    goto :goto_2

    :cond_c
    const-wide/16 v9, 0x1000

    cmp-long v8, v0, v9

    if-gez v8, :cond_d

    const-string v8, "<4KB"

    goto :goto_2

    :cond_d
    const-wide/16 v9, 0x1800

    cmp-long v8, v0, v9

    if-gez v8, :cond_e

    const-string v8, "<6KB"

    goto :goto_2

    :cond_e
    const-wide/16 v9, 0x2000

    cmp-long v8, v0, v9

    if-gez v8, :cond_f

    const-string v8, "<8KB"

    goto :goto_2

    :cond_f
    const-wide/16 v9, 0x2800

    cmp-long v8, v0, v9

    if-gez v8, :cond_10

    const-string v8, "<10KB"

    goto :goto_2

    :cond_10
    const-string v8, ">=10KB"

    goto :goto_2

    :goto_3
    const-wide/32 v9, 0x19000

    cmp-long v8, v0, v9

    if-lez v8, :cond_11

    const-string v0, "ContactsUriHandler/RestrictedCursor/getThumbnailPic thumbnail file size is >100KB"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    sget-object v0, LX/1uT;->A01:LX/1uT;

    invoke-static {v6, v0}, LX/0yT;->A0H(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v8
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V

    goto :goto_5
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    :cond_11
    :try_start_3
    new-array v1, v11, [B

    const-string/jumbo v0, "read_from_file_to_byte_array_end"

    invoke-interface {v4, v3, v5, v0}, LX/8si;->markerPoint(IILjava/lang/String;)V

    invoke-virtual {v7, v1}, Ljava/io/InputStream;->read([B)I

    const-string v0, "convert_to_byte_array_end"

    invoke-interface {v4, v3, v5, v0}, LX/8si;->markerPoint(IILjava/lang/String;)V

    invoke-static {v1}, LX/0yO;->A0o([B)Ljava/lang/String;

    move-result-object v1

    const-string v0, "encode_to_base64_string_end"

    invoke-interface {v4, v3, v5, v0}, LX/8si;->markerPoint(IILjava/lang/String;)V

    sget-object v0, LX/1uT;->A04:LX/1uT;

    invoke-static {v1, v0}, LX/0yT;->A0H(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v8
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V

    goto :goto_5
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    :catchall_0
    move-exception v1

    :try_start_5
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V

    goto :goto_4
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :catchall_1
    move-exception v0

    :try_start_6
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4
    throw v1
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_0

    :cond_12
    sget-object v0, LX/1uT;->A03:LX/1uT;

    invoke-static {v6, v0}, LX/0yT;->A0H(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v8

    goto :goto_5

    :cond_13
    const-string v1, "is_privacy_placeholder"

    const/4 v0, 0x1

    invoke-interface {v4, v3, v5, v1, v0}, LX/8si;->markerAnnotate(IILjava/lang/String;Z)V

    const-string v1, "/9j/4AAQSkZJRgABAQAAAQABAAD/7QCEUGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAGgcAigAYkZCTUQwYTAwMGE2ZjAxMDAwMDUxMDIwMDAwZWMwMzAwMDA2ZjA0MDAwMGU2MDQwMDAwMTYwNjAwMDA4MzA3MDAwMGQ0MDcwMDAwNTMwODAwMDBiYTA4MDAwMDBlMGIwMDAwAP/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/CABEIAGAAYAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBwUGAAEDAv/EABkBAAIDAQAAAAAAAAAAAAAAAAAEAQIDBf/aAAwDAQACEAMQAAABVOZsNdDr+FBkG4VWiYAewoITmz6Da8dm9BkiCygnJ/ROKopgERivZg4aXDrXbPx2ZQ8eylxsya61C6K08+TKurz7DD2euAFnLF0rJqEsjD0YlXslWuhjpRDpIlavOcVedHWiilZ4zPgsG+oVk4cbX7pVtJhroDNdWOgmf4E88lo6FmScVa9YNizJXrVR2ah6ESJqzJN1KFg2otY8yHZIIoqIdccpRQuNOH8zbeswP//EACMQAAICAgICAgMBAAAAAAAAAAIDAQQABRESEyEQIhQgMiP/2gAIAQEAAQUC+YGZxdQywdaycLWsjGVTHJGY/atXJs0NTi6alxwqM4VONpqZF/U5YrkqfmqmWnrKArBjYCAS5uRSHJpDhqcnAZBxtKEGNpMrPBjmdHUxx9BrIgBsXiKZKSwSkcr3iGbSIkVF5A3lTjCjiag9m65fjroHzWtm/llKmLFWA8Tuc5zVv+zR8NrZr8iLY9WayOXL9VtXjS7M1rIOrsGSdrOcrl1fsv6f7rbKP9tbPDlfatq59vHo6rYmu16F3Vo17Cbbokgag97Oznllj61tjPLqpdWatnkQmZVd3QCLecRYYglbaMvbDzhqa/Qe35Fnat6Jsl2YH9aCZ6qHtbu0mWrDdTMCdOwMhTsHNXWivLdnzYEQle6t9in3KY5PSJ4VEkqTl5xE2EzF9sZN9s4UOfIiCR2ux9PZJllLjyU7i1JftxjI3P2Ts1nkWUzk2Uxj9msIu7STxrZOfgS65+SfEsKc7TguIci2cZNs5wnEWc/p/8QAIREAAgIBAwUBAAAAAAAAAAAAAQIAAxEQEiEgMUFhcRT/2gAIAQMBAT8B0LqIHB6Hcudqw2VL2GYtlTeMRGKHa2jnAljbah7lyIKlI0rbdV8iHIjjIlozT8lVwUbH5Eb84TjvK12Vc+YowNCqlcNGqpPqLXUnbmIhY7n6CoMCga//xAAhEQACAgEEAgMAAAAAAAAAAAABAgAREBIxYXEDIBMhIv/aAAgBAgEBPwHGoQMD6MSxoQug5gdDxFJU0cNtHNJ3HVQgIwhtOou0baOLTqJ5K/LbQ/Fp+oopO4NsEAijCiHiBUHMVSTZ9KlZ/8QAKxAAAQIEBAYCAgMAAAAAAAAAAQACAxEhMRASQVETICIyYYEjcQRiQlKC/9oACAEBAAY/AuSysrK3PQIFwVlZWVkS0KvIEC4KQU+0eV1RHLpiFT7m+FIolo5A4qQXGj/ddFKF0t31VSSukkKUWo3XGg/ZkpFEjAYV7W1XCFhdZ4k62TmbY8I2NkQO01GBQQUU+U47lNGraFOmJZaYwz+yhHAoYRW+09uxWYW1CESG7q3UowysGo1Re12ZgUNvlQm+8CgpJsv5UTHjudfCcN0l8sM/5WRjcrNZox4lKU+kX6aKSOIP9RNZszWsAkF8USbv2VYTvVVSE73RZ/yXAy00XDg9mp3UyiAcBg7K0Eld8vpTa8+11QwV0wwF8jqbKZRa04iaFVTCq0WioqFV5Lq+F1dXV+X/xAAkEAACAQQCAQUBAQAAAAAAAAAAAREhMUFREGFxIIGhsdHB8P/aAAgBAQABPyHl7RFjYQXiC8u7D2q9SSgohKUoLFDxQ1QhCgnlJ6FglzBCNdV8/gSVZ4hDSpfMM1gzy8vRqTXEShbgCiqFJiCwfozfYH4PJcduRtLTpwJH39FAOixraFhSEiZRHOxSHGCOuqRkzn7MRZ2JOKDXWVO1jkYnfk6vRYgAprjBCuz3mWTQk7YIa3u1/IhGmNE9XWyeDUuE+xYzaoqp0ReU98jQRohyJQc/yoVKz03IU6UKfyx1cuGfAXUupo0MXZV+yqQjdSGknR75Jd2JTLBAiU015GgUYTxnhcGXWGQaB7afsqWZVrmQCqu42G3hvgLfLBKCxBBTYXuAU6kyPugouCukiSDN+H8EMS7/AGNrNq87Gv8A6D6M4OGR6hHiDcYHVkFnwjpGFondVJlObdNopb7bllTT9hEqVIhAGtt8VIJSFiSkhGVBQpoyYyYYJonkT825c0odBIvrHYWpjPTPS9MNnf0f/9oADAMBAAIAAwAAABDiAyhzTyGRZzxNQj26KsUo/wAAb4/dJ8sNU50c/8QAJREBAAIBAwMDBQAAAAAAAAAAAQARMRAhUUFxkSBhoYGxwfDx/9oACAEDAQE/ENMozDPospQZeI7VnlYrTbyO08NnnS5YxDLb7EBvdr683LjPeXt2lCyxJTPV15/SOAt+O0Db30c/yPRk/iVJHEZku90RHcX5PzHrK/fE69vtrUyxMAa//8QAHREBAAICAwEBAAAAAAAAAAAAAQAREDEgIVGRof/aAAgBAgEBPxDCW2aR4fUbOhCEaS2UapMQwjcRhHvaisMFonY+oQotQhWt/Y9TuDQIymlz0odstcQaXZAms//EACYQAQACAQIGAgMBAQAAAAAAAAEAESExQVFhcYGRoRCxIMHw0eH/2gAIAQEAAT8Q+SgzKnVcoMfRGj6Je6LlGgx+IK0RfCLwgvOmSZ4Jyg1Hhg1PhmWC8poYa4IhkB4REafl6yLBSDV5JQkKxiAlWUW2nLV5qWxDiB93LQltQfVQFqZje0czWVfG+MKtdXgjLCn4UjdmwnnJB9JRWIyQHYHGf5XWWhlix3P5cavWqy9wWT6L/SXAvih3nie+syxWdSXU+4upbKh4n1wRWNmYyuxKNhipGhS6NODz9QlSrp3ch2Pbymoil+mi2t2Ikpku5lePksFA3bGXoTPZ4ynWCXAdTs3KZljBVUodjghgRC6rfIF/cV+0fdR4jtCtHufuCl/IaoyLjd30r5nUz4qB9MMvUv0wwEKNTihuXZD1aSXaAjlkfomB17ddnpJebrL/AEmp/wBmPN1WHl648kMwNgvIL7slQoHQa1po67eIIi2lcS3ogaAE7oH0wdGkqnFMpVQmXRhdSk25/hp7Sp4nica9q7Hwdo3PPXP3rFE3SYPaleWIjIEDG2FGAuNnJBx3F8LrHLrDMNGp2On+94WwMZqu1iTdXGGnCVAE7w4Pt8QCrrQvqrQavHaU0xhD0Jp3uLqZuQ82hyx7ADvSJjDRNc5Ppg6zIbKhK6D+XF7gC8zNAFmGOi3jkF2zR4sOKIztAbUdYwFB2D319xOWWrxGA05vcfcGUTdp+oKb5YMPYxEgALzB5Vphjrm34orKGOAE4o3kusdROXGB1t4w22RtkhS8cJf5TwYhFuOfg6tJEU1dYxkd4A3a5SVO8Go8sCp8ssLneM2l/D//2Q=="

    sget-object v0, LX/1uT;->A04:LX/1uT;

    invoke-static {v1, v0}, LX/0yT;->A0H(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v8

    goto :goto_5

    :catch_0
    move-exception v1

    const-string v0, "ContactsUriHandler/RestrictedCursor/getThumbnailPic encountered IO exception"

    invoke-static {v0, v1}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)V

    sget-object v0, LX/1uT;->A02:LX/1uT;

    invoke-static {v6, v0}, LX/0yT;->A0H(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v8

    :goto_5
    iget-object v0, v8, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v0, LX/1uT;

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v7

    const/4 v0, 0x1

    const/4 v6, 0x2

    const-string v1, "is_pic_available"

    if-eq v7, v2, :cond_17

    if-eq v7, v0, :cond_16

    const/4 v0, 0x3

    if-eq v7, v0, :cond_15

    if-ne v7, v6, :cond_14

    invoke-interface {v4, v3, v5, v1, v2}, LX/8si;->markerAnnotate(IILjava/lang/String;Z)V

    const/16 v0, 0x93

    :goto_6
    invoke-interface {v4, v3, v5, v0}, LX/8si;->markerEnd(IIS)V

    :cond_14
    :goto_7
    iget-object v0, v8, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    return-object v0

    :cond_15
    invoke-interface {v4, v3, v5, v1, v2}, LX/8si;->markerAnnotate(IILjava/lang/String;Z)V

    const/16 v0, 0x9f

    goto :goto_6

    :cond_16
    invoke-interface {v4, v3, v5, v1, v2}, LX/8si;->markerAnnotate(IILjava/lang/String;Z)V

    goto :goto_8

    :cond_17
    invoke-interface {v4, v3, v5, v1, v0}, LX/8si;->markerAnnotate(IILjava/lang/String;Z)V

    :goto_8
    invoke-interface {v4, v3, v5, v6}, LX/8si;->markerEnd(IIS)V

    goto :goto_7

    :cond_18
    const/4 v0, 0x0

    return-object v0

    :cond_19
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "Column #"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " is not a string."

    invoke-static {v0, v1}, LX/000;->A0J(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0

    :cond_1a
    invoke-virtual {p0, p1}, Landroid/database/AbstractCursor;->getInt(I)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1b
    const-string v0, "Invalid column index"

    invoke-static {v0}, LX/001;->A0i(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0
.end method

.method public isNull(I)Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
