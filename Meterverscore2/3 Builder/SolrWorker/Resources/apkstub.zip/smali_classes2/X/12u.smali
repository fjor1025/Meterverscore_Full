.class public LX/12u;
.super LX/0Ve;
.source ""


# instance fields
.field public final A00:Lcom/gbwhatsapp/TextEmojiLabel;

.field public final A01:LX/29u;


# direct methods
.method public constructor <init>(Landroid/view/View;LX/29u;)V
    .locals 1

    invoke-direct {p0, p1}, LX/0Ve;-><init>(Landroid/view/View;)V

    iput-object p2, p0, LX/12u;->A01:LX/29u;

    const v0, 0x7f0b08fd

    invoke-static {p1, v0}, LX/0yR;->A0Q(Landroid/view/View;I)Lcom/gbwhatsapp/TextEmojiLabel;

    move-result-object v0

    iput-object v0, p0, LX/12u;->A00:Lcom/gbwhatsapp/TextEmojiLabel;

    return-void
.end method
