.class public final LX/15C;
.super LX/3eJ;
.source ""


# instance fields
.field public A00:I

.field public final synthetic A01:LX/15E;


# direct methods
.method public constructor <init>(LX/15E;)V
    .locals 0

    iput-object p1, p0, LX/15C;->A01:LX/15E;

    invoke-direct {p0}, LX/3eJ;-><init>()V

    return-void
.end method
