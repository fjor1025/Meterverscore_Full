.class public LX/15I;
.super LX/6Sd;
.source ""


# instance fields
.field public final A00:J


# direct methods
.method public constructor <init>(LX/6Se;Ljava/lang/String;J)V
    .locals 0

    invoke-direct {p0, p1, p2}, LX/6Sd;-><init>(LX/7OX;Ljava/lang/String;)V

    iput-wide p3, p0, LX/15I;->A00:J

    return-void
.end method
