.class public final LX/15f;
.super LX/6gB;
.source ""

# interfaces
.implements LX/46C;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LX/6gB;-><init>()V

    return-void
.end method
