.class public LX/134;
.super LX/0gA;
.source ""


# instance fields
.field public final synthetic A00:Lcom/gbwhatsapp/greenalert/GreenAlertActivity;


# direct methods
.method public constructor <init>(Lcom/gbwhatsapp/greenalert/GreenAlertActivity;)V
    .locals 0

    iput-object p1, p0, LX/134;->A00:Lcom/gbwhatsapp/greenalert/GreenAlertActivity;

    invoke-direct {p0}, LX/0gA;-><init>()V

    return-void
.end method


# virtual methods
.method public BWI(I)V
    .locals 5

    iget-object v4, p0, LX/134;->A00:Lcom/gbwhatsapp/greenalert/GreenAlertActivity;

    iget-object v0, v4, Lcom/gbwhatsapp/greenalert/GreenAlertActivity;->A06:Lcom/gbwhatsapp/WaViewPager;

    invoke-virtual {v0}, Lcom/gbwhatsapp/WaViewPager;->getCurrentLogicalItem()I

    move-result v3

    const/4 v0, 0x1

    iget-object v2, v4, Lcom/gbwhatsapp/greenalert/GreenAlertActivity;->A0A:LX/5SJ;

    if-ne v3, v0, :cond_1

    iget-object v0, v4, Lcom/gbwhatsapp/greenalert/GreenAlertActivity;->A0B:LX/34j;

    invoke-static {v0}, LX/32W;->A02(LX/34j;)Z

    move-result v1

    const/4 v0, 0x7

    if-eqz v1, :cond_0

    const/4 v0, 0x3

    :cond_0
    :goto_0
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v2, v0}, LX/5SJ;->A01(Ljava/lang/Integer;)V

    invoke-virtual {v4, v3}, Lcom/gbwhatsapp/greenalert/GreenAlertActivity;->A6D(I)V

    invoke-virtual {v4, v3}, Lcom/gbwhatsapp/greenalert/GreenAlertActivity;->A6E(I)V

    return-void

    :cond_1
    const/16 v0, 0xb

    goto :goto_0
.end method
