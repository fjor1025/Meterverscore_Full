.class public abstract LX/0yc;
.super Landroid/app/IntentService;
.source ""

# interfaces
.implements LX/468;


# instance fields
.field public final A00:Ljava/lang/Object;

.field public volatile A01:LX/3dr;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    invoke-direct {p0, p1}, Landroid/app/IntentService;-><init>(Ljava/lang/String;)V

    invoke-static {}, LX/001;->A0k()Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, LX/0yc;->A00:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public A04()V
    .locals 4

    instance-of v0, p0, Lcom/gbwhatsapp/notification/DirectReplyService;

    if-eqz v0, :cond_1

    move-object v1, p0

    check-cast v1, Lcom/gbwhatsapp/notification/DirectReplyService;

    iget-boolean v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A0A:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A0A:Z

    invoke-virtual {v1}, LX/0yc;->generatedComponent()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/3dq;

    check-cast v0, LX/1Ei;

    iget-object v2, v0, LX/1Ei;->A06:LX/3GZ;

    invoke-static {v2}, LX/3GZ;->A03(LX/3GZ;)LX/3by;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A00:LX/3by;

    iget-object v0, v2, LX/3GZ;->AZ4:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/350;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A01:LX/350;

    invoke-static {v2}, LX/3GZ;->A22(LX/3GZ;)LX/3J5;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A02:LX/3J5;

    invoke-static {v2}, LX/3GZ;->A2i(LX/3GZ;)LX/34w;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A05:LX/34w;

    invoke-static {v2}, LX/3GZ;->A3H(LX/3GZ;)LX/1cx;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A06:LX/1cx;

    iget-object v0, v2, LX/3GZ;->A4t:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/89j;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A04:LX/89j;

    iget-object v0, v2, LX/3GZ;->ALC:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/34n;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A07:LX/34n;

    iget-object v0, v2, LX/3GZ;->A00:LX/38w;

    iget-object v0, v0, LX/38w;->A7j:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/3cY;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A08:LX/3cY;

    iget-object v0, v2, LX/3GZ;->A6q:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2nj;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A03:LX/2nj;

    invoke-static {v2}, LX/3GZ;->A6x(LX/3GZ;)LX/2yj;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/notification/DirectReplyService;->A09:LX/2yj;

    :cond_0
    return-void

    :cond_1
    instance-of v0, p0, Lcom/gbwhatsapp/notification/AndroidWear;

    if-eqz v0, :cond_2

    move-object v1, p0

    check-cast v1, Lcom/gbwhatsapp/notification/AndroidWear;

    iget-boolean v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A0A:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A0A:Z

    invoke-virtual {v1}, LX/0yc;->generatedComponent()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/3dq;

    check-cast v0, LX/1Ei;

    iget-object v2, v0, LX/1Ei;->A06:LX/3GZ;

    invoke-static {v2}, LX/3GZ;->A03(LX/3GZ;)LX/3by;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A00:LX/3by;

    iget-object v0, v2, LX/3GZ;->AZ4:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/350;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A01:LX/350;

    invoke-static {v2}, LX/3GZ;->A22(LX/3GZ;)LX/3J5;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A02:LX/3J5;

    invoke-static {v2}, LX/3GZ;->A2i(LX/3GZ;)LX/34w;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A05:LX/34w;

    iget-object v0, v2, LX/3GZ;->AO2:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2sN;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A06:LX/2sN;

    iget-object v0, v2, LX/3GZ;->A4t:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/89j;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A04:LX/89j;

    iget-object v0, v2, LX/3GZ;->ANa:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2sf;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A07:LX/2sf;

    iget-object v0, v2, LX/3GZ;->ALC:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/34n;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A08:LX/34n;

    iget-object v0, v2, LX/3GZ;->A6q:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2nj;

    iput-object v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A03:LX/2nj;

    invoke-static {v2}, LX/3GZ;->A6x(LX/3GZ;)LX/2yj;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/notification/AndroidWear;->A09:LX/2yj;

    return-void

    :cond_2
    move-object v1, p0

    check-cast v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;

    iget-boolean v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0f:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0f:Z

    invoke-virtual {v1}, LX/0yc;->generatedComponent()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LX/3dq;

    check-cast v2, LX/1Ei;

    invoke-static {}, LX/0yU;->A0b()Ljava/util/Random;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0e:Ljava/util/Random;

    iget-object v2, v2, LX/1Ei;->A06:LX/3GZ;

    invoke-static {v2}, LX/3GZ;->A2l(LX/3GZ;)LX/2sJ;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0J:LX/2sJ;

    invoke-static {v2}, LX/3GZ;->A44(LX/3GZ;)LX/1Pl;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0U:LX/1Pl;

    invoke-static {v2}, LX/3GZ;->A03(LX/3GZ;)LX/3by;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A03:LX/3by;

    invoke-static {v2}, LX/3GZ;->A00(LX/3GZ;)LX/2qa;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A01:LX/2qa;

    invoke-static {v2}, LX/3GZ;->A04(LX/3GZ;)LX/2sr;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A04:LX/2sr;

    invoke-static {v2}, LX/3GZ;->A2m(LX/3GZ;)LX/2iX;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0K:LX/2iX;

    invoke-static {v2}, LX/3GZ;->A02(LX/3GZ;)LX/3HW;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A02:LX/3HW;

    invoke-static {v2}, LX/3GZ;->A4B(LX/3GZ;)LX/44u;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0V:LX/44u;

    iget-object v0, v2, LX/3GZ;->A9m:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/31l;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0G:LX/31l;

    iget-object v0, v2, LX/3GZ;->AJ2:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/1bw;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0Y:LX/1bw;

    invoke-static {v2}, LX/3GZ;->A5p(LX/3GZ;)LX/34u;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0X:LX/34u;

    iget-object v0, v2, LX/3GZ;->A23:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2cZ;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0F:LX/2cZ;

    invoke-static {v2}, LX/3GZ;->A2i(LX/3GZ;)LX/34w;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0I:LX/34w;

    invoke-virtual {v2}, LX/3GZ;->AnN()LX/2xB;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0W:LX/2xB;

    iget-object v0, v2, LX/3GZ;->AbJ:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/1nw;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0b:LX/1nw;

    iget-object v0, v2, LX/3GZ;->A8m:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/0XV;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A06:LX/0XV;

    iget-object v3, v2, LX/3GZ;->A00:LX/38w;

    iget-object v0, v3, LX/38w;->ACB:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/36v;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0a:LX/36v;

    iget-object v0, v2, LX/3GZ;->AJn:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2rR;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0H:LX/2rR;

    iget-object v0, v2, LX/3GZ;->AMh:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2eL;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0S:LX/2eL;

    iget-object v0, v2, LX/3GZ;->AJf:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/31u;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0O:LX/31u;

    iget-object v0, v2, LX/3GZ;->AJh:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/33o;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0Z:LX/33o;

    iget-object v0, v2, LX/3GZ;->ALr:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/37S;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0P:LX/37S;

    iget-object v0, v3, LX/38w;->A0r:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2Ru;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A07:LX/2Ru;

    iget-object v0, v2, LX/3GZ;->AFx:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2rd;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0A:LX/2rd;

    invoke-static {v2}, LX/3GZ;->A3I(LX/3GZ;)LX/3jF;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0R:LX/3jF;

    iget-object v0, v2, LX/3GZ;->ATf:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2j0;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0E:LX/2j0;

    invoke-static {v2}, LX/3GZ;->A2p(LX/3GZ;)LX/34r;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0L:LX/34r;

    invoke-static {v2}, LX/3GZ;->A2q(LX/3GZ;)LX/354;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0M:LX/354;

    iget-object v0, v2, LX/3GZ;->AJK:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/31Q;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0N:LX/31Q;

    iget-object v0, v2, LX/3GZ;->A1w:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/0VG;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A05:LX/0VG;

    iget-object v0, v3, LX/38w;->A0u:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2hM;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A08:LX/2hM;

    iget-object v0, v2, LX/3GZ;->ALu:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2oY;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0Q:LX/2oY;

    invoke-static {v2}, LX/3GZ;->A0W(LX/3GZ;)LX/3HP;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A09:LX/3HP;

    iget-object v0, v2, LX/3GZ;->AFy:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/1c2;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0B:LX/1c2;

    iget-object v0, v2, LX/3GZ;->AG0:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/3HO;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0D:LX/3HO;

    iget-object v0, v2, LX/3GZ;->AFz:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2n4;

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0C:LX/2n4;

    invoke-static {v2}, LX/3GZ;->A43(LX/3GZ;)LX/1Pk;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0T:LX/1Pk;

    iget-object v0, v2, LX/3GZ;->AUU:LX/41P;

    invoke-static {v0}, LX/3jM;->A00(LX/41P;)LX/8oO;

    move-result-object v0

    iput-object v0, v1, Lcom/gbwhatsapp/backup/google/GoogleBackupService;->A0c:LX/8oO;

    return-void
.end method

.method public final generatedComponent()Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, LX/0yc;->A01:LX/3dr;

    if-nez v0, :cond_1

    iget-object v1, p0, LX/0yc;->A00:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    iget-object v0, p0, LX/0yc;->A01:LX/3dr;

    if-nez v0, :cond_0

    new-instance v0, LX/3dr;

    invoke-direct {v0, p0}, LX/3dr;-><init>(Landroid/app/Service;)V

    iput-object v0, p0, LX/0yc;->A01:LX/3dr;

    :cond_0
    monitor-exit v1

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    :cond_1
    :goto_0
    iget-object v0, p0, LX/0yc;->A01:LX/3dr;

    invoke-virtual {v0}, LX/3dr;->generatedComponent()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public onCreate()V
    .locals 0

    invoke-virtual {p0}, LX/0yc;->A04()V

    invoke-super {p0}, Landroid/app/IntentService;->onCreate()V

    return-void
.end method
