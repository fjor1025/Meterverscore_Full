.class public LX/11N;
.super LX/0eR;
.source ""


# instance fields
.field public final synthetic A00:LX/10y;

.field public final synthetic A01:Z


# direct methods
.method public constructor <init>(LX/10y;Z)V
    .locals 0

    iput-object p1, p0, LX/11N;->A00:LX/10y;

    iput-boolean p2, p0, LX/11N;->A01:Z

    invoke-direct {p0}, LX/0eR;-><init>()V

    return-void
.end method


# virtual methods
.method public BL8(Landroid/view/View;)V
    .locals 1

    iget-boolean v0, p0, LX/11N;->A01:Z

    invoke-static {v0}, LX/001;->A0A(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method
