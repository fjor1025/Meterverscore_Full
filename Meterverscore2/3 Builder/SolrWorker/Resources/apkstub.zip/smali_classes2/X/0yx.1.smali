.class public LX/0yx;
.super Landroid/content/BroadcastReceiver;
.source ""


# instance fields
.field public final A00:LX/8oO;


# direct methods
.method public constructor <init>(LX/8oO;)V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    iput-object p1, p0, LX/0yx;->A00:LX/8oO;

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    const-string/jumbo v1, "noPopup"

    const/4 v0, 0x1

    invoke-virtual {p2, v1, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v3

    const-string v1, "isAndroidWearRefresh"

    const/4 v0, 0x0

    invoke-virtual {p2, v1, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v2

    invoke-static {p2}, LX/38F;->A02(Landroid/content/Intent;)LX/30N;

    move-result-object v1

    iget-object v0, p0, LX/0yx;->A00:LX/8oO;

    invoke-interface {v0}, LX/8oO;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/34n;

    invoke-virtual {v0, v1, v3, v2}, LX/34n;->A0C(LX/30N;ZZ)V

    return-void
.end method
