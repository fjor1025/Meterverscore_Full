.class public LX/10W;
.super Landroid/os/HandlerThread;
.source ""


# instance fields
.field public A00:F

.field public A01:I

.field public A02:J

.field public A03:Landroid/os/Handler;

.field public A04:LX/2ni;

.field public final A05:J

.field public final A06:Landroid/os/Handler;

.field public final A07:LX/3HW;

.field public final A08:LX/3by;

.field public final A09:Lcom/gbwhatsapp/audioRecording/AudioRecordFactory;

.field public final A0A:Lcom/gbwhatsapp/audioRecording/OpusRecorderFactory;

.field public final A0B:LX/2sJ;

.field public final A0C:LX/1Pl;

.field public final A0D:Ljava/lang/ref/WeakReference;


# direct methods
.method public constructor <init>(LX/3HW;LX/3by;Lcom/gbwhatsapp/audioRecording/AudioRecordFactory;Lcom/gbwhatsapp/audioRecording/OpusRecorderFactory;LX/2sJ;LX/1Pl;LX/5ny;J)V
    .locals 2

    const-string v0, "VoiceStatusRecorderThread"

    invoke-direct {p0, v0}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    const-wide/16 v0, 0x0

    iput-wide v0, p0, LX/10W;->A02:J

    const/4 v0, 0x0

    iput v0, p0, LX/10W;->A00:F

    const/4 v0, 0x0

    iput v0, p0, LX/10W;->A01:I

    iput-object p5, p0, LX/10W;->A0B:LX/2sJ;

    iput-object p6, p0, LX/10W;->A0C:LX/1Pl;

    iput-object p2, p0, LX/10W;->A08:LX/3by;

    iput-object p1, p0, LX/10W;->A07:LX/3HW;

    iput-wide p8, p0, LX/10W;->A05:J

    iput-object p3, p0, LX/10W;->A09:Lcom/gbwhatsapp/audioRecording/AudioRecordFactory;

    iput-object p4, p0, LX/10W;->A0A:Lcom/gbwhatsapp/audioRecording/OpusRecorderFactory;

    invoke-static {p7}, LX/0yT;->A1A(Ljava/lang/Object;)Ljava/lang/ref/WeakReference;

    move-result-object v0

    iput-object v0, p0, LX/10W;->A0D:Ljava/lang/ref/WeakReference;

    invoke-static {}, LX/000;->A0B()Landroid/os/Handler;

    move-result-object v0

    iput-object v0, p0, LX/10W;->A06:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method public A00()V
    .locals 4

    iget-object v0, p0, LX/10W;->A03:Landroid/os/Handler;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Ljava/lang/Thread;->start()V

    invoke-virtual {p0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    new-instance v2, Landroid/os/Handler;

    invoke-direct {v2, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v2, p0, LX/10W;->A03:Landroid/os/Handler;

    const/16 v1, 0x16

    new-instance v0, LX/3hT;

    invoke-direct {v0, p0, v1}, LX/3hT;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    iget-object v3, p0, LX/10W;->A03:Landroid/os/Handler;

    const/16 v0, 0x17

    new-instance v2, LX/3hT;

    invoke-direct {v2, p0, v0}, LX/3hT;-><init>(Ljava/lang/Object;I)V

    const-wide/16 v0, 0x10

    invoke-virtual {v3, v2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    iget-object v2, p0, LX/10W;->A03:Landroid/os/Handler;

    const/16 v1, 0x18

    new-instance v0, LX/3hT;

    invoke-direct {v0, p0, v1}, LX/3hT;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    iget-object v3, p0, LX/10W;->A03:Landroid/os/Handler;

    const/16 v0, 0x19

    new-instance v2, LX/3hT;

    invoke-direct {v2, p0, v0}, LX/3hT;-><init>(Ljava/lang/Object;I)V

    iget-wide v0, p0, LX/10W;->A05:J

    invoke-virtual {v3, v2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-void
.end method

.method public final A01(Z)V
    .locals 3

    iget-object v2, p0, LX/10W;->A04:LX/2ni;

    if-nez v2, :cond_0

    return-void

    :cond_0
    :try_start_0
    iget-object v0, v2, LX/2ni;->A06:Lcom/whatsapp/util/OpusRecorder;

    invoke-virtual {v0}, Lcom/whatsapp/util/OpusRecorder;->stop()V

    invoke-virtual {v0}, Lcom/whatsapp/util/OpusRecorder;->getPageNumber()J

    move-result-wide v0

    iput-wide v0, v2, LX/2ni;->A01:J

    iget-object v0, p0, LX/10W;->A04:LX/2ni;

    invoke-virtual {v0}, LX/2ni;->A01()V

    iget-object v1, p0, LX/10W;->A04:LX/2ni;

    invoke-virtual {v1}, LX/2ni;->A02()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, v1, LX/2ni;->A0D:Ljava/io/FileOutputStream;

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V

    :cond_1
    if-eqz p1, :cond_2

    iget-object v0, p0, LX/10W;->A04:LX/2ni;

    if-eqz v0, :cond_2

    iget-object v1, v0, LX/2ni;->A09:Ljava/io/File;

    iget-object v0, v0, LX/2ni;->A08:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    :cond_2
    iget-object v1, p0, LX/10W;->A04:LX/2ni;

    iget-object v0, v1, LX/2ni;->A06:Lcom/whatsapp/util/OpusRecorder;

    invoke-virtual {v0}, Lcom/whatsapp/util/OpusRecorder;->close()V

    iget-object v0, v1, LX/2ni;->A03:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v0, 0x0

    iput-object v0, p0, LX/10W;->A04:LX/2ni;

    invoke-virtual {p0}, Landroid/os/HandlerThread;->quit()Z

    invoke-virtual {p0}, Ljava/lang/Thread;->interrupt()V

    return-void
.end method
