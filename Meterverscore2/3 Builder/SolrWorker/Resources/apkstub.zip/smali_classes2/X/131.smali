.class public LX/131;
.super LX/0Ve;
.source ""

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final A00:Landroid/view/View;

.field public final A01:Landroid/view/View;

.field public final A02:Landroid/widget/ImageView;

.field public final A03:Landroid/widget/TextView;

.field public final A04:Lcom/gbwhatsapp/components/SelectionCheckView;

.field public final synthetic A05:LX/12l;


# direct methods
.method public constructor <init>(Landroid/view/View;LX/12l;)V
    .locals 1

    iput-object p2, p0, LX/131;->A05:LX/12l;

    invoke-direct {p0, p1}, LX/0Ve;-><init>(Landroid/view/View;)V

    iput-object p1, p0, LX/131;->A01:Landroid/view/View;

    const v0, 0x7f0b0aec

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, LX/131;->A00:Landroid/view/View;

    const v0, 0x7f0b0aed

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, LX/131;->A02:Landroid/widget/ImageView;

    const v0, 0x7f0b17ff

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/gbwhatsapp/components/SelectionCheckView;

    iput-object v0, p0, LX/131;->A04:Lcom/gbwhatsapp/components/SelectionCheckView;

    const v0, 0x7f0b0ae6

    invoke-static {p1, v0}, LX/0yR;->A0O(Landroid/view/View;I)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, LX/131;->A03:Landroid/widget/TextView;

    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5

    invoke-virtual {p0}, LX/0Ve;->A01()I

    move-result v4

    const/4 v0, -0x1

    if-eq v4, v0, :cond_0

    if-lez v4, :cond_1

    iget-object v0, p0, LX/131;->A05:LX/12l;

    iget-object v1, v0, LX/12l;->A01:[Landroid/graphics/Bitmap;

    add-int/lit8 v0, v4, -0x1

    aget-object v0, v1, v0

    if-nez v0, :cond_1

    :cond_0
    return-void

    :cond_1
    iget-object v0, p0, LX/131;->A05:LX/12l;

    iget-object v3, v0, LX/12l;->A09:LX/5Y8;

    iget v0, v3, LX/5Y8;->A01:I

    if-eq v4, v0, :cond_0

    const/16 v0, 0x27

    new-instance v2, LX/3ht;

    invoke-direct {v2, p0, v4, v0}, LX/3ht;-><init>(Ljava/lang/Object;II)V

    const/16 v1, 0x28

    new-instance v0, LX/3ht;

    invoke-direct {v0, p0, v4, v1}, LX/3ht;-><init>(Ljava/lang/Object;II)V

    invoke-virtual {v3, v2, v0, v4}, LX/5Y8;->A05(Ljava/lang/Runnable;Ljava/lang/Runnable;I)V

    return-void
.end method
