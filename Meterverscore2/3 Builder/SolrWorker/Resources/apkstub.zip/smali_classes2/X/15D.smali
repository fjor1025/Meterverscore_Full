.class public final LX/15D;
.super LX/3eJ;
.source ""


# instance fields
.field public A00:I

.field public final synthetic A01:LX/15F;


# direct methods
.method public constructor <init>(LX/15F;)V
    .locals 0

    iput-object p1, p0, LX/15D;->A01:LX/15F;

    invoke-direct {p0}, LX/3eJ;-><init>()V

    return-void
.end method
