.class public LX/112;
.super LX/0Nr;
.source ""


# instance fields
.field public final synthetic A00:LX/1b1;

.field public final synthetic A01:LX/2SH;


# direct methods
.method public constructor <init>(LX/1b1;LX/2SH;)V
    .locals 1

    const/4 v0, 0x1

    iput-object p1, p0, LX/112;->A00:LX/1b1;

    iput-object p2, p0, LX/112;->A01:LX/2SH;

    invoke-direct {p0, v0}, LX/0Nr;-><init>(Z)V

    return-void
.end method


# virtual methods
.method public A00()V
    .locals 1

    iget-object v0, p0, LX/112;->A01:LX/2SH;

    iget-object v0, v0, LX/2SH;->A0D:LX/3zx;

    if-eqz v0, :cond_0

    invoke-interface {v0}, LX/3zx;->BpU()V

    return-void

    :cond_0
    iget-object v0, p0, LX/112;->A00:LX/1b1;

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    return-void
.end method
