.class public LX/12H;
.super LX/0V7;
.source ""


# instance fields
.field public final A00:LX/08P;

.field public final A01:LX/3by;

.field public final A02:LX/2sr;

.field public final A03:LX/2so;

.field public final A04:LX/2xt;

.field public final A05:LX/2sI;

.field public final A06:LX/1cw;

.field public final A07:LX/44Y;

.field public final A08:LX/1c6;

.field public final A09:LX/2ss;

.field public final A0A:LX/44p;

.field public final A0B:LX/1bz;

.field public final A0C:LX/2rV;

.field public final A0D:LX/458;

.field public final A0E:LX/1cx;

.field public final A0F:LX/1Pl;

.field public final A0G:LX/2qc;

.field public final A0H:LX/1cd;

.field public final A0I:LX/2rg;

.field public final A0J:LX/1cp;

.field public final A0K:LX/2kw;

.field public final A0L:LX/11a;

.field public final A0M:LX/11a;

.field public final A0N:LX/3iy;

.field public final A0O:LX/4LC;

.field public final A0P:LX/4LC;

.field public final A0Q:Ljava/util/Comparator;

.field public final A0R:Ljava/util/Comparator;

.field public final A0S:Ljava/util/Map;

.field public final A0T:Ljava/util/Map;

.field public final A0U:LX/8wI;

.field public final A0V:LX/8wI;

.field public final A0W:LX/8wI;


# direct methods
.method public constructor <init>(LX/3by;LX/2sr;LX/2so;LX/1cw;LX/1c6;LX/2ss;LX/1bz;LX/2rV;LX/1cx;LX/1Pl;LX/1cd;LX/1cp;LX/2rL;LX/2kw;LX/454;)V
    .locals 5

    invoke-direct {p0}, LX/0V7;-><init>()V

    invoke-static {}, LX/0yU;->A0H()LX/4LC;

    move-result-object v0

    iput-object v0, p0, LX/12H;->A0O:LX/4LC;

    invoke-static {}, LX/0yU;->A0H()LX/4LC;

    move-result-object v0

    iput-object v0, p0, LX/12H;->A0P:LX/4LC;

    invoke-static {}, LX/0yT;->A1C()Ljava/util/LinkedHashMap;

    move-result-object v0

    iput-object v0, p0, LX/12H;->A0S:Ljava/util/Map;

    invoke-static {}, LX/001;->A0y()Ljava/util/HashMap;

    move-result-object v0

    iput-object v0, p0, LX/12H;->A0T:Ljava/util/Map;

    const/4 v2, 0x0

    new-instance v0, LX/48s;

    invoke-direct {v0, p0, v2}, LX/48s;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, LX/12H;->A07:LX/44Y;

    const/4 v3, 0x1

    new-instance v0, LX/46b;

    invoke-direct {v0, p0, v3}, LX/46b;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, LX/12H;->A0I:LX/2rg;

    const/4 v1, 0x2

    new-instance v0, LX/46a;

    invoke-direct {v0, p0, v1}, LX/46a;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, LX/12H;->A0G:LX/2qc;

    new-instance v0, LX/48r;

    invoke-direct {v0, p0, v3}, LX/48r;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, LX/12H;->A0D:LX/458;

    const/4 v3, 0x4

    new-instance v0, LX/47Q;

    invoke-direct {v0, p0, v3}, LX/47Q;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, LX/12H;->A0A:LX/44p;

    const/4 v1, 0x3

    new-instance v0, LX/46V;

    invoke-direct {v0, p0, v1}, LX/46V;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, LX/12H;->A05:LX/2sI;

    new-instance v0, LX/49C;

    invoke-direct {v0, p0, v3}, LX/49C;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, LX/12H;->A0V:LX/8wI;

    const/4 v1, 0x5

    new-instance v0, LX/49C;

    invoke-direct {v0, p0, v1}, LX/49C;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, LX/12H;->A0W:LX/8wI;

    const/4 v1, 0x6

    new-instance v0, LX/49C;

    invoke-direct {v0, p0, v1}, LX/49C;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, LX/12H;->A0U:LX/8wI;

    iput-object p10, p0, LX/12H;->A0F:LX/1Pl;

    iput-object p1, p0, LX/12H;->A01:LX/3by;

    iput-object p2, p0, LX/12H;->A02:LX/2sr;

    iput-object p6, p0, LX/12H;->A09:LX/2ss;

    new-instance v0, LX/3iy;

    move-object/from16 v1, p15

    invoke-direct {v0, v1, v2}, LX/3iy;-><init>(LX/454;Z)V

    iput-object v0, p0, LX/12H;->A0N:LX/3iy;

    iput-object p4, p0, LX/12H;->A06:LX/1cw;

    iput-object p8, p0, LX/12H;->A0C:LX/2rV;

    iput-object p9, p0, LX/12H;->A0E:LX/1cx;

    move-object/from16 v0, p14

    iput-object v0, p0, LX/12H;->A0K:LX/2kw;

    iput-object p5, p0, LX/12H;->A08:LX/1c6;

    iput-object p3, p0, LX/12H;->A03:LX/2so;

    move-object/from16 v0, p12

    iput-object v0, p0, LX/12H;->A0J:LX/1cp;

    iput-object p7, p0, LX/12H;->A0B:LX/1bz;

    move-object/from16 v0, p11

    iput-object v0, p0, LX/12H;->A0H:LX/1cd;

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v1

    new-instance v0, LX/11a;

    invoke-direct {v0, v1}, LX/11a;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12H;->A0M:LX/11a;

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v0

    new-instance v4, LX/11a;

    invoke-direct {v4, v0}, LX/11a;-><init>(Ljava/lang/Object;)V

    iput-object v4, p0, LX/12H;->A0L:LX/11a;

    new-instance v0, LX/3ic;

    invoke-direct {v0, p6}, LX/3ic;-><init>(LX/2ss;)V

    iput-object v0, p0, LX/12H;->A0R:Ljava/util/Comparator;

    new-instance v0, LX/3iU;

    move-object/from16 v1, p13

    invoke-direct {v0, p6, v1}, LX/3iU;-><init>(LX/2ss;LX/2rL;)V

    iput-object v0, p0, LX/12H;->A0Q:Ljava/util/Comparator;

    const/4 v1, 0x7

    new-instance v0, LX/49C;

    invoke-direct {v0, p0, v1}, LX/49C;-><init>(Ljava/lang/Object;I)V

    new-instance v2, LX/2xt;

    invoke-direct {v2, p7, v0}, LX/2xt;-><init>(LX/1bz;LX/8wI;)V

    iput-object v2, p0, LX/12H;->A04:LX/2xt;

    new-instance v3, LX/08P;

    invoke-direct {v3}, LX/08P;-><init>()V

    iput-object v3, p0, LX/12H;->A00:LX/08P;

    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x24

    new-instance v0, LX/49I;

    invoke-direct {v0, v3, v1}, LX/49I;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v3, v4, v0}, LX/08P;->A0I(LX/0Y8;LX/0t5;)V

    iget-object v2, v2, LX/2xt;->A04:LX/11a;

    const/16 v1, 0x25

    new-instance v0, LX/49I;

    invoke-direct {v0, p0, v1}, LX/49I;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v3, v2, v0}, LX/08P;->A0I(LX/0Y8;LX/0t5;)V

    return-void
.end method


# virtual methods
.method public A0F()V
    .locals 2

    iget-object v1, p0, LX/12H;->A0B:LX/1bz;

    iget-object v0, p0, LX/12H;->A0A:LX/44p;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    iget-object v1, p0, LX/12H;->A08:LX/1c6;

    iget-object v0, p0, LX/12H;->A07:LX/44Y;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    iget-object v1, p0, LX/12H;->A0J:LX/1cp;

    iget-object v0, p0, LX/12H;->A0I:LX/2rg;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    iget-object v1, p0, LX/12H;->A0E:LX/1cx;

    iget-object v0, p0, LX/12H;->A0D:LX/458;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    iget-object v1, p0, LX/12H;->A0H:LX/1cd;

    iget-object v0, p0, LX/12H;->A0G:LX/2qc;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    iget-object v1, p0, LX/12H;->A06:LX/1cw;

    iget-object v0, p0, LX/12H;->A05:LX/2sI;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    iget-object v0, p0, LX/12H;->A04:LX/2xt;

    iget-object v1, v0, LX/2xt;->A03:LX/1bz;

    iget-object v0, v0, LX/2xt;->A02:LX/44p;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    return-void
.end method

.method public final A0G(LX/31w;)Ljava/util/List;
    .locals 4

    iget-object v0, p0, LX/12H;->A0S:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/List;

    if-eqz v3, :cond_0

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/31w;

    iget-object v1, p0, LX/12H;->A0T:Ljava/util/Map;

    invoke-virtual {v0}, LX/31w;->A05()LX/1ZJ;

    move-result-object v0

    invoke-static {v0}, LX/33R;->A00(Lcom/whatsapp/jid/Jid;)Lcom/whatsapp/jid/GroupJid;

    move-result-object v0

    invoke-interface {v1, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_0
    return-object v3
.end method

.method public final A0H(LX/31w;Ljava/util/Map;)Ljava/util/List;
    .locals 5

    iget-object v1, p0, LX/12H;->A03:LX/2so;

    invoke-virtual {p1}, LX/31w;->A05()LX/1ZJ;

    move-result-object v0

    invoke-static {v0}, LX/35n;->A01(Lcom/whatsapp/jid/Jid;)LX/1ZI;

    move-result-object v0

    invoke-virtual {v1, v0}, LX/2so;->A04(LX/1ZI;)Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    const/4 v4, 0x0

    if-nez v0, :cond_2

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v3

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {v2}, LX/0yR;->A0T(Ljava/util/Iterator;)LX/2py;

    move-result-object v1

    iget-object v0, p0, LX/12H;->A09:LX/2ss;

    iget-object v1, v1, LX/2py;->A02:Lcom/whatsapp/jid/GroupJid;

    invoke-static {v0, v1}, LX/2ss;->A00(LX/2ss;LX/1ZJ;)LX/31w;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {p2, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v3, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    return-object v3

    :cond_2
    return-object v4
.end method

.method public final A0I(Z)V
    .locals 20

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v3

    move-object/from16 v2, p0

    iget-object v6, v2, LX/12H;->A0S:Ljava/util/Map;

    invoke-interface {v6}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-static {v0}, LX/002;->A07(Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object v1

    iget-object v0, v2, LX/12H;->A0Q:Ljava/util/Comparator;

    invoke-static {v1, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    invoke-virtual {v1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_0
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, LX/31w;

    invoke-static {v14, v6}, LX/0yS;->A0c(Ljava/lang/Object;Ljava/util/Map;)Ljava/util/List;

    move-result-object v8

    invoke-virtual {v14}, LX/31w;->A05()LX/1ZJ;

    move-result-object v0

    invoke-static {v0}, LX/33R;->A00(Lcom/whatsapp/jid/Jid;)Lcom/whatsapp/jid/GroupJid;

    move-result-object v1

    if-eqz v1, :cond_0

    if-eqz v8, :cond_0

    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    iget-object v0, v2, LX/12H;->A04:LX/2xt;

    iget-object v0, v0, LX/2xt;->A01:Ljava/util/Set;

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object v5, v2, LX/12H;->A04:LX/2xt;

    iget-object v0, v5, LX/2xt;->A01:Ljava/util/Set;

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {v14}, LX/31w;->A05()LX/1ZJ;

    move-result-object v0

    invoke-static {v0}, LX/33R;->A01(Lcom/whatsapp/jid/Jid;)Lcom/whatsapp/jid/GroupJid;

    move-result-object v15

    if-nez v15, :cond_2

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v7

    :goto_1
    invoke-virtual {v3, v7}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    :cond_2
    const/16 v18, 0x1

    const/4 v0, 0x3

    new-instance v4, LX/20B;

    invoke-direct {v4, v5, v0}, LX/20B;-><init>(Ljava/lang/Object;I)V

    const/4 v0, 0x4

    new-instance v1, LX/20B;

    invoke-direct {v1, v5, v0}, LX/20B;-><init>(Ljava/lang/Object;I)V

    iget-object v0, v5, LX/2xt;->A00:LX/2jM;

    iget-object v0, v0, LX/2jM;->A00:Ljava/util/Set;

    invoke-static {v0, v15}, LX/3lF;->A0T(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v19

    new-instance v13, LX/2ma;

    move-object/from16 v16, v4

    move-object/from16 v17, v1

    invoke-direct/range {v13 .. v19}, LX/2ma;-><init>(LX/31w;Lcom/whatsapp/jid/GroupJid;LX/8wI;LX/8wI;ZZ)V

    const/16 v1, 0x8

    new-instance v0, LX/5QD;

    invoke-direct {v0, v15, v13, v1}, LX/5QD;-><init>(LX/1ZJ;Ljava/lang/Object;I)V

    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v7

    goto :goto_1

    :cond_3
    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v14}, LX/31w;->A05()LX/1ZJ;

    move-result-object v0

    invoke-static {v0}, LX/33R;->A01(Lcom/whatsapp/jid/Jid;)Lcom/whatsapp/jid/GroupJid;

    move-result-object v15

    if-eqz v15, :cond_4

    const/16 v18, 0x0

    iget-object v1, v2, LX/12H;->A0V:LX/8wI;

    iget-object v0, v2, LX/12H;->A0W:LX/8wI;

    new-instance v13, LX/2ma;

    move-object/from16 v16, v1

    move-object/from16 v17, v0

    move/from16 v19, v18

    invoke-direct/range {v13 .. v19}, LX/2ma;-><init>(LX/31w;Lcom/whatsapp/jid/GroupJid;LX/8wI;LX/8wI;ZZ)V

    const/16 v1, 0x8

    new-instance v0, LX/5QD;

    invoke-direct {v0, v15, v13, v1}, LX/5QD;-><init>(LX/1ZJ;Ljava/lang/Object;I)V

    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_4
    iget-object v4, v2, LX/12H;->A0C:LX/2rV;

    invoke-virtual {v14}, LX/31w;->A05()LX/1ZJ;

    move-result-object v1

    const/4 v0, 0x1

    invoke-virtual {v4, v1, v0}, LX/2rV;->A02(LX/1ZJ;Z)LX/36P;

    move-result-object v11

    const/4 v9, 0x0

    if-eqz v11, :cond_5

    iget-object v0, v2, LX/12H;->A02:LX/2sr;

    invoke-static {v0, v11}, LX/38s;->A0S(LX/2sr;LX/36P;)Z

    move-result v0

    if-eqz v0, :cond_5

    monitor-enter v14

    :try_start_0
    iget-wide v4, v14, LX/31w;->A0K:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v14

    monitor-enter v14

    :try_start_1
    iget-wide v0, v14, LX/31w;->A0J:J

    goto :goto_2

    :cond_5
    const/4 v10, 0x0

    goto :goto_3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_2
    monitor-exit v14

    cmp-long v10, v4, v0

    if-ltz v10, :cond_5

    iget-object v0, v2, LX/12H;->A0U:LX/8wI;

    new-instance v5, LX/2jI;

    invoke-direct {v5, v11, v0}, LX/2jI;-><init>(LX/36P;LX/8wI;)V

    invoke-virtual {v11}, LX/36P;->A0m()LX/1ZJ;

    move-result-object v4

    const/16 v1, 0xd

    new-instance v0, LX/5QD;

    invoke-direct {v0, v4, v5, v1}, LX/5QD;-><init>(LX/1ZJ;Ljava/lang/Object;I)V

    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x1

    :goto_3
    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v0

    if-ge v9, v0, :cond_6

    const/4 v0, 0x3

    if-ge v10, v0, :cond_6

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LX/31w;

    invoke-virtual {v4}, LX/31w;->A05()LX/1ZJ;

    move-result-object v1

    const/4 v0, 0x2

    new-instance v5, LX/501;

    invoke-direct {v5, v1, v0}, LX/501;-><init>(LX/1ZJ;I)V

    invoke-virtual {v4}, LX/31w;->A05()LX/1ZJ;

    move-result-object v4

    const/4 v1, 0x4

    new-instance v0, LX/5QD;

    invoke-direct {v0, v4, v5, v1}, LX/5QD;-><init>(LX/1ZJ;Ljava/lang/Object;I)V

    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v10, 0x1

    add-int/lit8 v9, v9, 0x1

    goto :goto_3

    :cond_6
    const/16 v4, 0x9

    invoke-virtual {v14}, LX/31w;->A05()LX/1ZJ;

    move-result-object v1

    new-instance v0, LX/5QD;

    invoke-direct {v0, v1, v14, v4}, LX/5QD;-><init>(LX/1ZJ;Ljava/lang/Object;I)V

    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto/16 :goto_1

    :catchall_0
    move-exception v0

    monitor-exit v14

    throw v0

    :cond_7
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    const/4 v5, 0x0

    if-eqz v0, :cond_9

    iget-object v4, v2, LX/12H;->A0F:LX/1Pl;

    const/16 v0, 0x3d6

    sget-object v1, LX/2vP;->A02:LX/2vP;

    invoke-virtual {v4, v1, v0}, LX/2sp;->A0W(LX/2vP;I)Z

    move-result v0

    if-eqz v0, :cond_8

    const/16 v0, 0x15a7

    invoke-virtual {v4, v1, v0}, LX/2sp;->A0W(LX/2vP;I)Z

    move-result v0

    if-nez v0, :cond_8

    const/4 v0, 0x7

    new-instance v1, LX/5QD;

    invoke-direct {v1, v5, v5, v0}, LX/5QD;-><init>(LX/1ZJ;Ljava/lang/Object;I)V

    const/4 v0, 0x0

    invoke-virtual {v3, v0, v1}, Ljava/util/AbstractList;->add(ILjava/lang/Object;)V

    :cond_8
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_a

    :cond_9
    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v3

    const/16 v1, 0xa

    new-instance v0, LX/5QD;

    invoke-direct {v0, v5, v5, v1}, LX/5QD;-><init>(LX/1ZJ;Ljava/lang/Object;I)V

    invoke-virtual {v3, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_a
    iget-object v0, v2, LX/12H;->A0M:LX/11a;

    invoke-virtual {v0, v3}, LX/0Y8;->A0F(Ljava/lang/Object;)V

    if-eqz p1, :cond_b

    iget-object v0, v2, LX/12H;->A0L:LX/11a;

    invoke-virtual {v0, v3}, LX/0Y8;->A0F(Ljava/lang/Object;)V

    :cond_b
    return-void
.end method

.method public final A0J(LX/1ZJ;)Z
    .locals 5

    instance-of v0, p1, LX/1ZI;

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    iget-object v1, p0, LX/12H;->A0S:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {v1}, LX/000;->A0n(Ljava/util/Map;)Ljava/util/Iterator;

    move-result-object v3

    :cond_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {v3}, LX/001;->A14(Ljava/util/Iterator;)Ljava/util/Map$Entry;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LX/31w;

    invoke-virtual {v2}, LX/31w;->A05()LX/1ZJ;

    move-result-object v1

    instance-of v0, v1, LX/1ZI;

    if-eqz v0, :cond_0

    invoke-virtual {p1, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0, v2}, LX/12H;->A0G(LX/31w;)Ljava/util/List;

    const/4 v0, 0x1

    return v0

    :cond_1
    return v4
.end method
