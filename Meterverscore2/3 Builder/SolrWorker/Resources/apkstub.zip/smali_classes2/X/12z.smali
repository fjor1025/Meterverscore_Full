.class public LX/12z;
.super LX/0Ve;
.source ""


# instance fields
.field public A00:LX/2hi;

.field public A01:LX/3ep;

.field public final A02:Landroid/widget/PopupMenu;

.field public final A03:LX/3by;

.field public final A04:LX/2sr;

.field public final A05:LX/5YE;

.field public final A06:Lcom/gbwhatsapp/WaImageView;

.field public final A07:Lcom/gbwhatsapp/WaImageView;

.field public final A08:Lcom/gbwhatsapp/WaTextView;

.field public final A09:Lcom/gbwhatsapp/WaTextView;

.field public final A0A:LX/6Dk;

.field public final A0B:Lcom/gbwhatsapp/components/button/ThumbnailButton;

.field public final A0C:LX/5Uu;

.field public final A0D:LX/2sJ;

.field public final A0E:LX/2sa;

.field public final A0F:LX/3Qa;

.field public final A0G:LX/30u;

.field public final A0H:LX/2rl;

.field public final A0I:LX/2q7;

.field public final A0J:LX/2i0;

.field public final A0K:LX/1Pl;

.field public final A0L:LX/36j;

.field public final A0M:LX/2pv;

.field public final A0N:LX/454;

.field public final A0O:LX/8oO;


# direct methods
.method public constructor <init>(Landroid/view/View;LX/3by;LX/2sr;LX/69Q;LX/6Dk;LX/5Uu;LX/2sJ;LX/2sa;LX/3Qa;LX/30u;LX/2rl;LX/2q7;LX/2i0;LX/1Pl;LX/36j;LX/2pv;LX/454;LX/8oO;)V
    .locals 3

    invoke-direct {p0, p1}, LX/0Ve;-><init>(Landroid/view/View;)V

    iput-object p6, p0, LX/12z;->A0C:LX/5Uu;

    iput-object p7, p0, LX/12z;->A0D:LX/2sJ;

    move-object/from16 v0, p14

    iput-object v0, p0, LX/12z;->A0K:LX/1Pl;

    iput-object p2, p0, LX/12z;->A03:LX/3by;

    iput-object p3, p0, LX/12z;->A04:LX/2sr;

    move-object/from16 v0, p17

    iput-object v0, p0, LX/12z;->A0N:LX/454;

    iput-object p5, p0, LX/12z;->A0A:LX/6Dk;

    iput-object p10, p0, LX/12z;->A0G:LX/30u;

    move-object/from16 v0, p16

    iput-object v0, p0, LX/12z;->A0M:LX/2pv;

    iput-object p8, p0, LX/12z;->A0E:LX/2sa;

    move-object/from16 v0, p15

    iput-object v0, p0, LX/12z;->A0L:LX/36j;

    iput-object p9, p0, LX/12z;->A0F:LX/3Qa;

    iput-object p12, p0, LX/12z;->A0I:LX/2q7;

    iput-object p11, p0, LX/12z;->A0H:LX/2rl;

    move-object/from16 v0, p13

    iput-object v0, p0, LX/12z;->A0J:LX/2i0;

    move-object/from16 v0, p18

    iput-object v0, p0, LX/12z;->A0O:LX/8oO;

    const v0, 0x7f0b1707

    invoke-static {p1, v0}, LX/0yT;->A0N(Landroid/view/View;I)Lcom/gbwhatsapp/WaTextView;

    move-result-object v0

    iput-object v0, p0, LX/12z;->A09:Lcom/gbwhatsapp/WaTextView;

    const v0, 0x7f0b1706

    invoke-static {p1, v0}, LX/0yT;->A0N(Landroid/view/View;I)Lcom/gbwhatsapp/WaTextView;

    move-result-object v0

    iput-object v0, p0, LX/12z;->A08:Lcom/gbwhatsapp/WaTextView;

    const v0, 0x7f0b0469

    invoke-static {p1, v0}, LX/0Zj;->A02(Landroid/view/View;I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/gbwhatsapp/WaImageView;

    iput-object v0, p0, LX/12z;->A06:Lcom/gbwhatsapp/WaImageView;

    const v0, 0x7f0b067c

    invoke-static {p1, v0}, LX/0Zj;->A02(Landroid/view/View;I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/gbwhatsapp/components/button/ThumbnailButton;

    iput-object v0, p0, LX/12z;->A0B:Lcom/gbwhatsapp/components/button/ThumbnailButton;

    const v0, 0x7f0b06c8

    invoke-static {p1, v0}, LX/0Zj;->A02(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/gbwhatsapp/WaImageView;

    iput-object v2, p0, LX/12z;->A07:Lcom/gbwhatsapp/WaImageView;

    const v0, 0x7f0b1704

    invoke-static {p1, p4, v0}, LX/5YE;->A00(Landroid/view/View;LX/69Q;I)LX/5YE;

    move-result-object v0

    iput-object v0, p0, LX/12z;->A05:LX/5YE;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    new-instance v0, Landroid/widget/PopupMenu;

    invoke-direct {v0, v1, v2}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    iput-object v0, p0, LX/12z;->A02:Landroid/widget/PopupMenu;

    return-void
.end method


# virtual methods
.method public final A07(Landroid/content/Context;)V
    .locals 4

    iget-object v0, p0, LX/12z;->A00:LX/2hi;

    if-nez v0, :cond_0

    const-string v0, "UpcomingActivityCallViewHolder/openPrecallLobby schedule call null"

    :goto_0
    invoke-static {v0}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    return-void

    :cond_0
    iget-object v0, v0, LX/2hi;->A04:LX/1ZJ;

    invoke-static {v0}, LX/35n;->A01(Lcom/whatsapp/jid/Jid;)LX/1ZI;

    move-result-object v3

    if-nez v3, :cond_1

    const-string v0, "UpcomingActivityCallViewHolder/openPrecallLobby group jid is null"

    goto :goto_0

    :cond_1
    iget-object v2, p0, LX/12z;->A0N:LX/454;

    const/16 v1, 0xe

    new-instance v0, LX/3fg;

    invoke-direct {v0, p0, p1, v3, v1}, LX/3fg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {v2, v0}, LX/454;->Bit(Ljava/lang/Runnable;)V

    return-void
.end method

.method public A08(LX/3IR;)V
    .locals 7

    iget-object v4, p1, LX/3IR;->A00:LX/2f1;

    iget-object v2, p1, LX/3IR;->A02:LX/3ep;

    iput-object v2, p0, LX/12z;->A01:LX/3ep;

    iget-object v0, p1, LX/3IR;->A01:LX/2hi;

    iput-object v0, p0, LX/12z;->A00:LX/2hi;

    iget-object v1, p0, LX/12z;->A0C:LX/5Uu;

    iget-object v0, p0, LX/12z;->A0B:Lcom/gbwhatsapp/components/button/ThumbnailButton;

    invoke-virtual {v1, v0, v2}, LX/5Uu;->A08(Landroid/widget/ImageView;LX/3ep;)V

    iget-object v1, p0, LX/12z;->A09:Lcom/gbwhatsapp/WaTextView;

    iget-object v0, p0, LX/12z;->A00:LX/2hi;

    iget-object v0, v0, LX/2hi;->A06:Ljava/lang/String;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, LX/12z;->A05:LX/5YE;

    invoke-virtual {v0, v2}, LX/5YE;->A08(LX/3ep;)V

    iget-object v1, p0, LX/12z;->A08:Lcom/gbwhatsapp/WaTextView;

    iget-object v0, v4, LX/2f1;->A01:Ljava/lang/String;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, p0, LX/12z;->A06:Lcom/gbwhatsapp/WaImageView;

    iget-object v3, p0, LX/0Ve;->A0H:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    iget v0, v4, LX/2f1;->A00:I

    invoke-static {v1, v2, v0}, LX/0yS;->A0k(Landroid/content/Context;Landroid/widget/ImageView;I)V

    iget-boolean v2, v4, LX/2f1;->A02:Z

    iget-object v6, p0, LX/12z;->A02:Landroid/widget/PopupMenu;

    invoke-virtual {v6}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/Menu;->clear()V

    invoke-virtual {v6}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    const v0, 0x7f121c1e

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-interface {v1, v5, v5, v4, v0}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    if-eqz v2, :cond_0

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const v0, 0x7f12053f

    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Landroid/text/SpannableString;

    invoke-direct {v2, v0}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    const/high16 v0, -0x10000

    new-instance v1, Landroid/text/style/ForegroundColorSpan;

    invoke-direct {v1, v0}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    invoke-virtual {v2}, Landroid/text/SpannableString;->length()I

    move-result v0

    invoke-virtual {v2, v1, v5, v0, v5}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    invoke-virtual {v6}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    const/4 v0, 0x2

    invoke-interface {v1, v5, v4, v0, v2}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    :cond_0
    new-instance v0, LX/3Ci;

    invoke-direct {v0, p0}, LX/3Ci;-><init>(LX/12z;)V

    invoke-virtual {v6, v0}, Landroid/widget/PopupMenu;->setOnMenuItemClickListener(Landroid/widget/PopupMenu$OnMenuItemClickListener;)V

    iget-object v2, p0, LX/12z;->A07:Lcom/gbwhatsapp/WaImageView;

    const/16 v1, 0x30

    new-instance v0, LX/5dj;

    invoke-direct {v0, p0, v1}, LX/5dj;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v2, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x31

    new-instance v0, LX/5dj;

    invoke-direct {v0, p0, v1}, LX/5dj;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v3, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public final A09(Landroid/view/MenuItem;)Z
    .locals 9

    iget-object v0, p0, LX/0Ve;->A0H:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    const/4 v7, 0x0

    if-nez v8, :cond_0

    const-string v0, "UpcomingActivityCallViewHolder/onPopupMenuItemClickListener context null"

    :goto_0
    invoke-static {v0}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    return v7

    :cond_0
    iget-object v0, p0, LX/12z;->A01:LX/3ep;

    if-eqz v0, :cond_1

    iget-object v0, p0, LX/12z;->A00:LX/2hi;

    if-eqz v0, :cond_1

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const/4 v6, 0x1

    if-nez v0, :cond_2

    invoke-virtual {p0, v8}, LX/12z;->A07(Landroid/content/Context;)V

    return v6

    :cond_1
    const-string v0, "UpcomingActivityCallViewHolder/onPopupMenuItemClickListener contact and/or schedule call null"

    goto :goto_0

    :cond_2
    const v0, 0x7f12053f

    invoke-virtual {v8, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    new-instance v5, Landroid/text/SpannableString;

    invoke-direct {v5, v0}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    const/high16 v0, -0x10000

    new-instance v1, Landroid/text/style/ForegroundColorSpan;

    invoke-direct {v1, v0}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    invoke-virtual {v5}, Landroid/text/SpannableString;->length()I

    move-result v0

    invoke-virtual {v5, v1, v7, v0, v7}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    invoke-static {v8}, LX/5VC;->A00(Landroid/content/Context;)LX/4IM;

    move-result-object v4

    const v2, 0x7f121c0b

    new-array v1, v6, [Ljava/lang/Object;

    iget-object v0, p0, LX/12z;->A00:LX/2hi;

    iget-object v0, v0, LX/2hi;->A06:Ljava/lang/String;

    invoke-static {v8, v0, v1, v7, v2}, LX/0yP;->A0Z(Landroid/content/Context;Ljava/lang/Object;[Ljava/lang/Object;II)Ljava/lang/String;

    move-result-object v0

    iget-object v3, v4, LX/4IM;->A00:LX/0Vn;

    invoke-virtual {v3, v0}, LX/0Vn;->setTitle(Ljava/lang/CharSequence;)LX/0Vn;

    const v2, 0x7f121c0a

    new-array v1, v6, [Ljava/lang/Object;

    iget-object v0, p0, LX/12z;->A01:LX/3ep;

    invoke-virtual {v0}, LX/3ep;->A0I()Ljava/lang/String;

    move-result-object v0

    invoke-static {v8, v0, v1, v7, v2}, LX/0yP;->A0Z(Landroid/content/Context;Ljava/lang/Object;[Ljava/lang/Object;II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, LX/4IM;->A0f(Ljava/lang/CharSequence;)V

    invoke-virtual {v4, v6}, LX/4IM;->A0g(Z)V

    const v1, 0x7f122591

    const/4 v0, 0x0

    invoke-virtual {v4, v0, v1}, LX/4IM;->A0V(Landroid/content/DialogInterface$OnClickListener;I)V

    const/16 v0, 0x16

    invoke-static {p0, v0}, LX/475;->A00(Ljava/lang/Object;I)LX/475;

    move-result-object v0

    invoke-virtual {v3, v0, v5}, LX/0Vn;->A0H(Landroid/content/DialogInterface$OnClickListener;Ljava/lang/CharSequence;)LX/0Vn;

    invoke-static {v4}, LX/0yM;->A0u(LX/0Vn;)V

    return v6
.end method
