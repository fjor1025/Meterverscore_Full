.class public LX/150;
.super LX/3f8;
.source ""


# instance fields
.field public final synthetic A00:Lcom/facebook/msys/mci/DataTask;

.field public final synthetic A01:Lcom/facebook/msys/mci/NetworkSession;

.field public final synthetic A02:LX/2hf;

.field public final synthetic A03:LX/3DR;


# direct methods
.method public constructor <init>(Lcom/facebook/msys/mci/DataTask;Lcom/facebook/msys/mci/NetworkSession;LX/2hf;LX/3DR;)V
    .locals 1

    const-string v0, "StreamingUploadDataTask_initial_ask_for_data"

    iput-object p3, p0, LX/150;->A02:LX/2hf;

    iput-object p4, p0, LX/150;->A03:LX/3DR;

    iput-object p2, p0, LX/150;->A01:Lcom/facebook/msys/mci/NetworkSession;

    iput-object p1, p0, LX/150;->A00:Lcom/facebook/msys/mci/DataTask;

    invoke-direct {p0, v0}, LX/3f8;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v1, p0, LX/150;->A01:Lcom/facebook/msys/mci/NetworkSession;

    iget-object v0, p0, LX/150;->A00:Lcom/facebook/msys/mci/DataTask;

    iget-object v0, v0, Lcom/facebook/msys/mci/DataTask;->mTaskIdentifier:Ljava/lang/String;

    invoke-virtual {v1, v0}, Lcom/facebook/msys/mci/NetworkSession;->canHandleStreamingUploadUpdate(Ljava/lang/String;)V

    return-void
.end method
