.class public LX/0zr;
.super Landroid/net/ConnectivityManager$NetworkCallback;
.source ""


# instance fields
.field public final synthetic A00:LX/354;

.field public final synthetic A01:LX/42o;


# direct methods
.method public constructor <init>(LX/354;LX/42o;)V
    .locals 0

    iput-object p2, p0, LX/0zr;->A01:LX/42o;

    iput-object p1, p0, LX/0zr;->A00:LX/354;

    invoke-direct {p0}, Landroid/net/ConnectivityManager$NetworkCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onAvailable(Landroid/net/Network;)V
    .locals 1

    const-string v0, "RegistrationUtils/maybeExecuteSilentAuthRequestOnCellular/requestNetwork/cellular is available"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v0, p0, LX/0zr;->A01:LX/42o;

    invoke-interface {v0, p1}, LX/42o;->BLn(Landroid/net/Network;)V

    return-void
.end method

.method public onUnavailable()V
    .locals 2

    const-string v0, "RegistrationUtils/maybeExecuteSilentAuthRequestOnCellular/requestNetwork/cellular network is unavailable"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->e(Ljava/lang/String;)V

    iget-object v1, p0, LX/0zr;->A00:LX/354;

    const-string/jumbo v0, "silent_auth_no_cellular"

    invoke-virtual {v1, v0}, LX/354;->A0w(Ljava/lang/String;)V

    iget-object v0, p0, LX/0zr;->A01:LX/42o;

    invoke-interface {v0}, LX/42o;->BdS()V

    return-void
.end method
