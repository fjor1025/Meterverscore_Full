.class public LX/12m;
.super LX/0S8;
.source ""


# instance fields
.field public final A00:LX/0t3;

.field public final A01:LX/3by;

.field public final A02:LX/2sr;

.field public final A03:LX/5Ue;

.field public final A04:LX/3J5;

.field public final A05:LX/352;

.field public final A06:LX/31S;

.field public final A07:LX/34x;

.field public final A08:LX/2ah;

.field public final A09:LX/11u;

.field public final A0A:LX/3iy;


# direct methods
.method public constructor <init>(LX/0t3;LX/3by;LX/2sr;LX/5Ue;LX/3J5;LX/352;LX/31S;LX/34x;LX/2ah;LX/11u;LX/3iy;)V
    .locals 2

    invoke-direct {p0}, LX/0S8;-><init>()V

    iput-object p2, p0, LX/12m;->A01:LX/3by;

    iput-object p3, p0, LX/12m;->A02:LX/2sr;

    iput-object p4, p0, LX/12m;->A03:LX/5Ue;

    iput-object p5, p0, LX/12m;->A04:LX/3J5;

    iput-object p11, p0, LX/12m;->A0A:LX/3iy;

    iput-object p6, p0, LX/12m;->A05:LX/352;

    iput-object p8, p0, LX/12m;->A07:LX/34x;

    iput-object p7, p0, LX/12m;->A06:LX/31S;

    iput-object p1, p0, LX/12m;->A00:LX/0t3;

    iput-object p9, p0, LX/12m;->A08:LX/2ah;

    iput-object p10, p0, LX/12m;->A09:LX/11u;

    iget-object v1, p9, LX/2ah;->A02:LX/11a;

    const/16 v0, 0x69

    invoke-static {p1, v1, p0, v0}, LX/49I;->A00(LX/0t3;LX/0Y8;Ljava/lang/Object;I)V

    return-void
.end method


# virtual methods
.method public A0B()I
    .locals 1

    iget-object v0, p0, LX/12m;->A08:LX/2ah;

    iget-object v0, v0, LX/2ah;->A02:LX/11a;

    invoke-virtual {v0}, LX/0Y8;->A06()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public final A0K(LX/3ep;I)LX/2Fm;
    .locals 3

    iget-object v2, p0, LX/12m;->A05:LX/352;

    invoke-virtual {v2, p1, p2}, LX/352;->A0h(LX/3ep;I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, LX/12m;->A09:LX/11u;

    iget-boolean v0, v0, LX/11u;->A0B:Z

    if-eqz v0, :cond_0

    iget-object v1, p0, LX/12m;->A07:LX/34x;

    invoke-static {p1}, LX/3ep;->A02(LX/3ep;)LX/1ZJ;

    move-result-object v0

    invoke-static {v0}, LX/37z;->A03(LX/1ZJ;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, LX/34x;->A0J(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    sget-object v1, LX/1v1;->A08:LX/1v1;

    new-instance v0, LX/2Fm;

    invoke-direct {v0, v1, v2}, LX/2Fm;-><init>(LX/1v1;Ljava/lang/String;)V

    return-object v0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-virtual {v2, p1, p2, v1, v0}, LX/352;->A0F(LX/3ep;IZZ)LX/2Fm;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic BMT(LX/0Ve;I)V
    .locals 25

    move-object/from16 v7, p1

    check-cast v7, LX/12w;

    iget-object v0, v7, LX/0Ve;->A0H:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v15

    move-object/from16 v6, p0

    iget-object v0, v6, LX/12m;->A08:LX/2ah;

    iget-object v0, v0, LX/2ah;->A02:LX/11a;

    invoke-virtual {v0}, LX/0Y8;->A06()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    move/from16 v1, p2

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LX/3es;

    iget-object v3, v5, LX/3es;->A04:LX/1ZJ;

    iget-object v0, v6, LX/12m;->A04:LX/3J5;

    invoke-virtual {v0, v3}, LX/3J5;->A06(LX/1ZJ;)LX/3ep;

    move-result-object v4

    invoke-static {v4}, LX/38Z;->A07(Ljava/lang/Object;)V

    invoke-virtual {v15}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v0, 0x7f070adf

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v18

    iget-object v0, v6, LX/12m;->A06:LX/31S;

    const/16 v17, 0x0

    const/4 v1, 0x1

    const/4 v9, 0x1

    move-object v14, v0

    move-object/from16 v16, v4

    move/from16 v19, v1

    invoke-virtual/range {v14 .. v19}, LX/31S;->A03(Landroid/content/Context;LX/3ep;FIZ)Landroid/graphics/Bitmap;

    move-result-object v16

    if-nez v16, :cond_0

    iget-object v2, v6, LX/12m;->A03:LX/5Ue;

    invoke-virtual {v2, v4}, LX/5Ue;->A00(LX/3ep;)I

    move-result v0

    invoke-virtual {v2, v15, v0}, LX/5Ue;->A03(Landroid/content/Context;I)Landroid/graphics/Bitmap;

    move-result-object v16

    :cond_0
    iget-object v0, v6, LX/12m;->A02:LX/2sr;

    invoke-virtual {v0, v3}, LX/2sr;->A0Z(LX/1ZJ;)Z

    move-result v24

    iget-object v11, v6, LX/12m;->A05:LX/352;

    iget-object v0, v6, LX/12m;->A09:LX/11u;

    iget-object v0, v0, LX/11u;->A02:LX/1ZJ;

    invoke-virtual {v11, v0}, LX/352;->A0B(LX/1ZJ;)I

    move-result v8

    iget-object v3, v5, LX/3es;->A05:Ljava/lang/String;

    invoke-static {v3}, LX/38Z;->A07(Ljava/lang/Object;)V

    const/4 v14, 0x0

    if-eqz v24, :cond_1

    const v0, 0x7f121a47

    invoke-virtual {v15, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v0, 0x7f121a42

    invoke-static {v15, v3, v1, v0}, LX/0yM;->A0V(Landroid/content/Context;Ljava/lang/Object;II)Ljava/lang/String;

    move-result-object v0

    new-instance v1, LX/2Hk;

    invoke-direct {v1, v2, v0}, LX/2Hk;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    iget-object v0, v6, LX/12m;->A0A:LX/3iy;

    new-instance v14, LX/3h7;

    move-object/from16 v22, v3

    move/from16 v23, v8

    move-object/from16 v20, v7

    move-object/from16 v21, v6

    move-object/from16 v18, v4

    move-object/from16 v19, v1

    move-object/from16 v17, v5

    invoke-direct/range {v14 .. v24}, LX/3h7;-><init>(Landroid/content/Context;Landroid/graphics/Bitmap;LX/3es;LX/3ep;LX/2Hk;LX/12w;LX/12m;Ljava/lang/String;IZ)V

    invoke-virtual {v0, v14}, LX/3iy;->execute(Ljava/lang/Runnable;)V

    return-void

    :cond_1
    invoke-virtual {v6, v4, v8}, LX/12m;->A0K(LX/3ep;I)LX/2Fm;

    move-result-object v0

    iget-object v10, v0, LX/2Fm;->A01:Ljava/lang/String;

    const v2, 0x7f121a43

    invoke-static {}, LX/002;->A08()[Ljava/lang/Object;

    move-result-object v1

    iget-object v12, v0, LX/2Fm;->A00:LX/1v1;

    sget-object v0, LX/1v1;->A09:LX/1v1;

    move-object v13, v10

    if-ne v12, v0, :cond_2

    const v0, 0x7f1225ea

    invoke-virtual {v11, v4, v0}, LX/352;->A0R(LX/3ep;I)Ljava/lang/String;

    move-result-object v13

    :cond_2
    aput-object v13, v1, v14

    invoke-static {v15, v3, v1, v9, v2}, LX/0yP;->A0Z(Landroid/content/Context;Ljava/lang/Object;[Ljava/lang/Object;II)Ljava/lang/String;

    move-result-object v0

    new-instance v1, LX/2Hk;

    invoke-direct {v1, v10, v0}, LX/2Hk;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public bridge synthetic BPF(Landroid/view/ViewGroup;I)LX/0Ve;
    .locals 3

    iget-object v0, p0, LX/12m;->A09:LX/11u;

    iget-boolean v0, v0, LX/11u;->A0A:Z

    const/4 v2, 0x0

    invoke-static {p1}, LX/0yN;->A0H(Landroid/view/View;)Landroid/view/LayoutInflater;

    move-result-object v1

    if-eqz v0, :cond_0

    const v0, 0x7f0e078d

    invoke-virtual {v1, v0, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    new-instance v1, LX/1iW;

    invoke-direct {v1, v0}, LX/1iW;-><init>(Landroid/view/View;)V

    return-object v1

    :cond_0
    const v0, 0x7f0e078c

    invoke-virtual {v1, v0, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    new-instance v1, LX/12w;

    invoke-direct {v1, v0}, LX/12w;-><init>(Landroid/view/View;)V

    return-object v1
.end method
