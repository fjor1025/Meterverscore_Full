.class public LX/15H;
.super LX/156;
.source ""


# instance fields
.field public final A00:Ljava/io/File;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/io/File;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1, p3}, LX/156;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iput-object p2, p0, LX/15H;->A00:Ljava/io/File;

    return-void
.end method
