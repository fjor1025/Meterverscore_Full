.class public LX/129;
.super LX/0V7;
.source ""


# instance fields
.field public A00:LX/8nm;

.field public A01:Ljava/lang/String;

.field public A02:Z

.field public final A03:LX/08S;

.field public final A04:LX/1Pl;

.field public final A05:LX/2Nm;


# direct methods
.method public constructor <init>(LX/1Pl;LX/2Nm;)V
    .locals 1

    invoke-direct {p0}, LX/0V7;-><init>()V

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/129;->A03:LX/08S;

    const-string v0, ""

    iput-object v0, p0, LX/129;->A01:Ljava/lang/String;

    iput-object p1, p0, LX/129;->A04:LX/1Pl;

    iput-object p2, p0, LX/129;->A05:LX/2Nm;

    return-void
.end method


# virtual methods
.method public A0G()V
    .locals 2

    iget-object v1, p0, LX/129;->A03:LX/08S;

    invoke-virtual {v1}, LX/0Y8;->A06()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v1}, LX/0Y8;->A06()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v1, p0, LX/129;->A01:Ljava/lang/String;

    const/4 v0, 0x1

    invoke-virtual {p0, v1, v0}, LX/129;->A0H(Ljava/lang/String;Z)V

    :cond_0
    return-void
.end method

.method public final A0H(Ljava/lang/String;Z)V
    .locals 7

    iput-boolean p2, p0, LX/129;->A02:Z

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v0, 0x14

    if-gt v1, v0, :cond_2

    const-string v0, "[\\p{Punct}\u00a5%\uff0c\u3002\uff1f\uff1b\uff1a\uff08\uff09\u3010\u3011\u300c\u300d\u300a\u300b\u2014\u00a1!\u00ab\u00bb\u00bf?{}]"

    new-instance v1, LX/5pC;

    invoke-direct {v1, v0}, LX/5pC;-><init>(Ljava/lang/String;)V

    const-string v0, ""

    invoke-virtual {v1, p1, v0}, LX/5pC;->A00(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iget-object v0, p0, LX/129;->A01:Ljava/lang/String;

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    if-nez p2, :cond_1

    :cond_0
    return-void

    :cond_1
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v2, p0, LX/129;->A04:LX/1Pl;

    const/16 v1, 0xd4b

    sget-object v0, LX/2vP;->A02:LX/2vP;

    invoke-virtual {v2, v0, v1}, LX/2sp;->A0W(LX/2vP;I)Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-static {v6}, LX/5Zu;->A01(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_3

    :cond_2
    iget-object v1, p0, LX/129;->A03:LX/08S;

    const/4 v0, 0x0

    invoke-static {v0}, LX/001;->A0x(I)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v1, v0}, LX/0Y8;->A0G(Ljava/lang/Object;)V

    const-string v0, ""

    iput-object v0, p0, LX/129;->A01:Ljava/lang/String;

    iget-object v2, p0, LX/129;->A05:LX/2Nm;

    iget-object v1, v2, LX/2Nm;->A00:LX/1mZ;

    if-eqz v1, :cond_0

    const/4 v0, 0x1

    invoke-virtual {v1, v0}, LX/7jt;->A06(Z)V

    const/4 v0, 0x0

    iput-object v0, v2, LX/2Nm;->A00:LX/1mZ;

    return-void

    :cond_3
    iput-object v6, p0, LX/129;->A01:Ljava/lang/String;

    iget-object v5, p0, LX/129;->A05:LX/2Nm;

    invoke-static {}, LX/38Z;->A01()V

    new-instance v4, LX/5Q3;

    invoke-direct {v4}, LX/5Q3;-><init>()V

    iget-object v0, v5, LX/2Nm;->A01:Lcom/gbwhatsapp/emoji/search/EmojiSearchProvider;

    iget-boolean v0, v0, LX/7Tz;->A02:Z

    if-eqz v0, :cond_5

    iget-object v1, v5, LX/2Nm;->A00:LX/1mZ;

    if-eqz v1, :cond_4

    const/4 v0, 0x1

    invoke-virtual {v1, v0}, LX/7jt;->A06(Z)V

    const/4 v0, 0x0

    iput-object v0, v5, LX/2Nm;->A00:LX/1mZ;

    :cond_4
    iget-object v3, v5, LX/2Nm;->A02:LX/2QC;

    new-instance v1, LX/3UI;

    invoke-direct {v1, v4}, LX/3UI;-><init>(LX/5Q3;)V

    const/4 v0, 0x1

    new-instance v2, LX/1mZ;

    invoke-direct {v2, v1, v5, v3}, LX/1mZ;-><init>(LX/3zf;LX/2Nm;LX/2QC;)V

    iput-object v2, v5, LX/2Nm;->A00:LX/1mZ;

    iget-object v1, v5, LX/2Nm;->A03:LX/454;

    invoke-static {v6, v0}, LX/0yP;->A1b(Ljava/lang/Object;I)[Ljava/lang/String;

    move-result-object v0

    invoke-interface {v1, v2, v0}, LX/454;->Bip(LX/7jt;[Ljava/lang/Object;)V

    :cond_5
    iget-object v0, p0, LX/129;->A00:LX/8nm;

    if-nez v0, :cond_6

    new-instance v0, LX/3UH;

    invoke-direct {v0, p0}, LX/3UH;-><init>(LX/129;)V

    iput-object v0, p0, LX/129;->A00:LX/8nm;

    :cond_6
    invoke-virtual {v4, v0}, LX/5Q3;->A00(LX/8nm;)V

    return-void
.end method
