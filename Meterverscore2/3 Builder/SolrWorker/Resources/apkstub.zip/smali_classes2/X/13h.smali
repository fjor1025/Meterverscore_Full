.class public LX/13h;
.super LX/2co;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LX/2co;-><init>()V

    return-void
.end method
