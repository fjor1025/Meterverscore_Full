.class public LX/12o;
.super LX/0Rb;
.source ""


# instance fields
.field public final synthetic A00:Lcom/gbwhatsapp/companiondevice/LinkedDevicesActivity;


# direct methods
.method public constructor <init>(Lcom/gbwhatsapp/companiondevice/LinkedDevicesActivity;)V
    .locals 0

    iput-object p1, p0, LX/12o;->A00:Lcom/gbwhatsapp/companiondevice/LinkedDevicesActivity;

    invoke-direct {p0}, LX/0Rb;-><init>()V

    return-void
.end method


# virtual methods
.method public A05()V
    .locals 3

    iget-object v2, p0, LX/12o;->A00:Lcom/gbwhatsapp/companiondevice/LinkedDevicesActivity;

    iget-object v1, v2, LX/4VJ;->A05:LX/3by;

    const/16 v0, 0x15

    invoke-static {v1, v2, v0}, LX/3by;->A04(LX/3by;Ljava/lang/Object;I)V

    return-void
.end method
