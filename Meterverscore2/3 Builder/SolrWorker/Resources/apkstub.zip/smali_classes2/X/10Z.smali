.class public LX/10Z;
.super Landroid/os/HandlerThread;
.source ""


# instance fields
.field public A00:J

.field public A01:LX/2o9;

.field public A02:LX/10S;

.field public A03:LX/10P;

.field public A04:LX/2l8;

.field public A05:LX/43o;

.field public A06:LX/10Y;

.field public A07:LX/31H;

.field public A08:LX/31G;

.field public final A09:LX/5pD;

.field public final A0A:LX/1cV;

.field public final A0B:LX/31x;

.field public final A0C:LX/2nR;

.field public final A0D:LX/2qa;

.field public final A0E:LX/2TN;

.field public final A0F:LX/2sr;

.field public final A0G:LX/37u;

.field public final A0H:LX/1cE;

.field public final A0I:LX/2ze;

.field public final A0J:LX/3RL;

.field public final A0K:LX/2s4;

.field public final A0L:LX/2Xx;

.field public final A0M:LX/2iC;

.field public final A0N:LX/2ar;

.field public final A0O:LX/2jQ;

.field public final A0P:LX/2A1;

.field public final A0Q:LX/2sJ;

.field public final A0R:LX/2iX;

.field public final A0S:LX/2tD;

.field public final A0T:LX/354;

.field public final A0U:LX/2oI;

.field public final A0V:LX/2ss;

.field public final A0W:LX/3jF;

.field public final A0X:LX/3J0;

.field public final A0Y:LX/1Pl;

.field public final A0Z:LX/3zQ;

.field public final A0a:LX/44u;

.field public final A0b:LX/3QV;

.field public final A0c:LX/21M;

.field public final A0d:LX/21g;

.field public final A0e:LX/2i2;

.field public final A0f:LX/33f;

.field public final A0g:LX/452;

.field public final A0h:LX/2l6;

.field public final A0i:LX/3VT;

.field public final A0j:LX/2eW;

.field public final A0k:LX/2eW;

.field public final A0l:LX/2eW;

.field public final A0m:LX/34u;

.field public final A0n:LX/2lv;

.field public final A0o:LX/2q0;

.field public final A0p:LX/3GD;

.field public final A0q:LX/2qw;

.field public final A0r:LX/31V;

.field public final A0s:LX/7YY;

.field public final A0t:LX/2YZ;

.field public final A0u:LX/2qy;

.field public final A0v:LX/2Oq;

.field public final A0w:LX/9Qc;

.field public final A0x:LX/9Qb;

.field public final A0y:LX/2lz;

.field public final A0z:LX/22R;

.field public final A10:LX/9QU;

.field public final A11:LX/22W;

.field public final A12:LX/37f;

.field public final A13:LX/2zD;

.field public final A14:LX/1bw;

.field public final A15:LX/2io;

.field public final A16:LX/2VE;

.field public final A17:LX/3GB;

.field public final A18:LX/2pv;

.field public final A19:LX/40w;

.field public final A1A:LX/454;

.field public final A1B:LX/2mS;

.field public final A1C:LX/3VU;

.field public final A1D:LX/8oO;

.field public final A1E:LX/8oO;

.field public final A1F:Ljava/util/Map;

.field public final A1G:Ljava/util/Random;

.field public final A1H:Ljava/util/Set;


# direct methods
.method public constructor <init>(LX/5pD;LX/1cV;LX/31x;LX/2nR;LX/2qa;LX/2TN;LX/2sr;LX/37u;LX/1cE;LX/2ze;LX/3RL;LX/2s4;LX/2Xx;LX/2iC;LX/2ar;LX/2jQ;LX/2A1;LX/2sJ;LX/2iX;LX/2tD;LX/354;LX/2oI;LX/2ss;LX/3jF;LX/3J0;LX/1Pl;LX/3zQ;LX/44u;LX/3QV;LX/21M;LX/21g;LX/2i2;LX/33f;LX/452;LX/2l6;LX/3VT;LX/34u;LX/2lv;LX/2q0;LX/3GD;LX/2qw;LX/31V;LX/7YY;LX/2YZ;LX/2qy;LX/2Oq;LX/9Qc;LX/9Qb;LX/2lz;LX/22R;LX/9QU;LX/22W;LX/37f;LX/2zD;LX/1bw;LX/2io;LX/2VE;LX/3GB;LX/2pv;LX/40w;LX/454;LX/2mS;LX/3VU;LX/8oO;LX/8oO;Ljava/util/Set;)V
    .locals 3

    const-string v1, "ConnectionThread"

    const/4 v0, 0x1

    invoke-direct {p0, v1, v0}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    const-string v2, "connection_thread/logged_flag/connected"

    const/4 v1, 0x0

    new-instance v0, LX/2eW;

    invoke-direct {v0, v2, v1}, LX/2eW;-><init>(Ljava/lang/String;Z)V

    iput-object v0, p0, LX/10Z;->A0j:LX/2eW;

    const-string v2, "connection_thread/logged_flag/disconnecting"

    new-instance v0, LX/2eW;

    invoke-direct {v0, v2, v1}, LX/2eW;-><init>(Ljava/lang/String;Z)V

    iput-object v0, p0, LX/10Z;->A0k:LX/2eW;

    const-string v2, "connection_thread/logged_flag/quit"

    new-instance v0, LX/2eW;

    invoke-direct {v0, v2, v1}, LX/2eW;-><init>(Ljava/lang/String;Z)V

    iput-object v0, p0, LX/10Z;->A0l:LX/2eW;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    iput-object v0, p0, LX/10Z;->A1F:Ljava/util/Map;

    move-object/from16 v0, p34

    iput-object v0, p0, LX/10Z;->A0g:LX/452;

    move-object/from16 v0, p19

    iput-object v0, p0, LX/10Z;->A0R:LX/2iX;

    move-object/from16 v0, p18

    iput-object v0, p0, LX/10Z;->A0Q:LX/2sJ;

    move-object/from16 v0, p26

    iput-object v0, p0, LX/10Z;->A0Y:LX/1Pl;

    move-object/from16 v0, p25

    iput-object v0, p0, LX/10Z;->A0X:LX/3J0;

    iput-object p5, p0, LX/10Z;->A0D:LX/2qa;

    iput-object p7, p0, LX/10Z;->A0F:LX/2sr;

    move-object/from16 v0, p61

    iput-object v0, p0, LX/10Z;->A1A:LX/454;

    iput-object p10, p0, LX/10Z;->A0I:LX/2ze;

    iput-object p12, p0, LX/10Z;->A0K:LX/2s4;

    move-object/from16 v0, p23

    iput-object v0, p0, LX/10Z;->A0V:LX/2ss;

    move-object/from16 v0, p28

    iput-object v0, p0, LX/10Z;->A0a:LX/44u;

    iput-object p11, p0, LX/10Z;->A0J:LX/3RL;

    iput-object p3, p0, LX/10Z;->A0B:LX/31x;

    move-object/from16 v0, p55

    iput-object v0, p0, LX/10Z;->A14:LX/1bw;

    move-object/from16 v0, p40

    iput-object v0, p0, LX/10Z;->A0p:LX/3GD;

    move-object/from16 v0, p37

    iput-object v0, p0, LX/10Z;->A0m:LX/34u;

    move-object/from16 v0, p14

    iput-object v0, p0, LX/10Z;->A0M:LX/2iC;

    move-object/from16 v0, p31

    iput-object v0, p0, LX/10Z;->A0d:LX/21g;

    iput-object p8, p0, LX/10Z;->A0G:LX/37u;

    move-object/from16 v0, p35

    iput-object v0, p0, LX/10Z;->A0h:LX/2l6;

    move-object/from16 v0, p43

    iput-object v0, p0, LX/10Z;->A0s:LX/7YY;

    move-object/from16 v0, p64

    iput-object v0, p0, LX/10Z;->A1D:LX/8oO;

    move-object/from16 v0, p65

    iput-object v0, p0, LX/10Z;->A1E:LX/8oO;

    move-object/from16 v0, p63

    iput-object v0, p0, LX/10Z;->A1C:LX/3VU;

    move-object/from16 v0, p54

    iput-object v0, p0, LX/10Z;->A13:LX/2zD;

    move-object/from16 v0, p48

    iput-object v0, p0, LX/10Z;->A0x:LX/9Qb;

    iput-object p1, p0, LX/10Z;->A09:LX/5pD;

    move-object/from16 v0, p59

    iput-object v0, p0, LX/10Z;->A18:LX/2pv;

    move-object/from16 v0, p29

    iput-object v0, p0, LX/10Z;->A0b:LX/3QV;

    iput-object p9, p0, LX/10Z;->A0H:LX/1cE;

    move-object/from16 v0, p41

    iput-object v0, p0, LX/10Z;->A0q:LX/2qw;

    move-object/from16 v0, p62

    iput-object v0, p0, LX/10Z;->A1B:LX/2mS;

    move-object/from16 v0, p60

    iput-object v0, p0, LX/10Z;->A19:LX/40w;

    move-object/from16 v0, p57

    iput-object v0, p0, LX/10Z;->A16:LX/2VE;

    move-object/from16 v0, p27

    iput-object v0, p0, LX/10Z;->A0Z:LX/3zQ;

    move-object/from16 v0, p39

    iput-object v0, p0, LX/10Z;->A0o:LX/2q0;

    move-object/from16 v0, p30

    iput-object v0, p0, LX/10Z;->A0c:LX/21M;

    iput-object p4, p0, LX/10Z;->A0C:LX/2nR;

    move-object/from16 v0, p45

    iput-object v0, p0, LX/10Z;->A0u:LX/2qy;

    move-object/from16 v0, p38

    iput-object v0, p0, LX/10Z;->A0n:LX/2lv;

    move-object/from16 v0, p24

    iput-object v0, p0, LX/10Z;->A0W:LX/3jF;

    move-object/from16 v0, p51

    iput-object v0, p0, LX/10Z;->A10:LX/9QU;

    move-object/from16 v0, p21

    iput-object v0, p0, LX/10Z;->A0T:LX/354;

    move-object/from16 v0, p52

    iput-object v0, p0, LX/10Z;->A11:LX/22W;

    move-object/from16 v0, p32

    iput-object v0, p0, LX/10Z;->A0e:LX/2i2;

    move-object/from16 v0, p44

    iput-object v0, p0, LX/10Z;->A0t:LX/2YZ;

    move-object/from16 v0, p46

    iput-object v0, p0, LX/10Z;->A0v:LX/2Oq;

    move-object/from16 v0, p47

    iput-object v0, p0, LX/10Z;->A0w:LX/9Qc;

    move-object/from16 v0, p13

    iput-object v0, p0, LX/10Z;->A0L:LX/2Xx;

    move-object/from16 v0, p58

    iput-object v0, p0, LX/10Z;->A17:LX/3GB;

    move-object/from16 v0, p66

    iput-object v0, p0, LX/10Z;->A1H:Ljava/util/Set;

    move-object/from16 v0, p33

    iput-object v0, p0, LX/10Z;->A0f:LX/33f;

    move-object/from16 v0, p17

    iput-object v0, p0, LX/10Z;->A0P:LX/2A1;

    move-object/from16 v0, p56

    iput-object v0, p0, LX/10Z;->A15:LX/2io;

    iput-object p2, p0, LX/10Z;->A0A:LX/1cV;

    move-object/from16 v0, p50

    iput-object v0, p0, LX/10Z;->A0z:LX/22R;

    move-object/from16 v0, p42

    iput-object v0, p0, LX/10Z;->A0r:LX/31V;

    move-object/from16 v0, p22

    iput-object v0, p0, LX/10Z;->A0U:LX/2oI;

    move-object/from16 v0, p15

    iput-object v0, p0, LX/10Z;->A0N:LX/2ar;

    move-object/from16 v0, p36

    iput-object v0, p0, LX/10Z;->A0i:LX/3VT;

    move-object/from16 v0, p20

    iput-object v0, p0, LX/10Z;->A0S:LX/2tD;

    move-object/from16 v0, p49

    iput-object v0, p0, LX/10Z;->A0y:LX/2lz;

    move-object/from16 v0, p16

    iput-object v0, p0, LX/10Z;->A0O:LX/2jQ;

    move-object/from16 v0, p53

    iput-object v0, p0, LX/10Z;->A12:LX/37f;

    iput-object p6, p0, LX/10Z;->A0E:LX/2TN;

    invoke-static {}, LX/0yU;->A0b()Ljava/util/Random;

    move-result-object v0

    iput-object v0, p0, LX/10Z;->A1G:Ljava/util/Random;

    return-void
.end method

.method public static final A00(II)I
    .locals 1

    const/4 v0, -0x1

    if-eq p1, v0, :cond_0

    return p1

    :cond_0
    return p0
.end method

.method public static A01(Landroid/os/Message;)I
    .locals 0

    iget p0, p0, Landroid/os/Message;->arg1:I

    return p0
.end method

.method public static A02()Landroid/os/Message;
    .locals 1

    const/16 v0, 0x18

    invoke-static {v0}, LX/0yS;->A08(I)Landroid/os/Message;

    move-result-object v0

    return-object v0
.end method

.method public static A03()Landroid/os/Message;
    .locals 1

    const/16 v0, 0x16

    invoke-static {v0}, LX/0yS;->A08(I)Landroid/os/Message;

    move-result-object v0

    return-object v0
.end method

.method public static A04()Landroid/os/Message;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-static {v1, v0, v0, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v0

    return-object v0
.end method

.method public static A05()Landroid/os/Message;
    .locals 1

    const/16 v0, 0x17

    invoke-static {v0}, LX/0yS;->A08(I)Landroid/os/Message;

    move-result-object v0

    return-object v0
.end method

.method public static A06(Ljava/util/List;)Landroid/os/Message;
    .locals 1

    const/16 v0, 0x5a

    invoke-static {v0, p0}, LX/0yP;->A0F(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    return-object v0
.end method

.method public static A07(Ljava/util/List;)Landroid/os/Message;
    .locals 1

    const/16 v0, 0x114

    invoke-static {v0, p0}, LX/0yP;->A0F(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    return-object v0
.end method

.method public static A08(Ljava/util/List;)Landroid/os/Message;
    .locals 1

    const/16 v0, 0xf7

    invoke-static {v0, p0}, LX/0yP;->A0F(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    return-object v0
.end method

.method public static A09(Ljava/util/List;)Landroid/os/Message;
    .locals 1

    const/16 v0, 0x196

    invoke-static {v0, p0}, LX/0yP;->A0F(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic A0A(LX/10Z;)LX/2o9;
    .locals 0

    iget-object p0, p0, LX/10Z;->A01:LX/2o9;

    return-object p0
.end method

.method public static synthetic A0B(LX/10Z;)LX/2eW;
    .locals 0

    iget-object p0, p0, LX/10Z;->A0k:LX/2eW;

    return-object p0
.end method

.method public static synthetic A0C(LX/10Z;)LX/43o;
    .locals 0

    iget-object p0, p0, LX/10Z;->A05:LX/43o;

    return-object p0
.end method

.method public static synthetic A0D(LX/10Z;)LX/31V;
    .locals 0

    iget-object p0, p0, LX/10Z;->A0r:LX/31V;

    return-object p0
.end method

.method public static synthetic A0E(LX/10Z;)LX/2io;
    .locals 0

    iget-object p0, p0, LX/10Z;->A15:LX/2io;

    return-object p0
.end method

.method public static synthetic A0F(LX/10Z;)LX/2pv;
    .locals 0

    iget-object p0, p0, LX/10Z;->A18:LX/2pv;

    return-object p0
.end method

.method public static synthetic A0G(LX/10Z;)LX/3VU;
    .locals 0

    iget-object p0, p0, LX/10Z;->A1C:LX/3VU;

    return-object p0
.end method

.method public static A0H(LX/10Z;)LX/306;
    .locals 0

    iget-object p0, p0, LX/10Z;->A1D:LX/8oO;

    invoke-interface {p0}, LX/8oO;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LX/306;

    return-object p0
.end method

.method public static synthetic A0I(LX/10Z;)LX/8oO;
    .locals 0

    iget-object p0, p0, LX/10Z;->A1D:LX/8oO;

    return-object p0
.end method

.method public static synthetic A0J(Landroid/os/Message;LX/10Z;)V
    .locals 0

    invoke-virtual {p1, p0}, LX/10Z;->A0w(Landroid/os/Message;)V

    return-void
.end method

.method public static synthetic A0K(Landroid/os/Message;LX/10Z;)V
    .locals 0

    invoke-virtual {p1, p0}, LX/10Z;->A0v(Landroid/os/Message;)V

    return-void
.end method

.method public static synthetic A0L(Landroid/os/Message;LX/10Z;)V
    .locals 0

    invoke-virtual {p1, p0}, LX/10Z;->A0u(Landroid/os/Message;)V

    return-void
.end method

.method public static A0M(LX/354;LX/3zQ;LX/381;)V
    .locals 3

    const-string/jumbo v0, "location"

    invoke-virtual {p2, v0}, LX/381;->A0q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v0, 0x28

    if-ge v1, v0, :cond_1

    :cond_0
    invoke-static {p1, v2}, LX/20u;->A00(LX/3zQ;Ljava/lang/String;)V

    invoke-virtual {p0, v2}, LX/354;->A0s(Ljava/lang/String;)V

    :cond_1
    return-void
.end method

.method public static synthetic A0N(Lcom/whatsapp/jid/UserJid;LX/2L5;LX/10Z;Ljava/lang/String;ZZ)V
    .locals 1

    move-object v0, p2

    move-object p2, p3

    move p3, p4

    move p4, p5

    invoke-virtual/range {v0 .. v5}, LX/10Z;->A0x(Lcom/whatsapp/jid/UserJid;LX/2L5;Ljava/lang/String;ZZ)V

    return-void
.end method

.method public static synthetic A0O(LX/10Z;)V
    .locals 0

    invoke-virtual {p0}, LX/10Z;->A0n()V

    return-void
.end method

.method public static synthetic A0P(LX/10Z;)V
    .locals 0

    invoke-virtual {p0}, LX/10Z;->A0m()V

    return-void
.end method

.method public static synthetic A0Q(LX/10Z;)V
    .locals 0

    invoke-virtual {p0}, LX/10Z;->A0l()V

    return-void
.end method

.method public static synthetic A0R(LX/10Z;)V
    .locals 0

    invoke-virtual {p0}, LX/10Z;->A0k()V

    return-void
.end method

.method public static synthetic A0S(LX/10Z;I)V
    .locals 0

    invoke-virtual {p0, p1}, LX/10Z;->A0p(I)V

    return-void
.end method

.method public static synthetic A0T(LX/10Z;I)V
    .locals 0

    invoke-virtual {p0, p1}, LX/10Z;->A0o(I)V

    return-void
.end method

.method public static synthetic A0U(LX/10Z;I)V
    .locals 0

    invoke-virtual {p0, p1}, LX/10Z;->A0q(I)V

    return-void
.end method

.method public static synthetic A0V(LX/10Z;IJZ)V
    .locals 0

    invoke-virtual {p0, p2, p3, p1, p4}, LX/10Z;->A0s(JIZ)V

    return-void
.end method

.method public static synthetic A0W(LX/10Z;LX/43o;)V
    .locals 0

    invoke-virtual {p0, p1}, LX/10Z;->A0y(LX/43o;)V

    return-void
.end method

.method public static synthetic A0X(LX/10Z;LX/30N;)V
    .locals 0

    invoke-virtual {p0, p1}, LX/10Z;->A11(LX/30N;)V

    return-void
.end method

.method public static synthetic A0Y(LX/10Z;LX/31G;)V
    .locals 0

    invoke-virtual {p0, p1}, LX/10Z;->A12(LX/31G;)V

    return-void
.end method

.method public static synthetic A0Z(LX/10Z;Ljava/lang/String;)V
    .locals 0

    invoke-virtual {p0, p1}, LX/10Z;->A14(Ljava/lang/String;)V

    return-void
.end method

.method public static A0a(LX/1y0;LX/381;)V
    .locals 2

    const-string/jumbo v0, "logout_message_header"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LX/1y0;->logoutMessageHeader:Ljava/lang/String;

    const-string/jumbo v0, "logout_message_subtext"

    invoke-virtual {p1, v0, v1}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LX/1y0;->logoutMessageSubtext:Ljava/lang/String;

    const-string/jumbo v0, "logout_message_locale"

    invoke-virtual {p1, v0, v1}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LX/1y0;->logoutMessageLocale:Ljava/lang/String;

    const-string/jumbo v0, "logout_main_button_text"

    invoke-virtual {p1, v0, v1}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LX/1y0;->logoutMainButtonText:Ljava/lang/String;

    const-string/jumbo v0, "logout_main_button_url"

    invoke-virtual {p1, v0, v1}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LX/1y0;->logoutMainButtonUrl:Ljava/lang/String;

    const-string/jumbo v0, "logout_secondary_button_text"

    invoke-virtual {p1, v0, v1}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LX/1y0;->logoutSecondaryButtonText:Ljava/lang/String;

    const-string/jumbo v0, "logout_secondary_button_url"

    invoke-virtual {p1, v0, v1}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LX/1y0;->logoutSecondaryButtonUrl:Ljava/lang/String;

    return-void
.end method

.method public static final A0b(LX/2mN;Ljava/util/Map;)V
    .locals 5

    invoke-virtual {p0}, LX/2mN;->A02()[Ljava/lang/String;

    move-result-object v4

    array-length v3, v4

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v3, :cond_1

    aget-object v1, v4, v2

    invoke-interface {p1, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-interface {p1, v1, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    const-string v0, "ConnectionReader/addStanzaHandler this stanza is already handled"

    invoke-static {v0}, LX/001;->A0i(Ljava/lang/String;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0

    :cond_1
    return-void
.end method

.method public static synthetic A0c(LX/10Z;)Z
    .locals 0

    invoke-virtual {p0}, LX/10Z;->A18()Z

    move-result p0

    return p0
.end method


# virtual methods
.method public final A0d(LX/2wH;I)LX/2NO;
    .locals 9

    const/4 v5, 0x3

    const/4 v6, 0x0

    :try_start_0
    iget-object v0, p0, LX/10Z;->A0f:LX/33f;

    const/16 v1, 0x7530

    invoke-virtual {v0, p1}, LX/33f;->A02(LX/2wH;)LX/2o9;

    move-result-object v0

    iput-object v0, p0, LX/10Z;->A01:LX/2o9;

    invoke-virtual {v0, v1}, LX/2o9;->A02(I)V
    :try_end_0
    .catch Ljava/net/SocketException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    iget-object v0, p0, LX/10Z;->A1G:Ljava/util/Random;

    invoke-virtual {v0}, Ljava/util/Random;->nextInt()I

    move-result v8

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "ConnectionThread/tryOpenSocket: socket connected; sessionId="

    invoke-static {v0, v1, v8}, LX/0yK;->A0w(Ljava/lang/String;Ljava/lang/StringBuilder;I)V

    iget-object v0, p0, LX/10Z;->A1E:LX/8oO;

    invoke-interface {v0}, LX/8oO;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/3FY;

    invoke-virtual {v0}, LX/3FY;->A00()V

    iget v1, p1, LX/2wH;->A00:I

    iget-object v0, p1, LX/2wH;->A02:LX/2GN;

    new-instance v6, LX/2qt;

    invoke-direct {v6, v0, v8, v1, p2}, LX/2qt;-><init>(LX/2GN;III)V

    iget-object v2, p0, LX/10Z;->A1D:LX/8oO;

    invoke-interface {v2}, LX/8oO;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/306;

    invoke-virtual {v0, v6}, LX/306;->A03(LX/2qt;)V

    :try_start_1
    iget-object v0, p0, LX/10Z;->A01:LX/2o9;

    invoke-static {v0, p1}, LX/33f;->A00(LX/2o9;LX/2wH;)Ljava/io/InputStream;

    move-result-object v1

    iget-object v7, p0, LX/10Z;->A0K:LX/2s4;

    invoke-static {}, LX/0yN;->A0N()Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2}, LX/8oO;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/306;

    new-instance v3, LX/1On;

    invoke-direct {v3, v7, v0, v1, v4}, LX/1On;-><init>(LX/2s4;LX/306;Ljava/io/InputStream;Ljava/lang/Integer;)V

    iget-object v0, p0, LX/10Z;->A01:LX/2o9;

    invoke-static {v0, p1}, LX/33f;->A01(LX/2o9;LX/2wH;)Ljava/io/OutputStream;

    move-result-object v1

    invoke-interface {v2}, LX/8oO;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/306;

    new-instance v2, LX/1Oo;

    invoke-direct {v2, v7, v0, v1, v4}, LX/1Oo;-><init>(LX/2s4;LX/306;Ljava/io/OutputStream;Ljava/lang/Integer;)V

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "ConnectionThread/tryOpenSocket: created IO streams; sessionId="

    invoke-static {v0, v1, v8}, LX/0yK;->A0w(Ljava/lang/String;Ljava/lang/StringBuilder;I)V

    iget-object v0, p0, LX/10Z;->A0s:LX/7YY;

    invoke-virtual {v0, v6}, LX/7YY;->A08(LX/2qt;)V

    new-instance v0, LX/2NO;

    invoke-direct {v0, p1, v6, v3, v2}, LX/2NO;-><init>(LX/2wH;LX/2qt;Ljava/io/InputStream;Ljava/io/OutputStream;)V

    return-object v0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    move-exception v4

    iget-object v0, p0, LX/10Z;->A0s:LX/7YY;

    invoke-virtual {v0, v6, v5}, LX/7YY;->A0B(LX/2qt;I)V

    throw v4

    :catch_1
    move-exception v4

    iget-object v3, p0, LX/10Z;->A0s:LX/7YY;

    iget v2, p1, LX/2wH;->A00:I

    iget-object v1, p1, LX/2wH;->A02:LX/2GN;

    new-instance v0, LX/2qt;

    invoke-direct {v0, v1, v6, v2, p2}, LX/2qt;-><init>(LX/2GN;III)V

    invoke-virtual {v3, v0, v5}, LX/7YY;->A0B(LX/2qt;I)V

    throw v4

    :catch_2
    move-exception v4

    iget-object v3, p0, LX/10Z;->A0s:LX/7YY;

    iget v2, p1, LX/2wH;->A00:I

    iget-object v0, p1, LX/2wH;->A02:LX/2GN;

    new-instance v1, LX/2qt;

    invoke-direct {v1, v0, v6, v2, p2}, LX/2qt;-><init>(LX/2GN;III)V

    const/4 v0, 0x2

    invoke-virtual {v3, v1, v0}, LX/7YY;->A0B(LX/2qt;I)V

    throw v4
.end method

.method public final A0e(LX/34X;I)LX/2wH;
    .locals 6

    :try_start_0
    invoke-virtual {p1}, LX/34X;->A02()LX/2wH;

    move-result-object v5

    iget-object v4, p0, LX/10Z;->A0s:LX/7YY;

    iget v3, v5, LX/2wH;->A00:I

    iget-object v2, v5, LX/2wH;->A02:LX/2GN;

    const/4 v1, 0x0

    new-instance v0, LX/2qt;

    invoke-direct {v0, v2, v1, v3, p2}, LX/2qt;-><init>(LX/2GN;III)V

    invoke-virtual {v4, v0}, LX/7YY;->A05(LX/2qt;)V

    return-object v5
    :try_end_0
    .catch Ljava/net/UnknownHostException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception v1

    iget-object v0, p0, LX/10Z;->A0s:LX/7YY;

    invoke-virtual {v0, p2}, LX/7YY;->A02(I)V

    throw v1
.end method

.method public final A0f(LX/2Mi;LX/2zO;Ljava/util/Map;)Ljava/util/Map;
    .locals 35

    invoke-static {}, LX/001;->A0y()Ljava/util/HashMap;

    move-result-object v8

    move-object/from16 v10, p0

    iget-object v3, v10, LX/10Z;->A1F:Ljava/util/Map;

    new-instance v2, LX/2m2;

    move-object/from16 v4, p1

    move-object/from16 v34, p2

    move-object/from16 v29, p3

    move-object/from16 v1, v34

    move-object/from16 v0, v29

    invoke-direct {v2, v4, v1, v0, v3}, LX/2m2;-><init>(LX/2Mi;LX/2zO;Ljava/util/Map;Ljava/util/Map;)V

    iget-object v0, v10, LX/10Z;->A1H:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/40M;

    invoke-interface {v0, v2}, LX/40M;->Azt(LX/2m2;)LX/2mN;

    move-result-object v0

    invoke-static {v0, v8}, LX/10Z;->A0b(LX/2mN;Ljava/util/Map;)V

    goto :goto_0

    :cond_0
    iget-object v0, v10, LX/10Z;->A0Q:LX/2sJ;

    move-object/from16 v33, v0

    iget-object v0, v10, LX/10Z;->A0Y:LX/1Pl;

    move-object/from16 v32, v0

    iget-object v0, v10, LX/10Z;->A0D:LX/2qa;

    move-object/from16 v31, v0

    iget-object v0, v10, LX/10Z;->A0a:LX/44u;

    move-object/from16 v30, v0

    iget-object v15, v10, LX/10Z;->A0m:LX/34u;

    iget-object v14, v10, LX/10Z;->A0v:LX/2Oq;

    iget-object v13, v10, LX/10Z;->A0w:LX/9Qc;

    iget-object v12, v10, LX/10Z;->A0i:LX/3VT;

    new-instance v0, LX/1i6;

    move-object/from16 v16, v0

    move-object/from16 v17, v31

    move-object/from16 v18, v33

    move-object/from16 v19, v32

    move-object/from16 v20, v30

    move-object/from16 v21, v34

    move-object/from16 v22, v12

    move-object/from16 v23, v15

    move-object/from16 v24, v14

    move-object/from16 v25, v13

    move-object/from16 v26, v29

    invoke-direct/range {v16 .. v26}, LX/1i6;-><init>(LX/2qa;LX/2sJ;LX/1Pl;LX/44u;LX/2zO;LX/3VT;LX/34u;LX/2Oq;LX/9Qc;Ljava/util/Map;)V

    invoke-static {v0, v8}, LX/10Z;->A0b(LX/2mN;Ljava/util/Map;)V

    iget-object v11, v10, LX/10Z;->A0F:LX/2sr;

    iget-object v9, v10, LX/10Z;->A0d:LX/21g;

    iget-object v7, v10, LX/10Z;->A0G:LX/37u;

    iget-object v6, v10, LX/10Z;->A0x:LX/9Qb;

    iget-object v5, v10, LX/10Z;->A19:LX/40w;

    iget-object v4, v10, LX/10Z;->A1B:LX/2mS;

    iget-object v3, v10, LX/10Z;->A10:LX/9QU;

    iget-object v2, v10, LX/10Z;->A0T:LX/354;

    iget-object v1, v10, LX/10Z;->A0P:LX/2A1;

    iget-object v10, v10, LX/10Z;->A0y:LX/2lz;

    new-instance v0, LX/1i4;

    move-object/from16 v23, v13

    move-object/from16 v24, v6

    move-object/from16 v25, v10

    move-object/from16 v26, v3

    move-object/from16 v27, v5

    move-object/from16 v28, v4

    move-object/from16 v17, v30

    move-object/from16 v18, v9

    move-object/from16 v19, v34

    move-object/from16 v20, v12

    move-object/from16 v21, v15

    move-object/from16 v22, v14

    move-object v12, v7

    move-object v13, v1

    move-object/from16 v14, v33

    move-object v15, v2

    move-object/from16 v16, v32

    move-object v9, v0

    move-object/from16 v10, v31

    invoke-direct/range {v9 .. v29}, LX/1i4;-><init>(LX/2qa;LX/2sr;LX/37u;LX/2A1;LX/2sJ;LX/354;LX/1Pl;LX/44u;LX/21g;LX/2zO;LX/3VT;LX/34u;LX/2Oq;LX/9Qc;LX/9Qb;LX/2lz;LX/9QU;LX/40w;LX/2mS;Ljava/util/Map;)V

    invoke-static {v0, v8}, LX/10Z;->A0b(LX/2mN;Ljava/util/Map;)V

    new-instance v0, LX/1iD;

    move-object/from16 v17, v34

    move-object v12, v14

    move-object v13, v2

    move-object/from16 v14, v32

    move-object/from16 v15, v30

    move-object/from16 v16, v34

    move-object/from16 v18, v29

    move-object v9, v0

    invoke-direct/range {v9 .. v18}, LX/1iD;-><init>(LX/2qa;LX/2sr;LX/2sJ;LX/354;LX/1Pl;LX/44u;LX/2zO;LX/2zO;Ljava/util/Map;)V

    invoke-static {v0, v8}, LX/10Z;->A0b(LX/2mN;Ljava/util/Map;)V

    return-object v8
.end method

.method public final A0g(LX/1EU;LX/2qt;Ljava/io/InputStream;Ljava/io/OutputStream;LX/3jU;LX/3jT;)LX/319;
    .locals 11

    :try_start_0
    iget-object v3, p0, LX/10Z;->A0Q:LX/2sJ;

    iget-object v4, p0, LX/10Z;->A0S:LX/2tD;

    iget-object v6, p0, LX/10Z;->A16:LX/2VE;

    new-instance v2, LX/319;

    move-object v5, p1

    move-object v7, p3

    move-object v8, p4

    move-object/from16 v9, p5

    move-object/from16 v10, p6

    invoke-direct/range {v2 .. v10}, LX/319;-><init>(LX/2sJ;LX/2tD;LX/1EU;LX/2VE;Ljava/io/InputStream;Ljava/io/OutputStream;LX/3jU;LX/3jT;)V

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "ConnectionThread/performHandshake: completed noise handshake; sessionId="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p2, LX/2qt;->A03:I

    invoke-static {v1, v0}, LX/0yK;->A1E(Ljava/lang/StringBuilder;I)V

    iget-object v0, p0, LX/10Z;->A0s:LX/7YY;

    invoke-virtual {v0, p2}, LX/7YY;->A06(LX/2qt;)V

    return-object v2
    :try_end_0
    .catch LX/1tC; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catch LX/1xv; {:try_start_0 .. :try_end_0} :catch_2

    :catch_0
    move-exception v2

    iget-object v1, p0, LX/10Z;->A0s:LX/7YY;

    const/4 v0, 0x5

    goto :goto_0

    :catch_1
    move-exception v2

    iget-object v1, p0, LX/10Z;->A0s:LX/7YY;

    const/4 v0, 0x4

    goto :goto_0

    :catch_2
    move-exception v2

    iget-object v1, p0, LX/10Z;->A0s:LX/7YY;

    const/4 v0, 0x6

    :goto_0
    invoke-virtual {v1, p2, v0}, LX/7YY;->A09(LX/2qt;I)V

    throw v2
.end method

.method public A0h()V
    .locals 1

    iget-object v0, p0, LX/10Z;->A07:LX/31H;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, LX/31H;->A03()V

    :cond_0
    return-void
.end method

.method public final A0i()V
    .locals 1

    const-string v0, "ConnectionThread/closeSocket"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v0, p0, LX/10Z;->A01:LX/2o9;

    invoke-virtual {v0}, LX/2o9;->A01()V

    return-void
.end method

.method public final A0j()V
    .locals 2

    iget-object v1, p0, LX/10Z;->A05:LX/43o;

    invoke-static {}, LX/10Z;->A03()Landroid/os/Message;

    move-result-object v0

    invoke-interface {v1, v0}, LX/43o;->Bk3(Landroid/os/Message;)V

    return-void
.end method

.method public final A0k()V
    .locals 2

    invoke-virtual {p0}, LX/10Z;->A0i()V

    const/4 v1, 0x0

    const/4 v0, -0x1

    invoke-virtual {p0, v1, v0}, LX/10Z;->A17(ZI)V

    return-void
.end method

.method public final A0l()V
    .locals 4

    const-wide/16 v2, 0x0

    const/16 v1, 0x8

    const/4 v0, 0x1

    invoke-virtual {p0, v2, v3, v1, v0}, LX/10Z;->A0s(JIZ)V

    return-void
.end method

.method public final A0m()V
    .locals 2

    iget-object v1, p0, LX/10Z;->A05:LX/43o;

    invoke-static {}, LX/10Z;->A02()Landroid/os/Message;

    move-result-object v0

    invoke-interface {v1, v0}, LX/43o;->Bk3(Landroid/os/Message;)V

    iget-object v1, p0, LX/10Z;->A0C:LX/2nR;

    invoke-virtual {v1}, LX/2nR;->A01()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {v1}, LX/2nR;->A00()V

    :cond_0
    return-void
.end method

.method public final A0n()V
    .locals 2

    iget-object v1, p0, LX/10Z;->A05:LX/43o;

    invoke-static {}, LX/10Z;->A05()Landroid/os/Message;

    move-result-object v0

    invoke-interface {v1, v0}, LX/43o;->Bk3(Landroid/os/Message;)V

    return-void
.end method

.method public final A0o(I)V
    .locals 1

    iget-object v0, p0, LX/10Z;->A0M:LX/2iC;

    invoke-virtual {v0}, LX/2iC;->A00()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "ConnectionThread/handleLogoutTimeout/skip-voip-active"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v0, p0, LX/10Z;->A03:LX/10P;

    invoke-virtual {v0, p1}, LX/10P;->A07(I)V

    invoke-virtual {p0}, LX/10Z;->A0j()V

    return-void

    :cond_0
    invoke-static {p0}, LX/10Z;->A0H(LX/10Z;)LX/306;

    move-result-object v0

    invoke-virtual {v0, p1}, LX/306;->A02(I)V

    const-string v0, "ConnectionThread/handleLogoutTimeout/close-socket"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    invoke-virtual {p0}, LX/10Z;->A0i()V

    return-void
.end method

.method public final A0p(I)V
    .locals 2

    iget-object v1, p0, LX/10Z;->A0l:LX/2eW;

    const/4 v0, 0x1

    invoke-virtual {v1, v0}, LX/2eW;->A00(Z)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1}, LX/10Z;->A16(ZI)V

    return-void
.end method

.method public final A0q(I)V
    .locals 1

    invoke-virtual {p0}, LX/10Z;->A0i()V

    const/4 v0, 0x1

    invoke-virtual {p0, v0, p1}, LX/10Z;->A17(ZI)V

    return-void
.end method

.method public final A0r(J)V
    .locals 2

    iget-object v1, p0, LX/10Z;->A0T:LX/354;

    invoke-virtual {v1, p1, p2}, LX/354;->A0j(J)V

    const/4 v0, 0x0

    invoke-virtual {v1, v0}, LX/354;->A1L(Z)V

    return-void
.end method

.method public final A0s(JIZ)V
    .locals 4

    const-wide/16 v1, 0x0

    cmp-long v0, p1, v1

    if-lez v0, :cond_0

    iget-wide v0, p0, LX/10Z;->A00:J

    cmp-long v2, v0, p1

    if-lez v2, :cond_0

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v2, "ConnectionThread/handleDisconnect/skip disconnectRequestTime:"

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, " lastConnectedTime:"

    invoke-static {v2, v3, v0, v1}, LX/0yK;->A0z(Ljava/lang/String;Ljava/lang/StringBuilder;J)V

    return-void

    :cond_0
    invoke-virtual {p0, p4, p3}, LX/10Z;->A16(ZI)V

    return-void
.end method

.method public final A0t(JJ)V
    .locals 8

    new-instance v3, LX/1QK;

    invoke-direct {v3}, LX/1QK;-><init>()V

    sub-long v0, p1, p3

    invoke-static {v0, v1}, Ljava/lang/Math;->abs(J)J

    move-result-wide v0

    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v2, v0, v1}, Ljava/util/concurrent/TimeUnit;->toHours(J)J

    move-result-wide v6

    invoke-virtual {v2, v0, v1}, Ljava/util/concurrent/TimeUnit;->toMinutes(J)J

    move-result-wide v4

    const-wide/16 v0, 0x3c

    rem-long/2addr v4, v0

    const-wide/16 v1, 0x1e

    cmp-long v0, v4, v1

    if-ltz v0, :cond_0

    const-wide/16 v0, 0x1

    add-long/2addr v6, v0

    :cond_0
    cmp-long v0, p1, p3

    if-gez v0, :cond_1

    const-wide/16 v0, -0x1

    mul-long/2addr v6, v0

    :cond_1
    const-wide/16 v1, 0x0

    cmp-long v0, v6, v1

    if-eqz v0, :cond_2

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    iput-object v0, v3, LX/1QK;->A00:Ljava/lang/Long;

    iget-object v0, p0, LX/10Z;->A0a:LX/44u;

    invoke-interface {v0, v3}, LX/44u;->Bfn(LX/3eo;)V

    :cond_2
    return-void
.end method

.method public final A0u(Landroid/os/Message;)V
    .locals 3

    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v1

    const-string v0, "iqId"

    invoke-virtual {v1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, LX/38Z;->A07(Ljava/lang/Object;)V

    iget-object v1, p0, LX/10Z;->A0r:LX/31V;

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, LX/381;

    invoke-virtual {v1, v0, v2}, LX/31V;->A08(LX/381;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, LX/10Z;->A0g:LX/452;

    invoke-interface {v0, v2}, LX/452;->BTR(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public final A0v(Landroid/os/Message;)V
    .locals 5

    invoke-static {p1}, LX/10Z;->A01(Landroid/os/Message;)I

    move-result v2

    const/4 v0, 0x4

    if-eq v2, v0, :cond_2

    const/16 v0, 0x57

    if-eq v2, v0, :cond_1

    iget-object v1, p0, LX/10Z;->A0r:LX/31V;

    invoke-virtual {v1, v2}, LX/31V;->A07(I)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Landroid/os/Message;->obtain(Landroid/os/Message;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v1, v0, v2}, LX/31V;->A01(Landroid/os/Message;I)V

    return-void

    :cond_0
    iget-object v1, p0, LX/10Z;->A0g:LX/452;

    invoke-static {p1}, Landroid/os/Message;->obtain(Landroid/os/Message;)Landroid/os/Message;

    move-result-object v0

    invoke-interface {v1, v0}, LX/452;->BeX(Landroid/os/Message;)V

    return-void

    :cond_1
    iget-object v0, p0, LX/10Z;->A03:LX/10P;

    invoke-virtual {v0}, LX/10P;->A04()V

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    invoke-static {v0}, LX/001;->A1Z(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {p0, v0}, LX/10Z;->A15(Z)V

    return-void

    :cond_2
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v1

    const-string/jumbo v0, "timestamp"

    invoke-virtual {v1, v0}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    move-result-wide v3

    iget-object v2, p0, LX/10Z;->A0Q:LX/2sJ;

    const-wide/16 v0, 0x3e8

    mul-long/2addr v3, v0

    invoke-virtual {v2}, LX/2sJ;->A0C()J

    move-result-wide v0

    invoke-virtual {v2, v3, v4, v0, v1}, LX/2sJ;->A0K(JJ)V

    iget-object v1, p0, LX/10Z;->A05:LX/43o;

    invoke-static {}, LX/10Z;->A04()Landroid/os/Message;

    move-result-object v0

    invoke-interface {v1, v0}, LX/43o;->Bk3(Landroid/os/Message;)V

    invoke-static {p0}, LX/10Z;->A0H(LX/10Z;)LX/306;

    move-result-object v0

    invoke-virtual {v0}, LX/306;->A01()V

    return-void
.end method

.method public final A0w(Landroid/os/Message;)V
    .locals 2

    iget-object v1, p0, LX/10Z;->A05:LX/43o;

    invoke-static {p1}, Landroid/os/Message;->obtain(Landroid/os/Message;)Landroid/os/Message;

    move-result-object v0

    invoke-interface {v1, v0}, LX/43o;->Bk3(Landroid/os/Message;)V

    invoke-static {p1}, LX/21k;->A00(Landroid/os/Message;)I

    move-result v1

    const/16 v0, 0x25

    if-ne v1, v0, :cond_0

    iget-object v0, p0, LX/10Z;->A03:LX/10P;

    invoke-virtual {v0}, LX/10P;->A02()V

    :cond_0
    return-void
.end method

.method public final A0x(Lcom/whatsapp/jid/UserJid;LX/2L5;Ljava/lang/String;ZZ)V
    .locals 65

    const-string v29, "ConnectionThread/connect/socket/disconnect "

    const-string v27, "ConnectionThread/connect/socket/closed"

    move-object/from16 v0, p0

    iget-object v1, v0, LX/10Z;->A0O:LX/2jQ;

    invoke-virtual {v1}, LX/2jQ;->A02()Z

    move-result v28

    move-object/from16 v44, p1

    if-nez p1, :cond_1

    if-nez v28, :cond_1

    const-string v0, "ConnectionThread/connect/ignored/jid null and not in companion reg"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->e(Ljava/lang/String;)V

    :cond_0
    return-void

    :cond_1
    iget-object v1, v0, LX/10Z;->A0j:LX/2eW;

    move-object/from16 v64, v1

    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, v0, LX/10Z;->A0p:LX/3GD;

    move-object/from16 v63, v1

    invoke-virtual/range {v63 .. v63}, LX/3GD;->A04()V

    iget-object v2, v0, LX/10Z;->A0I:LX/2ze;

    invoke-virtual {v2}, LX/2ze;->A03()Z

    move-result v1

    if-eqz v1, :cond_2

    const-string v1, "ConnectionThread/connect/not-allowed/clock"

    invoke-static {v1}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    iget-object v0, v0, LX/10Z;->A0g:LX/452;

    invoke-interface {v0}, LX/452;->BO2()V

    return-void

    :cond_2
    if-nez v28, :cond_3

    iget-object v1, v0, LX/10Z;->A14:LX/1bw;

    invoke-virtual {v1}, LX/1bw;->A08()Z

    move-result v1

    if-eqz v1, :cond_3

    const-string v0, "ConnectionThread/connect/not-allowed/login-failed"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    return-void

    :cond_3
    invoke-virtual {v2}, LX/2ze;->A02()Z

    move-result v1

    if-eqz v1, :cond_4

    const-string v1, "ConnectionThread/connect/not-allowed/software-expired"

    invoke-static {v1}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    iget-object v0, v0, LX/10Z;->A0g:LX/452;

    invoke-interface {v0}, LX/452;->BaP()V

    return-void

    :cond_4
    iget-object v1, v0, LX/10Z;->A0l:LX/2eW;

    invoke-virtual {v1}, LX/2eW;->A01()Z

    move-result v1

    if-eqz v1, :cond_5

    const-string v1, "ConnectionThread/connect/not-allowed/quit-flag-set"

    invoke-virtual {v0, v1}, LX/10Z;->A14(Ljava/lang/String;)V

    return-void

    :cond_5
    const-string v1, "ConnectionThread/connect"

    invoke-static {v1}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v10, v0, LX/10Z;->A0s:LX/7YY;

    invoke-virtual {v10}, LX/7YY;->A01()V

    iget-object v8, v0, LX/10Z;->A0g:LX/452;

    invoke-interface {v8}, LX/452;->BOb()V

    iget-object v1, v0, LX/10Z;->A01:LX/2o9;

    if-eqz v1, :cond_6

    invoke-virtual {v1}, LX/2o9;->A03()Z

    move-result v1

    if-nez v1, :cond_6

    invoke-virtual {v0}, LX/10Z;->A0i()V

    :cond_6
    iget-object v1, v0, LX/10Z;->A0h:LX/2l6;

    invoke-virtual {v1}, LX/2l6;->A00()Ljava/util/ArrayList;

    move-result-object v22

    iget-object v1, v0, LX/10Z;->A0Q:LX/2sJ;

    move-object/from16 v62, v1

    invoke-virtual/range {v62 .. v62}, LX/2sJ;->A0E()J

    move-result-wide v48

    iget-object v1, v0, LX/10Z;->A0T:LX/354;

    move-object/from16 v51, v1

    invoke-virtual/range {v51 .. v51}, LX/354;->A01()I

    move-result v1

    const/4 v5, 0x1

    add-int/lit8 v25, v1, 0x1

    const/4 v3, 0x0

    const/4 v2, -0x1

    const/4 v4, 0x0

    new-instance v1, LX/2qt;

    invoke-direct {v1, v4, v3, v2, v3}, LX/2qt;-><init>(LX/2GN;III)V

    new-instance v61, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct/range {v61 .. v61}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/16 v52, 0x5

    :try_start_0
    move/from16 v16, p4

    invoke-static {v5}, Landroid/net/TrafficStats;->setThreadStatsTag(I)V

    iget-object v7, v0, LX/10Z;->A0X:LX/3J0;

    iget-object v12, v0, LX/10Z;->A0Y:LX/1Pl;

    iget-object v4, v0, LX/10Z;->A13:LX/2zD;

    invoke-virtual {v4}, LX/2zD;->A00()LX/2zw;

    move-result-object v20

    iget-object v4, v0, LX/10Z;->A1G:Ljava/util/Random;

    const/4 v5, -0x1

    const/4 v6, 0x0

    new-instance v26, LX/34X;

    move-object/from16 v21, p3

    move-object/from16 v17, v26

    move-object/from16 v18, v7

    move-object/from16 v19, v12

    move-object/from16 v23, v4

    invoke-direct/range {v17 .. v23}, LX/34X;-><init>(LX/3J0;LX/1Pl;LX/2zw;Ljava/lang/String;Ljava/util/List;Ljava/util/Random;)V

    invoke-virtual/range {v51 .. v51}, LX/354;->A05()I

    move-result v7

    move-object/from16 v4, v26

    invoke-virtual {v4, v7}, LX/34X;->A04(I)V

    const/4 v7, 0x0

    const/16 v21, -0x1
    :try_end_0
    .catch LX/1y0; {:try_start_0 .. :try_end_0} :catch_1b
    .catchall {:try_start_0 .. :try_end_0} :catchall_c

    :goto_0
    :try_start_1
    invoke-virtual/range {v26 .. v26}, LX/34X;->A05()Z

    move-result v2

    if-eqz v2, :cond_2a

    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v2

    if-nez v2, :cond_2a

    add-int/lit8 v24, v3, 0x1
    :try_end_1
    .catch LX/1y0; {:try_start_1 .. :try_end_1} :catch_18
    .catchall {:try_start_1 .. :try_end_1} :catchall_b

    :try_start_2
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v2, "ConnectionThread/connect: connecting; attempt="

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move/from16 v2, v24

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " state="

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {v26 .. v26}, LX/34X;->A01()I

    move-result v2

    invoke-static {v3, v2}, LX/0yK;->A1E(Ljava/lang/StringBuilder;I)V
    :try_end_2
    .catch LX/1y0; {:try_start_2 .. :try_end_2} :catch_1a
    .catchall {:try_start_2 .. :try_end_2} :catchall_f

    :try_start_3
    invoke-virtual/range {v26 .. v26}, LX/34X;->A01()I

    move-result v3

    new-instance v9, LX/2qt;

    const/4 v4, 0x0
    :try_end_3
    .catch LX/1tC; {:try_start_3 .. :try_end_3} :catch_15
    .catch LX/1tH; {:try_start_3 .. :try_end_3} :catch_14
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_d
    .catch LX/1yQ; {:try_start_3 .. :try_end_3} :catch_c
    .catch LX/1xv; {:try_start_3 .. :try_end_3} :catch_13
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    :try_start_4
    invoke-direct {v9, v4, v6, v5, v3}, LX/2qt;-><init>(LX/2GN;III)V
    :try_end_4
    .catch LX/1tC; {:try_start_4 .. :try_end_4} :catch_16
    .catch LX/1tH; {:try_start_4 .. :try_end_4} :catch_12
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_b
    .catch LX/1yQ; {:try_start_4 .. :try_end_4} :catch_a
    .catch LX/1xv; {:try_start_4 .. :try_end_4} :catch_11
    .catchall {:try_start_4 .. :try_end_4} :catchall_5

    :try_start_5
    move-object/from16 v1, v26

    invoke-virtual {v0, v1, v3}, LX/10Z;->A0e(LX/34X;I)LX/2wH;

    move-result-object v5

    iget v4, v5, LX/2wH;->A00:I

    iget-object v2, v5, LX/2wH;->A02:LX/2GN;

    new-instance v1, LX/2qt;

    invoke-direct {v1, v2, v6, v4, v3}, LX/2qt;-><init>(LX/2GN;III)V
    :try_end_5
    .catch LX/1tC; {:try_start_5 .. :try_end_5} :catch_10
    .catch LX/1tH; {:try_start_5 .. :try_end_5} :catch_f
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_8
    .catch LX/1yQ; {:try_start_5 .. :try_end_5} :catch_6
    .catch LX/1xv; {:try_start_5 .. :try_end_5} :catch_e
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    :try_start_6
    invoke-virtual {v0, v5, v3}, LX/10Z;->A0d(LX/2wH;I)LX/2NO;

    move-result-object v6

    iget-object v1, v6, LX/2NO;->A01:LX/2qt;
    :try_end_6
    .catch LX/1tC; {:try_start_6 .. :try_end_6} :catch_15
    .catch LX/1tH; {:try_start_6 .. :try_end_6} :catch_14
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_d
    .catch LX/1yQ; {:try_start_6 .. :try_end_6} :catch_c
    .catch LX/1xv; {:try_start_6 .. :try_end_6} :catch_13
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    :try_start_7
    new-instance v4, LX/10S;

    invoke-direct {v4, v0}, LX/10S;-><init>(LX/10Z;)V
    :try_end_7
    .catch LX/1tC; {:try_start_7 .. :try_end_7} :catch_15
    .catch LX/1tH; {:try_start_7 .. :try_end_7} :catch_14
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_5
    .catch LX/1yQ; {:try_start_7 .. :try_end_7} :catch_4
    .catch LX/1xv; {:try_start_7 .. :try_end_7} :catch_13
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    :try_start_8
    new-instance v3, LX/2zO;

    move-object/from16 v2, v62

    invoke-direct {v3, v2, v4}, LX/2zO;-><init>(LX/2sJ;LX/3zs;)V

    invoke-virtual/range {v51 .. v51}, LX/354;->A1Z()Z

    move-result v23

    invoke-virtual/range {v63 .. v63}, LX/3GD;->A08()Z

    move-result v2

    if-nez v2, :cond_8
    :try_end_8
    .catch LX/1tC; {:try_start_8 .. :try_end_8} :catch_16
    .catch LX/1tH; {:try_start_8 .. :try_end_8} :catch_12
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_b
    .catch LX/1yQ; {:try_start_8 .. :try_end_8} :catch_a
    .catch LX/1xv; {:try_start_8 .. :try_end_8} :catch_11
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    :try_start_9
    iget-object v2, v0, LX/10Z;->A0o:LX/2q0;

    invoke-virtual {v2}, LX/2q0;->A04()Z

    move-result v2

    if-nez v2, :cond_8

    iget-object v2, v0, LX/10Z;->A06:LX/10Y;

    invoke-virtual {v2}, LX/10Y;->A02()Z

    move-result v2

    if-eqz v2, :cond_7

    const/16 v2, 0x1384    # 7.001E-42f

    invoke-virtual {v12, v2}, LX/2sp;->A0V(I)Z

    move-result v2

    if-eqz v2, :cond_7

    goto :goto_1

    :cond_7
    const/16 v22, 0x0

    goto :goto_2

    :cond_8
    :goto_1
    const/16 v22, 0x1

    :goto_2
    if-nez v28, :cond_a

    if-nez p5, :cond_9

    if-nez v22, :cond_9

    if-eqz v23, :cond_a

    :cond_9
    const/4 v15, 0x1

    goto :goto_3

    :cond_a
    const/4 v15, 0x0
    :try_end_9
    .catch LX/1tC; {:try_start_9 .. :try_end_9} :catch_16
    .catch LX/1tH; {:try_start_9 .. :try_end_9} :catch_12
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_b
    .catch LX/1yQ; {:try_start_9 .. :try_end_9} :catch_a
    .catch LX/1xv; {:try_start_9 .. :try_end_9} :catch_11
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    :goto_3
    :try_start_a
    iget-object v5, v0, LX/10Z;->A0e:LX/2i2;

    iget v14, v1, LX/2qt;->A03:I

    iget-object v2, v1, LX/2qt;->A04:LX/2GN;

    move-object/from16 v45, p2

    move-object/from16 v42, v5

    move-object/from16 v43, v2

    move/from16 v46, v14

    move/from16 v47, v25

    move/from16 v50, v15

    invoke-virtual/range {v42 .. v50}, LX/2i2;->A02(LX/2GN;Lcom/whatsapp/jid/UserJid;LX/2L5;IIJZ)LX/1EU;

    move-result-object v54

    invoke-virtual {v1, v15}, LX/2qt;->A02(Z)V

    if-eqz v28, :cond_b

    const/16 v59, 0x0

    goto :goto_4

    :cond_b
    iget-object v2, v0, LX/10Z;->A0B:LX/31x;

    invoke-virtual {v2}, LX/31x;->A09()LX/3jT;

    move-result-object v59

    :goto_4
    iget-object v9, v0, LX/10Z;->A0B:LX/31x;

    invoke-virtual {v9}, LX/31x;->A03()LX/2GO;

    move-result-object v5

    iget v2, v5, LX/2GO;->A00:I

    move/from16 v21, v2

    iget-object v2, v5, LX/2GO;->A01:LX/3jU;

    if-eqz v2, :cond_20
    :try_end_a
    .catch LX/1tC; {:try_start_a .. :try_end_a} :catch_16
    .catch LX/1tH; {:try_start_a .. :try_end_a} :catch_12
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_b
    .catch LX/1yQ; {:try_start_a .. :try_end_a} :catch_a
    .catch LX/1xv; {:try_start_a .. :try_end_a} :catch_11
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    :try_start_b
    iget-object v11, v6, LX/2NO;->A02:Ljava/io/InputStream;

    iget-object v5, v6, LX/2NO;->A03:Ljava/io/OutputStream;

    move-object/from16 v53, v0

    move-object/from16 v55, v1

    move-object/from16 v56, v11

    move-object/from16 v57, v5

    move-object/from16 v58, v2

    invoke-virtual/range {v53 .. v59}, LX/10Z;->A0g(LX/1EU;LX/2qt;Ljava/io/InputStream;Ljava/io/OutputStream;LX/3jU;LX/3jT;)LX/319;

    move-result-object v11

    invoke-virtual {v11}, LX/319;->A04()LX/3jT;

    move-result-object v5

    if-eqz v59, :cond_c
    :try_end_b
    .catch LX/1tC; {:try_start_b .. :try_end_b} :catch_16
    .catch LX/1tH; {:try_start_b .. :try_end_b} :catch_12
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_3
    .catch LX/1yQ; {:try_start_b .. :try_end_b} :catch_2
    .catch LX/1xv; {:try_start_b .. :try_end_b} :catch_11
    .catchall {:try_start_b .. :try_end_b} :catchall_1

    :try_start_c
    invoke-virtual/range {v59 .. v59}, LX/3jT;->A00()[B

    move-result-object v6

    goto :goto_5

    :cond_c
    const/4 v6, 0x0
    :try_end_c
    .catch LX/1tC; {:try_start_c .. :try_end_c} :catch_16
    .catch LX/1tH; {:try_start_c .. :try_end_c} :catch_12
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_c} :catch_b
    .catch LX/1yQ; {:try_start_c .. :try_end_c} :catch_a
    .catch LX/1xv; {:try_start_c .. :try_end_c} :catch_11
    .catchall {:try_start_c .. :try_end_c} :catchall_5

    :goto_5
    :try_start_d
    invoke-virtual {v5}, LX/3jT;->A00()[B

    move-result-object v2

    invoke-static {v6, v2}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v2

    if-nez v2, :cond_d
    :try_end_d
    .catch LX/1tC; {:try_start_d .. :try_end_d} :catch_16
    .catch LX/1tH; {:try_start_d .. :try_end_d} :catch_12
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_d} :catch_3
    .catch LX/1yQ; {:try_start_d .. :try_end_d} :catch_2
    .catch LX/1xv; {:try_start_d .. :try_end_d} :catch_11
    .catchall {:try_start_d .. :try_end_d} :catchall_1

    :try_start_e
    invoke-virtual {v9, v5}, LX/31x;->A0E(LX/3jT;)V
    :try_end_e
    .catch LX/1tC; {:try_start_e .. :try_end_e} :catch_16
    .catch LX/1tH; {:try_start_e .. :try_end_e} :catch_12
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_e} :catch_b
    .catch LX/1yQ; {:try_start_e .. :try_end_e} :catch_a
    .catch LX/1xv; {:try_start_e .. :try_end_e} :catch_11
    .catchall {:try_start_e .. :try_end_e} :catchall_5

    :cond_d
    :try_start_f
    new-instance v6, LX/2Sk;

    invoke-direct {v6}, LX/2Sk;-><init>()V

    iget-object v5, v0, LX/10Z;->A0D:LX/2qa;

    invoke-virtual {v11}, LX/319;->A01()LX/2Ix;

    move-result-object v2
    :try_end_f
    .catch LX/1tC; {:try_start_f .. :try_end_f} :catch_16
    .catch LX/1tH; {:try_start_f .. :try_end_f} :catch_12
    .catch Ljava/io/IOException; {:try_start_f .. :try_end_f} :catch_3
    .catch LX/1yQ; {:try_start_f .. :try_end_f} :catch_2
    .catch LX/1xv; {:try_start_f .. :try_end_f} :catch_11
    .catchall {:try_start_f .. :try_end_f} :catchall_1

    :try_start_10
    new-instance v13, LX/34d;

    invoke-direct {v13, v5, v6, v2}, LX/34d;-><init>(LX/2qa;LX/2Sk;LX/2Ix;)V
    :try_end_10
    .catch LX/1tC; {:try_start_10 .. :try_end_10} :catch_16
    .catch LX/1tH; {:try_start_10 .. :try_end_10} :catch_12
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_10} :catch_b
    .catch LX/1yQ; {:try_start_10 .. :try_end_10} :catch_a
    .catch LX/1xv; {:try_start_10 .. :try_end_10} :catch_11
    .catchall {:try_start_10 .. :try_end_10} :catchall_1

    :try_start_11
    invoke-virtual {v11}, LX/319;->A02()LX/2Xp;

    move-result-object v2

    new-instance v11, LX/37c;

    invoke-direct {v11, v5, v12, v6, v2}, LX/37c;-><init>(LX/2qa;LX/1Pl;LX/2Sk;LX/2Xp;)V

    invoke-static {}, LX/0yT;->A1F()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v9

    iget-object v2, v0, LX/10Z;->A0E:LX/2TN;

    invoke-virtual {v2, v3}, LX/2TN;->A00(LX/2zO;)LX/2Mi;

    move-result-object v2

    invoke-virtual {v0, v2, v3, v9}, LX/10Z;->A0f(LX/2Mi;LX/2zO;Ljava/util/Map;)Ljava/util/Map;

    move-result-object v42

    iget-object v2, v0, LX/10Z;->A0F:LX/2sr;

    move-object/from16 v33, v2

    iget-object v2, v0, LX/10Z;->A0V:LX/2ss;

    move-object/from16 v20, v2

    iget-object v2, v0, LX/10Z;->A0a:LX/44u;

    move-object/from16 v19, v2

    iget-object v2, v0, LX/10Z;->A0m:LX/34u;

    move-object/from16 v18, v2

    iget-object v2, v0, LX/10Z;->A1C:LX/3VU;

    move-object/from16 v17, v2

    iget-object v6, v0, LX/10Z;->A0A:LX/1cV;

    new-instance v2, LX/31H;

    move-object/from16 v30, v2

    move-object/from16 v31, v6

    move-object/from16 v32, v5

    move-object/from16 v34, v62

    move-object/from16 v35, v20

    move-object/from16 v36, v12

    move-object/from16 v37, v19

    move-object/from16 v38, v3

    move-object/from16 v39, v18

    move-object/from16 v40, v13

    move-object/from16 v41, v17

    move-object/from16 v43, v9

    invoke-direct/range {v30 .. v43}, LX/31H;-><init>(LX/1cV;LX/2qa;LX/2sr;LX/2sJ;LX/2ss;LX/1Pl;LX/44u;LX/2zO;LX/34u;LX/34d;LX/3VU;Ljava/util/Map;Ljava/util/Map;)V

    iput-object v2, v0, LX/10Z;->A07:LX/31H;

    new-instance v6, LX/2Bm;

    invoke-direct {v6, v0}, LX/2Bm;-><init>(LX/10Z;)V

    iget-object v2, v0, LX/10Z;->A0R:LX/2iX;

    move-object/from16 v19, v2

    iget-object v2, v0, LX/10Z;->A1A:LX/454;

    move-object/from16 v18, v2

    iget-object v2, v0, LX/10Z;->A0J:LX/3RL;

    move-object/from16 v32, v2

    iget-object v2, v0, LX/10Z;->A0o:LX/2q0;

    move-object/from16 v38, v2

    iget-object v2, v0, LX/10Z;->A0u:LX/2qy;

    move-object/from16 v17, v2

    new-instance v2, LX/31G;

    move-object/from16 v30, v2

    move-object/from16 v31, v5

    move-object/from16 v33, v19

    move-object/from16 v34, v51

    move-object/from16 v35, v12

    move-object/from16 v36, v6

    move-object/from16 v37, v3

    move-object/from16 v39, v17

    move-object/from16 v40, v11

    move-object/from16 v41, v18

    move-object/from16 v42, v9

    invoke-direct/range {v30 .. v42}, LX/31G;-><init>(LX/2qa;LX/3RL;LX/2iX;LX/354;LX/1Pl;LX/2Bm;LX/2zO;LX/2q0;LX/2qy;LX/37c;LX/454;Ljava/util/Map;)V

    iput-object v2, v0, LX/10Z;->A08:LX/31G;

    new-instance v60, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct/range {v60 .. v60}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    if-nez v28, :cond_e
    :try_end_11
    .catch LX/1tC; {:try_start_11 .. :try_end_11} :catch_16
    .catch LX/1tH; {:try_start_11 .. :try_end_11} :catch_12
    .catch Ljava/io/IOException; {:try_start_11 .. :try_end_11} :catch_3
    .catch LX/1yQ; {:try_start_11 .. :try_end_11} :catch_2
    .catch LX/1xv; {:try_start_11 .. :try_end_11} :catch_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_1

    :try_start_12
    iget-object v2, v0, LX/10Z;->A08:LX/31G;

    move-object/from16 v55, v0

    move-object/from16 v56, v54

    move-object/from16 v57, v13

    move-object/from16 v58, v2

    move-object/from16 v59, v1

    invoke-virtual/range {v55 .. v61}, LX/10Z;->A0z(LX/1EU;LX/34d;LX/31G;LX/2qt;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicReference;)V

    const/16 v6, 0x11

    goto :goto_6

    :cond_e
    const/4 v6, 0x3
    :try_end_12
    .catch LX/1tC; {:try_start_12 .. :try_end_12} :catch_16
    .catch LX/1tH; {:try_start_12 .. :try_end_12} :catch_12
    .catch Ljava/io/IOException; {:try_start_12 .. :try_end_12} :catch_b
    .catch LX/1yQ; {:try_start_12 .. :try_end_12} :catch_a
    .catch LX/1xv; {:try_start_12 .. :try_end_12} :catch_11
    .catchall {:try_start_12 .. :try_end_12} :catchall_5

    :goto_6
    :try_start_13
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v2, "ConnectionThread/connect: switching to "

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " minute read timeout; sessionId="

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object v9, v1
    :try_end_13
    .catch LX/1tC; {:try_start_13 .. :try_end_13} :catch_16
    .catch LX/1tH; {:try_start_13 .. :try_end_13} :catch_12
    .catch Ljava/io/IOException; {:try_start_13 .. :try_end_13} :catch_3
    .catch LX/1yQ; {:try_start_13 .. :try_end_13} :catch_2
    .catch LX/1xv; {:try_start_13 .. :try_end_13} :catch_11
    .catchall {:try_start_13 .. :try_end_13} :catchall_1

    :try_start_14
    invoke-static {v3, v14}, LX/0yK;->A1E(Ljava/lang/StringBuilder;I)V

    iget-object v2, v0, LX/10Z;->A01:LX/2o9;

    mul-int/lit8 v3, v6, 0x3c

    mul-int/lit16 v3, v3, 0x3e8

    invoke-virtual {v2, v3}, LX/2o9;->A02(I)V

    invoke-virtual/range {v62 .. v62}, LX/2sJ;->A0G()J

    move-result-wide v2

    iput-wide v2, v0, LX/10Z;->A00:J

    iget-object v2, v0, LX/10Z;->A08:LX/31G;

    invoke-virtual {v2}, LX/31G;->A08()Z

    move-result v3

    iget-object v2, v0, LX/10Z;->A17:LX/3GB;

    invoke-virtual {v2}, LX/3GB;->A00()V

    if-eqz v3, :cond_f
    :try_end_14
    .catch LX/1tC; {:try_start_14 .. :try_end_14} :catch_16
    .catch LX/1tH; {:try_start_14 .. :try_end_14} :catch_12
    .catch Ljava/io/IOException; {:try_start_14 .. :try_end_14} :catch_9
    .catch LX/1yQ; {:try_start_14 .. :try_end_14} :catch_7
    .catch LX/1xv; {:try_start_14 .. :try_end_14} :catch_11
    .catchall {:try_start_14 .. :try_end_14} :catchall_a

    :try_start_15
    const/16 v2, 0x699

    invoke-virtual {v12, v2}, LX/2sp;->A0V(I)Z

    move-result v2

    if-eqz v2, :cond_f

    iget-object v2, v0, LX/10Z;->A0L:LX/2Xx;

    invoke-virtual {v2}, LX/2Xx;->A00()V
    :try_end_15
    .catch LX/1tC; {:try_start_15 .. :try_end_15} :catch_16
    .catch LX/1tH; {:try_start_15 .. :try_end_15} :catch_12
    .catch Ljava/io/IOException; {:try_start_15 .. :try_end_15} :catch_b
    .catch LX/1yQ; {:try_start_15 .. :try_end_15} :catch_a
    .catch LX/1xv; {:try_start_15 .. :try_end_15} :catch_11
    .catchall {:try_start_15 .. :try_end_15} :catchall_a

    :cond_f
    :try_start_16
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v2, "ConnectionThread/connect: fetching client config; sessionId="

    invoke-static {v2, v3, v14}, LX/0yK;->A0w(Ljava/lang/String;Ljava/lang/StringBuilder;I)V

    iget-object v2, v0, LX/10Z;->A08:LX/31G;

    invoke-virtual {v2}, LX/31G;->A04()V

    if-nez v28, :cond_14
    :try_end_16
    .catch LX/1tC; {:try_start_16 .. :try_end_16} :catch_16
    .catch LX/1tH; {:try_start_16 .. :try_end_16} :catch_12
    .catch Ljava/io/IOException; {:try_start_16 .. :try_end_16} :catch_9
    .catch LX/1yQ; {:try_start_16 .. :try_end_16} :catch_7
    .catch LX/1xv; {:try_start_16 .. :try_end_16} :catch_11
    .catchall {:try_start_16 .. :try_end_16} :catchall_a

    :try_start_17
    invoke-virtual/range {v32 .. v32}, LX/3RL;->A02()I

    move-result v2

    invoke-virtual/range {v60 .. v60}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    if-eqz v3, :cond_10

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    if-eq v3, v2, :cond_10

    iget-object v2, v0, LX/10Z;->A08:LX/31G;

    const/4 v6, 0x1

    :goto_7
    invoke-virtual {v2, v6}, LX/31G;->A07(Z)V

    goto :goto_8

    :cond_10
    const/4 v6, 0x1

    iget-object v2, v0, LX/10Z;->A0U:LX/2oI;

    invoke-virtual {v2}, LX/2oI;->A03()Z

    move-result v2

    if-eqz v2, :cond_11

    iget-object v2, v0, LX/10Z;->A08:LX/31G;

    goto :goto_7

    :cond_11
    invoke-virtual/range {v62 .. v62}, LX/2sJ;->A0B()J

    move-result-wide v19

    invoke-virtual/range {v32 .. v32}, LX/3RL;->A05()J

    move-result-wide v17

    invoke-virtual/range {v32 .. v32}, LX/3RL;->A04()J

    move-result-wide v13

    add-long v13, v13, v17

    cmp-long v2, v13, v19

    if-ltz v2, :cond_12

    cmp-long v2, v19, v17

    if-gez v2, :cond_13

    :cond_12
    iget-object v3, v0, LX/10Z;->A08:LX/31G;

    const/4 v2, 0x0

    invoke-virtual {v3, v2}, LX/31G;->A07(Z)V

    :cond_13
    :goto_8
    if-eqz p4, :cond_15

    iget-object v2, v0, LX/10Z;->A08:LX/31G;

    invoke-virtual {v2}, LX/31G;->A03()V

    goto :goto_9

    :cond_14
    const/4 v6, 0x1
    :try_end_17
    .catch LX/1tC; {:try_start_17 .. :try_end_17} :catch_16
    .catch LX/1tH; {:try_start_17 .. :try_end_17} :catch_12
    .catch Ljava/io/IOException; {:try_start_17 .. :try_end_17} :catch_b
    .catch LX/1yQ; {:try_start_17 .. :try_end_17} :catch_a
    .catch LX/1xv; {:try_start_17 .. :try_end_17} :catch_11
    .catchall {:try_start_17 .. :try_end_17} :catchall_a

    :cond_15
    :goto_9
    :try_start_18
    iget-object v3, v0, LX/10Z;->A07:LX/31H;

    new-instance v2, LX/1nq;

    invoke-direct {v2, v5, v4, v3}, LX/1nq;-><init>(LX/2qa;LX/3xi;LX/31H;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    move-object/from16 v2, v64

    invoke-virtual {v2, v6}, LX/2eW;->A00(Z)V

    iget-object v2, v0, LX/10Z;->A01:LX/2o9;

    invoke-virtual {v2}, LX/2o9;->A00()Ljava/net/InetAddress;

    move-result-object v2

    instance-of v7, v2, Ljava/net/Inet6Address;
    :try_end_18
    .catch LX/1tC; {:try_start_18 .. :try_end_18} :catch_16
    .catch LX/1tH; {:try_start_18 .. :try_end_18} :catch_12
    .catch Ljava/io/IOException; {:try_start_18 .. :try_end_18} :catch_9
    .catch LX/1yQ; {:try_start_18 .. :try_end_18} :catch_7
    .catch LX/1xv; {:try_start_18 .. :try_end_18} :catch_11
    .catchall {:try_start_18 .. :try_end_18} :catchall_a

    :try_start_19
    const/4 v3, 0x0

    move-object/from16 v2, v51

    invoke-virtual {v2, v3}, LX/354;->A0Z(I)V

    iput-object v4, v0, LX/10Z;->A02:LX/10S;

    if-nez v28, :cond_1e

    if-nez p5, :cond_19

    if-eqz v22, :cond_19

    invoke-virtual/range {v38 .. v38}, LX/2q0;->A00()Ljava/util/List;

    move-result-object v11

    invoke-virtual/range {v38 .. v38}, LX/2q0;->A02()Ljava/util/List;

    move-result-object v9

    invoke-virtual/range {v38 .. v38}, LX/2q0;->A01()Ljava/util/List;

    move-result-object v5

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_16

    iget-object v3, v0, LX/10Z;->A05:LX/43o;

    invoke-static {v11}, LX/10Z;->A06(Ljava/util/List;)Landroid/os/Message;

    move-result-object v2

    invoke-interface {v3, v2}, LX/43o;->Bk3(Landroid/os/Message;)V

    :cond_16
    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_17

    iget-object v3, v0, LX/10Z;->A05:LX/43o;

    invoke-static {v9}, LX/10Z;->A08(Ljava/util/List;)Landroid/os/Message;

    move-result-object v2

    invoke-interface {v3, v2}, LX/43o;->Bk3(Landroid/os/Message;)V

    :cond_17
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_18

    iget-object v3, v0, LX/10Z;->A05:LX/43o;

    invoke-static {v5}, LX/10Z;->A07(Ljava/util/List;)Landroid/os/Message;

    move-result-object v2

    invoke-interface {v3, v2}, LX/43o;->Bk3(Landroid/os/Message;)V

    :cond_18
    invoke-virtual/range {v63 .. v63}, LX/3GD;->A02()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_19

    invoke-static {v2, v6}, LX/0yT;->A07(Ljava/util/List;I)I

    move-result v3

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LX/2l8;

    iput-object v3, v0, LX/10Z;->A04:LX/2l8;

    invoke-interface {v2}, Ljava/util/List;->size()I

    iget-object v3, v0, LX/10Z;->A05:LX/43o;

    invoke-static {v2}, LX/10Z;->A09(Ljava/util/List;)Landroid/os/Message;

    move-result-object v2

    invoke-interface {v3, v2}, LX/43o;->Bk3(Landroid/os/Message;)V

    :cond_19
    if-eqz v23, :cond_1a
    :try_end_19
    .catch LX/1tC; {:try_start_19 .. :try_end_19} :catch_16
    .catch LX/1tH; {:try_start_19 .. :try_end_19} :catch_12
    .catch Ljava/io/IOException; {:try_start_19 .. :try_end_19} :catch_b
    .catch LX/1yQ; {:try_start_19 .. :try_end_19} :catch_a
    .catch LX/1xv; {:try_start_19 .. :try_end_19} :catch_11
    .catchall {:try_start_19 .. :try_end_19} :catchall_5

    :try_start_1a
    iget-object v2, v0, LX/10Z;->A0H:LX/1cE;

    invoke-virtual {v2}, LX/1cE;->A08()V

    goto :goto_a
    :try_end_1a
    .catch Ljava/lang/InterruptedException; {:try_start_1a .. :try_end_1a} :catch_1
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_1a .. :try_end_1a} :catch_0
    .catch LX/1tC; {:try_start_1a .. :try_end_1a} :catch_16
    .catch LX/1tH; {:try_start_1a .. :try_end_1a} :catch_12
    .catch Ljava/io/IOException; {:try_start_1a .. :try_end_1a} :catch_b
    .catch LX/1yQ; {:try_start_1a .. :try_end_1a} :catch_a
    .catch LX/1xv; {:try_start_1a .. :try_end_1a} :catch_11
    .catchall {:try_start_1a .. :try_end_1a} :catchall_5

    :catch_0
    move-exception v3

    :try_start_1b
    const-string v2, "ConnectionThread/connect/signal/execution-exception"

    invoke-static {v2, v3}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_a

    :catch_1
    move-exception v3

    const-string v2, "ConnectionThread/connect/signal/interrupted-exception"

    invoke-static {v2, v3}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_a

    :cond_1a
    invoke-virtual/range {v51 .. v51}, LX/354;->A1Y()Z

    move-result v2

    if-eqz v2, :cond_1b

    iget-object v2, v0, LX/10Z;->A0H:LX/1cE;

    invoke-virtual {v2}, LX/1cE;->A0A()V

    :cond_1b
    :goto_a
    if-nez p5, :cond_1c

    if-eqz v15, :cond_1c

    iget-object v3, v0, LX/10Z;->A05:LX/43o;

    invoke-static {v6}, LX/385;->A06(Z)Landroid/os/Message;

    move-result-object v2

    invoke-interface {v3, v2}, LX/43o;->Bk3(Landroid/os/Message;)V

    iget-object v2, v0, LX/10Z;->A03:LX/10P;

    invoke-virtual {v2}, LX/10P;->A02()V

    :cond_1c
    invoke-virtual/range {v51 .. v51}, LX/354;->A0F()Ljava/lang/Integer;

    move-result-object v5

    if-eqz v5, :cond_1d

    iget-object v2, v0, LX/10Z;->A0W:LX/3jF;

    invoke-virtual {v2}, LX/3jF;->A07()Z

    move-result v2

    if-eqz v2, :cond_1d

    iget-object v3, v0, LX/10Z;->A0b:LX/3QV;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {v3, v2, v6}, LX/3QV;->A0D(IZ)V

    :cond_1d
    iget-object v3, v0, LX/10Z;->A0C:LX/2nR;

    invoke-virtual {v3}, LX/2nR;->A01()Z

    move-result v2

    if-eqz v2, :cond_1e

    if-eqz p4, :cond_1e

    invoke-virtual {v3}, LX/2nR;->A00()V

    :cond_1e
    const/16 v2, 0x4a6

    invoke-virtual {v12, v2}, LX/2sp;->A0V(I)Z

    move-result v2

    if-eqz v2, :cond_1f

    iget-object v2, v0, LX/10Z;->A08:LX/31G;

    iget-wide v5, v2, LX/31G;->A02:J

    iget-wide v2, v2, LX/31G;->A01:J

    invoke-virtual {v0, v5, v6, v2, v3}, LX/10Z;->A0t(JJ)V

    :cond_1f
    iget-object v2, v0, LX/10Z;->A08:LX/31G;

    iget-wide v5, v2, LX/31G;->A02:J

    const-wide/16 v13, 0x3e8

    mul-long/2addr v5, v13

    iget-wide v2, v2, LX/31G;->A01:J

    mul-long/2addr v2, v13

    move-object/from16 v9, v62

    invoke-virtual {v9, v5, v6, v2, v3}, LX/2sJ;->A0K(JJ)V

    goto :goto_15
    :try_end_1b
    .catch LX/1tC; {:try_start_1b .. :try_end_1b} :catch_16
    .catch LX/1tH; {:try_start_1b .. :try_end_1b} :catch_12
    .catch Ljava/io/IOException; {:try_start_1b .. :try_end_1b} :catch_b
    .catch LX/1yQ; {:try_start_1b .. :try_end_1b} :catch_a
    .catch LX/1xv; {:try_start_1b .. :try_end_1b} :catch_11
    .catchall {:try_start_1b .. :try_end_1b} :catchall_5

    :catch_2
    move-exception v3

    move-object v9, v1

    goto :goto_c

    :catch_3
    move-exception v3

    move-object v9, v1

    goto :goto_e

    :cond_20
    move-object v9, v1

    :try_start_1c
    const-string v2, "ConnectionThread/connect/failed to load auth key, postponing login"

    invoke-static {v2}, Lcom/whatsapp/util/Log;->e(Ljava/lang/String;)V

    const/4 v3, 0x0

    new-instance v2, LX/1tH;

    invoke-direct {v2, v3}, LX/1tH;-><init>(LX/2Bm;)V

    throw v2
    :try_end_1c
    .catch LX/1tC; {:try_start_1c .. :try_end_1c} :catch_16
    .catch LX/1tH; {:try_start_1c .. :try_end_1c} :catch_12
    .catch Ljava/io/IOException; {:try_start_1c .. :try_end_1c} :catch_b
    .catch LX/1yQ; {:try_start_1c .. :try_end_1c} :catch_a
    .catch LX/1xv; {:try_start_1c .. :try_end_1c} :catch_11
    .catchall {:try_start_1c .. :try_end_1c} :catchall_a

    :catch_4
    move-exception v3

    move-object v9, v1

    goto :goto_b

    :catch_5
    move-exception v3

    move-object v9, v1

    goto :goto_d

    :catch_6
    move-exception v3

    :goto_b
    const/4 v4, 0x0

    goto :goto_c

    :catch_7
    move-exception v3

    :goto_c
    move-object v1, v9

    goto :goto_f

    :catch_8
    move-exception v3

    :goto_d
    const/4 v4, 0x0

    goto :goto_e

    :catch_9
    move-exception v3

    :goto_e
    move-object v1, v9

    goto :goto_10

    :catch_a
    move-exception v3

    goto :goto_f

    :catch_b
    move-exception v3

    goto :goto_10

    :catch_c
    move-exception v3

    const/4 v4, 0x0

    :goto_f
    :try_start_1d
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v2, "ConnectionThread/connect/socket/next-port/corrupt-stream-exception "

    invoke-static {v3, v2, v5}, LX/000;->A0Q(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v3}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_11
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_5

    :catch_d
    move-exception v3

    const/4 v4, 0x0

    :goto_10
    :try_start_1e
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v5

    move-object/from16 v2, v29

    invoke-static {v3, v2, v5}, LX/000;->A0Q(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v3}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1e
    .catchall {:try_start_1e .. :try_end_1e} :catchall_5

    :try_start_1f
    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v2

    if-nez v2, :cond_26

    iget-object v2, v0, LX/10Z;->A01:LX/2o9;

    if-eqz v2, :cond_21

    invoke-virtual {v2}, LX/2o9;->A03()Z

    move-result v2

    if-nez v2, :cond_21

    goto :goto_12

    :goto_11
    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v2

    if-nez v2, :cond_26

    iget-object v2, v0, LX/10Z;->A01:LX/2o9;

    if-eqz v2, :cond_22

    invoke-virtual {v2}, LX/2o9;->A03()Z

    move-result v2

    if-nez v2, :cond_22

    :goto_12
    invoke-virtual {v0}, LX/10Z;->A0i()V

    goto :goto_14

    :cond_21
    iget-object v2, v0, LX/10Z;->A01:LX/2o9;

    if-eqz v2, :cond_23

    goto :goto_13

    :cond_22
    iget-object v2, v0, LX/10Z;->A01:LX/2o9;

    if-eqz v2, :cond_23

    :goto_13
    invoke-static/range {v27 .. v27}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    :cond_23
    :goto_14
    if-eqz v4, :cond_26

    goto :goto_16

    :goto_15
    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v2

    if-nez v2, :cond_26

    iget-object v2, v0, LX/10Z;->A01:LX/2o9;

    if-eqz v2, :cond_25

    invoke-virtual {v2}, LX/2o9;->A03()Z

    move-result v2

    if-nez v2, :cond_25

    invoke-virtual {v0}, LX/10Z;->A0i()V

    :cond_24
    :goto_16
    invoke-virtual {v4}, LX/10S;->A00()V

    goto :goto_17

    :cond_25
    iget-object v2, v0, LX/10Z;->A01:LX/2o9;

    if-eqz v2, :cond_24

    invoke-static/range {v27 .. v27}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    goto :goto_16

    :cond_26
    :goto_17
    move/from16 v3, v24

    const/4 v6, 0x0

    const/4 v5, -0x1

    goto/16 :goto_0
    :try_end_1f
    .catch LX/1y0; {:try_start_1f .. :try_end_1f} :catch_1a
    .catchall {:try_start_1f .. :try_end_1f} :catchall_f

    :catchall_0
    move-exception v5

    const/16 v6, 0x8

    const/4 v3, 0x0

    const/4 v9, 0x0

    goto :goto_20

    :catchall_1
    move-exception v5

    move-object v9, v1

    goto :goto_1d

    :catchall_2
    move-exception v5

    move-object v9, v1

    goto :goto_18

    :catchall_3
    move-exception v5

    :goto_18
    const/4 v4, 0x0

    goto :goto_1d

    :catch_e
    move-exception v3

    const/4 v4, 0x0

    move-object v1, v9

    goto :goto_19

    :catch_f
    move-exception v5

    const/4 v4, 0x0

    move-object v1, v9

    goto :goto_1a

    :catch_10
    move-exception v5

    const/4 v4, 0x0

    move-object v1, v9

    goto :goto_1b

    :catch_11
    move-exception v3

    goto :goto_19

    :catch_12
    move-exception v5

    goto :goto_1a

    :catchall_4
    move-exception v5

    const/4 v4, 0x0

    goto :goto_1e

    :catch_13
    move-exception v3

    const/4 v4, 0x0

    :goto_19
    :try_start_20
    const-string v2, "ConnectionThread/connect/socket/invalid-certificate-exception"

    invoke-static {v2, v3}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/16 v5, 0xa

    const/4 v3, -0x1

    new-instance v2, LX/1y0;

    invoke-direct {v2, v5, v3}, LX/1y0;-><init>(II)V

    throw v2
    :try_end_20
    .catchall {:try_start_20 .. :try_end_20} :catchall_5

    :catchall_5
    move-exception v5

    goto :goto_1e

    :catch_14
    move-exception v5

    const/4 v4, 0x0

    :goto_1a
    :try_start_21
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    move-object/from16 v2, v29

    invoke-static {v5, v2, v3}, LX/000;->A0Q(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v5}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, -0x1

    const/16 v6, 0x8
    :try_end_21
    .catchall {:try_start_21 .. :try_end_21} :catchall_6

    :try_start_22
    new-instance v2, LX/1y0;

    invoke-direct {v2, v6, v3}, LX/1y0;-><init>(II)V

    throw v2
    :try_end_22
    .catchall {:try_start_22 .. :try_end_22} :catchall_9

    :catchall_6
    move-exception v5

    const/16 v6, 0x8

    goto :goto_1f

    :catch_15
    move-exception v5

    const/4 v4, 0x0

    goto :goto_1b

    :catch_16
    move-exception v5

    :goto_1b
    const/16 v6, 0x8

    :try_start_23
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v2, "ConnectionThread/connect/socket/goaway"

    invoke-static {v5, v2, v3}, LX/000;->A0Q(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v5}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_23
    .catchall {:try_start_23 .. :try_end_23} :catchall_9

    :try_start_24
    invoke-virtual/range {v26 .. v26}, LX/34X;->A01()I

    move-result v3
    :try_end_24
    .catchall {:try_start_24 .. :try_end_24} :catchall_7

    :try_start_25
    const/4 v9, 0x6

    const/4 v5, -0x1

    new-instance v2, LX/1y0;

    invoke-direct {v2, v9, v5}, LX/1y0;-><init>(II)V

    throw v2
    :try_end_25
    .catchall {:try_start_25 .. :try_end_25} :catchall_8

    :catchall_7
    move-exception v5

    const/4 v3, 0x0

    goto :goto_1c

    :catchall_8
    move-exception v5

    :goto_1c
    const/4 v9, 0x1

    goto :goto_20

    :catchall_9
    move-exception v5

    goto :goto_1f

    :catchall_a
    move-exception v5

    :goto_1d
    move-object v1, v9

    :goto_1e
    const/16 v6, 0x8

    :goto_1f
    const/4 v3, 0x0

    const/4 v9, 0x0

    :goto_20
    :try_start_26
    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v2

    if-nez v2, :cond_29

    iget-object v2, v0, LX/10Z;->A01:LX/2o9;

    if-eqz v2, :cond_27

    invoke-virtual {v2}, LX/2o9;->A03()Z

    move-result v2

    if-nez v2, :cond_27

    invoke-virtual {v0}, LX/10Z;->A0i()V

    goto :goto_21

    :cond_27
    iget-object v2, v0, LX/10Z;->A01:LX/2o9;

    if-eqz v2, :cond_28

    invoke-static/range {v27 .. v27}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    :cond_28
    :goto_21
    if-eqz v4, :cond_29

    invoke-virtual {v4}, LX/10S;->A00()V

    :cond_29
    throw v5
    :try_end_26
    .catch LX/1y0; {:try_start_26 .. :try_end_26} :catch_17
    .catchall {:try_start_26 .. :try_end_26} :catchall_e

    :catch_17
    move-exception v4

    goto :goto_24

    :cond_2a
    const/16 v6, 0x8

    :try_start_27
    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v2

    if-nez v2, :cond_2b

    move-object/from16 v4, v51

    move/from16 v2, v25

    invoke-virtual {v4, v2}, LX/354;->A0Z(I)V
    :try_end_27
    .catch LX/1y0; {:try_start_27 .. :try_end_27} :catch_19
    .catchall {:try_start_27 .. :try_end_27} :catchall_b

    :cond_2b
    invoke-virtual/range {v51 .. v51}, LX/354;->A0O()V

    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v2

    if-eqz v2, :cond_2c

    const/16 v52, 0x1

    :cond_2c
    add-int/lit8 v53, v25, -0x1

    add-int/lit8 v54, v3, -0x1

    int-to-long v2, v5

    move-object/from16 v50, v0

    move-object/from16 v51, v1

    move/from16 v55, v21

    move-wide/from16 v56, v48

    move-wide/from16 v58, v2

    invoke-virtual/range {v50 .. v59}, LX/10Z;->A13(LX/2qt;IIIIJJ)V

    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v2

    if-nez v2, :cond_31

    invoke-virtual {v10, v1}, LX/7YY;->A04(LX/2qt;)V

    const/4 v0, 0x1

    invoke-interface {v8, v0}, LX/452;->BQ6(Z)V

    goto/16 :goto_27

    :catchall_b
    move-exception v5

    goto/16 :goto_28

    :catch_18
    move-exception v4

    const/16 v6, 0x8

    goto :goto_22

    :catch_19
    move-exception v4

    :goto_22
    move/from16 v24, v3

    goto :goto_23

    :catch_1a
    move-exception v4

    const/16 v6, 0x8

    :goto_23
    const/4 v3, 0x0

    const/4 v9, 0x0

    goto :goto_24

    :catchall_c
    move-exception v5

    const/16 v21, -0x1

    const/4 v7, 0x0

    goto/16 :goto_29

    :catch_1b
    move-exception v4

    const/16 v6, 0x8

    const/16 v21, -0x1

    const/4 v7, 0x0

    const/4 v9, 0x0

    const/16 v24, 0x0

    :goto_24
    :try_start_28
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v2, "ConnectionThread/connect/login/failure type:"

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, v4, LX/1y0;->type:I

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " code:"

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, v4, LX/1y0;->code:I

    invoke-static {v5, v2}, LX/001;->A0n(Ljava/lang/StringBuilder;I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v4}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)V

    iget v5, v4, LX/1y0;->type:I

    const/4 v2, 0x6

    if-ne v5, v2, :cond_2d

    const/4 v2, -0x1

    const/16 v44, 0x4

    goto :goto_25

    :cond_2d
    if-ne v5, v6, :cond_2e

    const/4 v2, -0x1

    const/16 v44, 0x6

    goto :goto_25

    :cond_2e
    const/16 v2, 0xa

    if-ne v5, v2, :cond_2f

    const/4 v2, -0x1

    const/16 v44, 0x7

    goto :goto_25

    :cond_2f
    iget v2, v4, LX/1y0;->serverErrorCode:I

    const/16 v44, 0x3
    :try_end_28
    .catchall {:try_start_28 .. :try_end_28} :catchall_e

    :goto_25
    :try_start_29
    invoke-interface {v8, v4}, LX/452;->BUb(LX/1y0;)V
    :try_end_29
    .catchall {:try_start_29 .. :try_end_29} :catchall_d

    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v4

    if-nez v4, :cond_32

    if-eqz v9, :cond_32

    move-object/from16 v4, v51

    invoke-virtual {v4, v3}, LX/354;->A0e(I)V

    :goto_26
    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v3

    if-eqz v3, :cond_30

    const/16 v44, 0x1

    :cond_30
    add-int/lit8 v45, v25, -0x1

    add-int/lit8 v46, v24, -0x1

    int-to-long v2, v2

    move-object/from16 v42, v0

    move-object/from16 v43, v1

    move/from16 v47, v21

    move-wide/from16 v50, v2

    invoke-virtual/range {v42 .. v51}, LX/10Z;->A13(LX/2qt;IIIIJJ)V

    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v2

    if-nez v2, :cond_31

    invoke-virtual {v10, v1}, LX/7YY;->A04(LX/2qt;)V

    :goto_27
    invoke-static {}, Landroid/net/TrafficStats;->clearThreadStatsTag()V

    return-void

    :cond_31
    iget v4, v1, LX/2qt;->A03:I

    invoke-virtual/range {v61 .. v61}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    move/from16 v2, v16

    invoke-interface {v8, v3, v4, v7, v2}, LX/452;->BOa(Ljava/lang/Integer;IZZ)V

    iget-object v3, v0, LX/10Z;->A05:LX/43o;

    iget-object v2, v0, LX/10Z;->A08:LX/31G;

    invoke-interface {v3, v2}, LX/43o;->Bjm(LX/31G;)V

    invoke-virtual {v10, v1}, LX/7YY;->A03(LX/2qt;)V

    invoke-static {v0}, LX/10Z;->A0H(LX/10Z;)LX/306;

    move-result-object v0

    invoke-virtual {v0, v1}, LX/306;->A03(LX/2qt;)V

    goto :goto_27

    :cond_32
    invoke-virtual/range {v51 .. v51}, LX/354;->A0O()V

    goto :goto_26

    :catchall_d
    move-exception v5

    move/from16 v3, v24

    goto :goto_29

    :catchall_e
    move-exception v5

    move/from16 v3, v24

    const/4 v2, -0x1

    goto :goto_29

    :catchall_f
    move-exception v5

    move/from16 v3, v24

    :goto_28
    const/4 v2, -0x1

    :goto_29
    invoke-virtual/range {v51 .. v51}, LX/354;->A0O()V

    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v4

    if-eqz v4, :cond_33

    const/16 v52, 0x1

    :cond_33
    add-int/lit8 v53, v25, -0x1

    add-int/lit8 v54, v3, -0x1

    int-to-long v2, v2

    move-object/from16 v50, v0

    move-object/from16 v51, v1

    move/from16 v55, v21

    move-wide/from16 v56, v48

    move-wide/from16 v58, v2

    invoke-virtual/range {v50 .. v59}, LX/10Z;->A13(LX/2qt;IIIIJJ)V

    invoke-virtual/range {v64 .. v64}, LX/2eW;->A01()Z

    move-result v2

    if-nez v2, :cond_34

    invoke-virtual {v10, v1}, LX/7YY;->A04(LX/2qt;)V

    const/4 v0, 0x1

    invoke-interface {v8, v0}, LX/452;->BQ6(Z)V

    :goto_2a
    invoke-static {}, Landroid/net/TrafficStats;->clearThreadStatsTag()V

    throw v5

    :cond_34
    iget v4, v1, LX/2qt;->A03:I

    invoke-virtual/range {v61 .. v61}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    move/from16 v2, v16

    invoke-interface {v8, v3, v4, v7, v2}, LX/452;->BOa(Ljava/lang/Integer;IZZ)V

    iget-object v3, v0, LX/10Z;->A05:LX/43o;

    iget-object v2, v0, LX/10Z;->A08:LX/31G;

    invoke-interface {v3, v2}, LX/43o;->Bjm(LX/31G;)V

    invoke-virtual {v10, v1}, LX/7YY;->A03(LX/2qt;)V

    invoke-static {v0}, LX/10Z;->A0H(LX/10Z;)LX/306;

    move-result-object v0

    invoke-virtual {v0, v1}, LX/306;->A03(LX/2qt;)V

    goto :goto_2a
.end method

.method public final A0y(LX/43o;)V
    .locals 2

    iput-object p1, p0, LX/10Z;->A05:LX/43o;

    iget-object v1, p0, LX/10Z;->A0g:LX/452;

    new-instance v0, LX/10T;

    invoke-direct {v0, p0}, LX/10T;-><init>(LX/10Z;)V

    invoke-interface {v1, v0}, LX/452;->BOe(LX/43n;)V

    return-void
.end method

.method public final A0z(LX/1EU;LX/34d;LX/31G;LX/2qt;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicReference;)V
    .locals 7

    :try_start_0
    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p5

    move-object v6, p6

    invoke-virtual/range {v1 .. v6}, LX/10Z;->A10(LX/1EU;LX/34d;LX/31G;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicReference;)V

    iget-object v0, p0, LX/10Z;->A0T:LX/354;

    invoke-virtual {v0}, LX/354;->A0S()V

    iget-object v0, p0, LX/10Z;->A0s:LX/7YY;

    invoke-virtual {v0, p4}, LX/7YY;->A07(LX/2qt;)V

    return-void
    :try_end_0
    .catch LX/1yQ; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catch LX/1y0; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception v2

    iget-object v1, p0, LX/10Z;->A0s:LX/7YY;

    const/16 v0, 0x9

    goto :goto_0

    :catch_1
    move-exception v2

    iget-object v1, p0, LX/10Z;->A0s:LX/7YY;

    const/4 v0, 0x7

    goto :goto_0

    :catch_2
    move-exception v2

    iget-object v1, p0, LX/10Z;->A0s:LX/7YY;

    const/16 v0, 0x8

    :goto_0
    invoke-virtual {v1, p4, v0}, LX/7YY;->A0A(LX/2qt;I)V

    throw v2
.end method

.method public final A10(LX/1EU;LX/34d;LX/31G;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicReference;)V
    .locals 12

    invoke-virtual {p1}, LX/1EU;->A0M()LX/1EX;

    move-result-object v0

    invoke-virtual {v0}, LX/1EX;->A0M()Z

    move-result v4

    invoke-virtual {p2}, LX/34d;->A03()LX/381;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v1, 0x0

    :goto_0
    if-eqz v2, :cond_15

    const-string/jumbo v0, "web"

    invoke-static {v2, v0}, LX/381;->A0X(LX/381;Ljava/lang/String;)Z

    move-result v0

    const/16 v11, 0x1f4

    const-string v7, "code"

    if-eqz v0, :cond_3

    if-nez v1, :cond_2

    if-eqz v4, :cond_1

    invoke-static {v2}, LX/381;->A0D(LX/381;)LX/381;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, v7, v11}, LX/381;->A0c(Ljava/lang/String;I)I

    move-result v0

    invoke-static {v0}, LX/2zO;->A00(I)V

    :cond_0
    invoke-virtual {p2}, LX/34d;->A03()LX/381;

    move-result-object v2

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    const-string/jumbo v0, "web node given during login without any web ref provided"

    invoke-static {v0}, LX/1yQ;->A01(Ljava/lang/String;)LX/1yQ;

    move-result-object v0

    throw v0

    :cond_2
    const-string/jumbo v0, "multiple web nodes encountered on login"

    invoke-static {v0}, LX/1yQ;->A01(Ljava/lang/String;)LX/1yQ;

    move-result-object v0

    throw v0

    :cond_3
    const-string/jumbo v0, "success"

    invoke-static {v2, v0}, LX/381;->A0X(LX/381;Ljava/lang/String;)Z

    move-result v0

    const-wide/16 v8, 0x3e8

    const-string/jumbo v10, "t"

    const/4 v3, 0x0

    const/4 v6, -0x1

    if-eqz v0, :cond_b

    if-eqz v4, :cond_4

    if-nez v1, :cond_4

    const-string/jumbo v0, "web was expected but not seen before success"

    invoke-static {v0}, LX/1yQ;->A01(Ljava/lang/String;)LX/1yQ;

    move-result-object v0

    throw v0

    :cond_4
    invoke-virtual {v2, v10}, LX/381;->A0q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-eqz v7, :cond_5

    :try_start_0
    invoke-static {v7}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    iput-wide v0, p3, LX/31G;->A02:J

    iget-object v4, p0, LX/10Z;->A0Q:LX/2sJ;

    invoke-virtual {v4}, LX/2sJ;->A0C()J

    move-result-wide v4

    div-long/2addr v4, v8

    iput-wide v4, p3, LX/31G;->A01:J

    invoke-virtual {p0, v0, v1}, LX/10Z;->A0r(J)V

    goto :goto_1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "invalid server time; timeString="

    invoke-static {v0, v7, v1}, LX/1yQ;->A02(Ljava/lang/String;Ljava/lang/String;Ljava/lang/StringBuilder;)LX/1yQ;

    move-result-object v0

    throw v0

    :cond_5
    :goto_1
    const-string/jumbo v0, "props"

    invoke-virtual {v2, v0, v6}, LX/381;->A0c(Ljava/lang/String;I)I

    move-result v0

    if-eq v0, v6, :cond_6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v1, p4

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    :cond_6
    const-string v0, "abprops"

    invoke-virtual {v2, v0, v6}, LX/381;->A0c(Ljava/lang/String;I)I

    move-result v0

    if-eq v0, v6, :cond_7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v1, p5

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    :cond_7
    const-class v1, Lcom/whatsapp/jid/Jid;

    const-string/jumbo v0, "lid"

    invoke-virtual {v2, v1, v0}, LX/381;->A0h(Ljava/lang/Class;Ljava/lang/String;)Lcom/whatsapp/jid/Jid;

    move-result-object v1

    if-eqz v1, :cond_8

    iget-object v0, p0, LX/10Z;->A0F:LX/2sr;

    invoke-virtual {v0, v1}, LX/2sr;->A0S(Lcom/whatsapp/jid/Jid;)V

    :cond_8
    const-string v0, "display_name"

    invoke-virtual {v2, v0, v3}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_9

    iget-object v0, p0, LX/10Z;->A0F:LX/2sr;

    invoke-virtual {v0, v1}, LX/2sr;->A0W(Ljava/lang/String;)V

    :cond_9
    iget-object v1, p0, LX/10Z;->A0Z:LX/3zQ;

    iget-object v0, p0, LX/10Z;->A0T:LX/354;

    invoke-static {v0, v1, v2}, LX/10Z;->A0M(LX/354;LX/3zQ;LX/381;)V

    iget-object v0, p0, LX/10Z;->A07:LX/31H;

    if-eqz v0, :cond_a

    invoke-virtual {v0}, LX/31H;->A02()V

    :cond_a
    return-void

    :cond_b
    const-string v0, "failure"

    invoke-static {v2, v0}, LX/381;->A0X(LX/381;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_14

    const-string/jumbo v0, "reason"

    invoke-virtual {v2, v0}, LX/381;->A0b(Ljava/lang/String;)I

    move-result v4

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "ConnectionThread/login/failure/reason="

    invoke-static {v0, v1, v4}, LX/0yK;->A0x(Ljava/lang/String;Ljava/lang/StringBuilder;I)V

    iget-object v0, p0, LX/10Z;->A0F:LX/2sr;

    invoke-virtual {v0}, LX/2sr;->A0X()Z

    move-result v0

    const/4 v9, 0x3

    if-eqz v0, :cond_c

    iget-object v0, p0, LX/10Z;->A0T:LX/354;

    invoke-virtual {v0}, LX/354;->A1Z()Z

    move-result v0

    if-eqz v0, :cond_c

    iget-object v8, p0, LX/10Z;->A0N:LX/2ar;

    int-to-long v0, v4

    invoke-virtual {v8, v9, v0, v1}, LX/2ar;->A00(IJ)V

    :cond_c
    iget-object v1, p0, LX/10Z;->A0Z:LX/3zQ;

    iget-object v0, p0, LX/10Z;->A0T:LX/354;

    invoke-static {v0, v1, v2}, LX/10Z;->A0M(LX/354;LX/3zQ;LX/381;)V

    if-lt v4, v11, :cond_d

    const/16 v0, 0x258

    if-ge v4, v0, :cond_e

    const/4 v0, 0x4

    new-instance v1, LX/1y0;

    invoke-direct {v1, v0, v4}, LX/1y0;-><init>(II)V

    throw v1

    :cond_d
    const/16 v0, 0x192

    if-ne v4, v0, :cond_e

    const/4 v0, 0x2

    new-instance v1, LX/1y0;

    invoke-direct {v1, v0, v4}, LX/1y0;-><init>(II)V

    const-string v0, "expire"

    invoke-virtual {v2, v0}, LX/381;->A0b(Ljava/lang/String;)I

    move-result v0

    iput v0, v1, LX/1y0;->expire_time_out:I

    invoke-virtual {v2, v7}, LX/381;->A0b(Ljava/lang/String;)I

    move-result v0

    iput v0, v1, LX/1y0;->code:I

    const-string/jumbo v0, "message"

    invoke-virtual {v2, v0, v3}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, LX/1y0;->banMessage:Ljava/lang/String;

    const-string/jumbo v0, "url"

    invoke-virtual {v2, v0, v3}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, LX/1y0;->faqUrl:Ljava/lang/String;

    throw v1

    :cond_e
    const/16 v0, 0x193

    const-string/jumbo v8, "vt"

    if-eq v4, v0, :cond_11

    const/16 v0, 0x195

    if-eq v4, v0, :cond_13

    const/16 v0, 0x196

    if-eq v4, v0, :cond_12

    const/16 v0, 0x1a0

    if-eq v4, v0, :cond_10

    const/16 v0, 0x191

    if-ne v4, v0, :cond_f

    iget-object v1, p0, LX/10Z;->A0Y:LX/1Pl;

    const/16 v0, 0xcd1

    invoke-virtual {v1, v0}, LX/2sp;->A0V(I)Z

    move-result v0

    if-eqz v0, :cond_f

    const/16 v0, 0x9

    new-instance v1, LX/1y0;

    invoke-direct {v1, v0, v4}, LX/1y0;-><init>(II)V

    :goto_2
    invoke-static {v1, v2}, LX/10Z;->A0a(LX/1y0;LX/381;)V

    throw v1

    :cond_f
    new-instance v1, LX/1y0;

    invoke-direct {v1, v5, v4}, LX/1y0;-><init>(II)V

    goto :goto_2

    :cond_10
    const/16 v0, 0xb

    new-instance v1, LX/1y0;

    invoke-direct {v1, v0, v4}, LX/1y0;-><init>(II)V

    invoke-virtual {v2, v8, v5}, LX/381;->A0c(Ljava/lang/String;I)I

    move-result v0

    iput v0, v1, LX/1y0;->violationType:I

    const-string/jumbo v0, "violation_reason"

    invoke-virtual {v2, v0, v3}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, LX/1y0;->violationReason:Ljava/lang/String;

    const-string/jumbo v0, "source_acct"

    invoke-virtual {v2, v0, v6}, LX/381;->A0c(Ljava/lang/String;I)I

    move-result v0

    iput v0, v1, LX/1y0;->violationSourceAcct:I

    goto :goto_2

    :cond_11
    const/4 v0, 0x7

    new-instance v1, LX/1y0;

    invoke-direct {v1, v0, v4}, LX/1y0;-><init>(II)V

    invoke-virtual {v2, v8, v5}, LX/381;->A0c(Ljava/lang/String;I)I

    move-result v0

    iput v0, v1, LX/1y0;->violationType:I

    const-string v0, "appeal_token"

    invoke-virtual {v2, v0, v3}, LX/381;->A0s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, LX/1y0;->banAppealToken:Ljava/lang/String;

    goto :goto_2

    :cond_12
    const/4 v0, 0x5

    new-instance v1, LX/1y0;

    invoke-direct {v1, v0, v4}, LX/1y0;-><init>(II)V

    invoke-virtual {v2, v7, v5}, LX/381;->A0c(Ljava/lang/String;I)I

    move-result v0

    iput v0, v1, LX/1y0;->code:I

    throw v1

    :cond_13
    new-instance v1, LX/1y0;

    invoke-direct {v1, v9, v4}, LX/1y0;-><init>(II)V

    invoke-static {v2, v10}, LX/381;->A04(LX/381;Ljava/lang/String;)J

    move-result-wide v4

    const-wide/16 v2, 0x3e8

    mul-long/2addr v4, v2

    iput-wide v4, v1, LX/1y0;->expiration_time:J

    throw v1

    :cond_14
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v0, "unexpected node received during login sequence; node="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, LX/381;->A0p()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LX/1yQ;->A01(Ljava/lang/String;)LX/1yQ;

    move-result-object v0

    throw v0

    :cond_15
    const-string/jumbo v0, "node stream ended unexpectedly"

    invoke-static {v0}, LX/1yQ;->A01(Ljava/lang/String;)LX/1yQ;

    move-result-object v0

    throw v0
.end method

.method public final A11(LX/30N;)V
    .locals 1

    iget-object v0, p0, LX/10Z;->A03:LX/10P;

    invoke-virtual {v0, p1}, LX/10P;->A08(LX/30N;)V

    return-void
.end method

.method public final A12(LX/31G;)V
    .locals 2

    iget-object v0, p0, LX/10Z;->A08:LX/31G;

    if-ne p1, v0, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-virtual {p0, v1, v0}, LX/10Z;->A16(ZI)V

    :cond_0
    return-void
.end method

.method public final A13(LX/2qt;IIIIJJ)V
    .locals 13

    const/4 v0, 0x6

    iget-object v1, p0, LX/10Z;->A0s:LX/7YY;

    int-to-long v9, v0

    move-object v2, p1

    move v3, p2

    move/from16 v4, p3

    move/from16 v5, p4

    move/from16 v6, p5

    move-wide/from16 v7, p6

    move-wide/from16 v11, p8

    invoke-virtual/range {v1 .. v12}, LX/7YY;->A00(LX/2qt;IIIIJJJ)LX/3eo;

    move-result-object v2

    const/4 v1, 0x1

    if-eqz v2, :cond_0

    if-eq p2, v1, :cond_1

    const/4 v0, 0x5

    if-eq p2, v0, :cond_1

    iget-object v0, p0, LX/10Z;->A0a:LX/44u;

    invoke-interface {v0, v2}, LX/44u;->Bfl(LX/3eo;)V

    :cond_0
    :goto_0
    iget-object v0, p0, LX/10Z;->A0n:LX/2lv;

    if-ne p2, v1, :cond_2

    invoke-virtual {v0}, LX/2lv;->A01()V

    return-void

    :cond_1
    iget-object v0, p0, LX/10Z;->A0a:LX/44u;

    invoke-interface {v0, v2}, LX/44u;->Bfn(LX/3eo;)V

    goto :goto_0

    :cond_2
    invoke-virtual {v0}, LX/2lv;->A00()V

    return-void
.end method

.method public final A14(Ljava/lang/String;)V
    .locals 3

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "ConnectionThread/quitIfNeeded should quit: "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LX/10Z;->A0l:LX/2eW;

    invoke-virtual {v1}, LX/2eW;->A01()Z

    move-result v0

    invoke-static {v2, v0}, LX/0yK;->A1U(Ljava/lang/StringBuilder;Z)V

    invoke-virtual {v1}, LX/2eW;->A01()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v0, p0, LX/10Z;->A06:LX/10Y;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quit()Z

    invoke-virtual {p0}, Landroid/os/HandlerThread;->quit()Z

    :cond_0
    return-void
.end method

.method public final A15(Z)V
    .locals 2

    if-eqz p1, :cond_0

    iget-object v0, p0, LX/10Z;->A0o:LX/2q0;

    invoke-virtual {v0}, LX/2q0;->A03()V

    iget-object v1, p0, LX/10Z;->A04:LX/2l8;

    if-eqz v1, :cond_0

    iget-object v0, p0, LX/10Z;->A0p:LX/3GD;

    invoke-virtual {v0, v1}, LX/3GD;->A07(LX/2l8;)V

    :cond_0
    return-void
.end method

.method public final A16(ZI)V
    .locals 6

    iget-object v0, p0, LX/10Z;->A03:LX/10P;

    invoke-virtual {v0}, LX/10P;->A09()Z

    move-result v5

    iget-object v0, p0, LX/10Z;->A03:LX/10P;

    invoke-static {v0}, LX/10P;->A00(LX/10P;)I

    move-result v2

    invoke-virtual {v0}, LX/10P;->A03()V

    iget-object v0, p0, LX/10Z;->A07:LX/31H;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, LX/31H;->A01()V

    :cond_0
    iget-object v1, p0, LX/10Z;->A0j:LX/2eW;

    invoke-virtual {v1}, LX/2eW;->A01()Z

    move-result v0

    const-string/jumbo v3, "quit during forced disconnect"

    if-eqz v0, :cond_3

    iget-object v4, p0, LX/10Z;->A0k:LX/2eW;

    invoke-virtual {v4}, LX/2eW;->A01()Z

    move-result v0

    if-nez v0, :cond_3

    const/4 v2, 0x1

    if-eqz p1, :cond_6

    const-string v0, "ConnectionThread/disconnect/reader_thread/mark_finished"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v0, p0, LX/10Z;->A02:LX/10S;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, LX/10S;->A00()V

    :cond_1
    invoke-static {p0}, LX/10Z;->A0H(LX/10Z;)LX/306;

    move-result-object v0

    invoke-virtual {v0, p2}, LX/306;->A02(I)V

    invoke-virtual {p0}, LX/10Z;->A0i()V

    iget-object v0, p0, LX/10Z;->A05:LX/43o;

    invoke-interface {v0}, LX/43o;->Bjq()V

    iget-object v0, p0, LX/10Z;->A0g:LX/452;

    invoke-interface {v0, v2}, LX/452;->BQ6(Z)V

    const/4 v0, 0x0

    invoke-virtual {v1, v0}, LX/2eW;->A00(Z)V

    :goto_0
    invoke-virtual {p0, v3}, LX/10Z;->A14(Ljava/lang/String;)V

    :cond_2
    return-void

    :cond_3
    if-eqz v5, :cond_4

    if-eqz p1, :cond_5

    iget-object v1, p0, LX/10Z;->A03:LX/10P;

    invoke-static {p2, v2}, LX/10Z;->A00(II)I

    move-result v0

    invoke-virtual {v1, v0}, LX/10P;->A06(I)V

    :goto_1
    iget-object v0, p0, LX/10Z;->A0k:LX/2eW;

    invoke-virtual {v0}, LX/2eW;->A01()Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_0

    :cond_4
    if-eqz p1, :cond_5

    invoke-static {p0}, LX/10Z;->A0H(LX/10Z;)LX/306;

    move-result-object v0

    invoke-virtual {v0, p2}, LX/306;->A02(I)V

    goto :goto_1

    :cond_5
    iget-object v0, p0, LX/10Z;->A0k:LX/2eW;

    invoke-virtual {v0}, LX/2eW;->A01()Z

    move-result v0

    if-nez v0, :cond_2

    const-string/jumbo v0, "quit even if not connected"

    invoke-virtual {p0, v0}, LX/10Z;->A14(Ljava/lang/String;)V

    return-void

    :cond_6
    iget-object v0, p0, LX/10Z;->A03:LX/10P;

    invoke-virtual {v0, p2}, LX/10P;->A07(I)V

    iget-object v1, p0, LX/10Z;->A05:LX/43o;

    invoke-static {}, LX/385;->A01()Landroid/os/Message;

    move-result-object v0

    invoke-interface {v1, v0}, LX/43o;->Bk3(Landroid/os/Message;)V

    invoke-virtual {v4, v2}, LX/2eW;->A00(Z)V

    return-void
.end method

.method public final A17(ZI)V
    .locals 4

    iget-object v0, p0, LX/10Z;->A07:LX/31H;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, LX/31H;->A01()V

    :cond_0
    iget-object v0, p0, LX/10Z;->A0j:LX/2eW;

    const/4 v3, 0x0

    invoke-virtual {v0, v3}, LX/2eW;->A00(Z)V

    iget-object v0, p0, LX/10Z;->A0k:LX/2eW;

    invoke-virtual {v0, v3}, LX/2eW;->A00(Z)V

    iget-object v0, p0, LX/10Z;->A0l:LX/2eW;

    invoke-virtual {v0}, LX/2eW;->A01()Z

    move-result v0

    if-nez v0, :cond_6

    iget-object v0, p0, LX/10Z;->A03:LX/10P;

    invoke-virtual {v0}, LX/10P;->A01()I

    move-result v2

    invoke-virtual {v0}, LX/10P;->A05()V

    iget-object v0, p0, LX/10Z;->A05:LX/43o;

    invoke-interface {v0}, LX/43o;->Bjq()V

    iget-object v0, p0, LX/10Z;->A0g:LX/452;

    invoke-interface {v0, p1}, LX/452;->BQ6(Z)V

    const/4 v1, -0x1

    if-eqz p1, :cond_5

    if-eqz p2, :cond_4

    const/4 v0, 0x1

    if-eq p2, v0, :cond_3

    const/4 v0, 0x2

    if-ne p2, v0, :cond_2

    invoke-static {p0}, LX/10Z;->A0H(LX/10Z;)LX/306;

    move-result-object v0

    if-ne v2, v1, :cond_1

    const/4 v2, 0x5

    :cond_1
    :goto_0
    invoke-virtual {v0, v2}, LX/306;->A02(I)V

    :cond_2
    :goto_1
    iget-object v0, p0, LX/10Z;->A03:LX/10P;

    invoke-virtual {v0}, LX/10P;->A03()V

    return-void

    :cond_3
    invoke-static {p0}, LX/10Z;->A0H(LX/10Z;)LX/306;

    move-result-object v0

    if-ne v2, v1, :cond_1

    const/4 v2, 0x3

    goto :goto_0

    :cond_4
    iget-object v2, p0, LX/10Z;->A0D:LX/2qa;

    const-string/jumbo v1, "logout-report-new-exception"

    const-string/jumbo v0, "please include correct error type"

    invoke-virtual {v2, v1, v3, v0}, LX/2qa;->A0C(Ljava/lang/String;ZLjava/lang/String;)V

    goto :goto_1

    :cond_5
    invoke-static {p0}, LX/10Z;->A0H(LX/10Z;)LX/306;

    move-result-object v0

    if-ne v2, v1, :cond_1

    const/4 v2, 0x4

    goto :goto_0

    :cond_6
    const-string v0, "ConnectionThread/quit after disconnected"

    invoke-virtual {p0, v0}, LX/10Z;->A14(Ljava/lang/String;)V

    goto :goto_1
.end method

.method public final A18()Z
    .locals 1

    iget-object v0, p0, LX/10Z;->A03:LX/10P;

    invoke-virtual {v0}, LX/10P;->A09()Z

    move-result v0

    return v0
.end method

.method public onLooperPrepared()V
    .locals 7

    new-instance v0, LX/10P;

    invoke-direct {v0, p0}, LX/10P;-><init>(LX/10Z;)V

    iput-object v0, p0, LX/10Z;->A03:LX/10P;

    iget-object v1, p0, LX/10Z;->A0Y:LX/1Pl;

    iget-object v4, p0, LX/10Z;->A0p:LX/3GD;

    iget-object v6, p0, LX/10Z;->A0u:LX/2qy;

    new-instance v5, LX/10V;

    invoke-direct {v5, p0}, LX/10V;-><init>(LX/10Z;)V

    iget-object v0, p0, LX/10Z;->A0q:LX/2qw;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, LX/2Bk;

    invoke-direct {v2, v0}, LX/2Bk;-><init>(LX/2qw;)V

    iget-object v0, p0, LX/10Z;->A12:LX/37f;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, LX/2Bl;

    invoke-direct {v3, v0}, LX/2Bl;-><init>(LX/37f;)V

    new-instance v0, LX/10Y;

    invoke-direct/range {v0 .. v6}, LX/10Y;-><init>(LX/1Pl;LX/2Bk;LX/2Bl;LX/3GD;LX/3xj;LX/2qy;)V

    iput-object v0, p0, LX/10Z;->A06:LX/10Y;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    iget-object v0, p0, LX/10Z;->A0t:LX/2YZ;

    invoke-virtual {v0}, LX/2YZ;->A00()V

    iget-object v1, p0, LX/10Z;->A0r:LX/31V;

    iget-object v0, p0, LX/10Z;->A0m:LX/34u;

    invoke-virtual {v1, v0}, LX/31V;->A02(LX/34u;)V

    return-void
.end method

.method public quit()Z
    .locals 2

    invoke-super {p0}, Landroid/os/HandlerThread;->quit()Z

    move-result v1

    iget-object v0, p0, LX/10Z;->A0g:LX/452;

    invoke-interface {v0}, LX/452;->BXx()V

    return v1
.end method
