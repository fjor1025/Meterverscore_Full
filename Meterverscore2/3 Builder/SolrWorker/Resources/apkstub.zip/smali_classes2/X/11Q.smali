.class public abstract LX/11Q;
.super LX/03u;
.source ""

# interfaces
.implements LX/468;


# instance fields
.field public final A00:Ljava/lang/Object;

.field public volatile A01:LX/5p8;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, LX/03u;-><init>()V

    invoke-static {}, LX/001;->A0k()Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, LX/11Q;->A00:Ljava/lang/Object;

    const/16 v0, 0x2d

    invoke-static {p0, v0}, LX/46t;->A00(LX/05i;I)V

    return-void
.end method


# virtual methods
.method public B5a()LX/0vx;
    .locals 1

    invoke-super {p0}, LX/05i;->B5a()LX/0vx;

    move-result-object v0

    invoke-static {p0, v0}, LX/2u5;->A00(LX/05i;LX/0vx;)LX/0vx;

    move-result-object v0

    return-object v0
.end method

.method public final generatedComponent()Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, LX/11Q;->A01:LX/5p8;

    if-nez v0, :cond_1

    iget-object v1, p0, LX/11Q;->A00:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    iget-object v0, p0, LX/11Q;->A01:LX/5p8;

    if-nez v0, :cond_0

    new-instance v0, LX/5p8;

    invoke-direct {v0, p0}, LX/5p8;-><init>(Landroid/app/Activity;)V

    iput-object v0, p0, LX/11Q;->A01:LX/5p8;

    :cond_0
    monitor-exit v1

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    :cond_1
    :goto_0
    iget-object v0, p0, LX/11Q;->A01:LX/5p8;

    invoke-virtual {v0}, LX/5p8;->generatedComponent()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method
