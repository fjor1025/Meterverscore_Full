.class public final LX/11j;
.super LX/0V7;
.source ""


# instance fields
.field public final A00:LX/2sm;

.field public final A01:LX/2gp;

.field public final A02:LX/8Nl;


# direct methods
.method public constructor <init>(LX/2sm;LX/2gp;LX/8Nl;)V
    .locals 0

    invoke-static {p1, p2}, LX/0yK;->A0U(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-direct {p0}, LX/0V7;-><init>()V

    iput-object p1, p0, LX/11j;->A00:LX/2sm;

    iput-object p2, p0, LX/11j;->A01:LX/2gp;

    iput-object p3, p0, LX/11j;->A02:LX/8Nl;

    return-void
.end method
