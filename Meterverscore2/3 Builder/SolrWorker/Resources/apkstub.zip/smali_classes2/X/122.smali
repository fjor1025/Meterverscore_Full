.class public LX/122;
.super LX/0V7;
.source ""


# instance fields
.field public A00:Z

.field public final A01:LX/08S;

.field public final A02:LX/08S;

.field public final A03:LX/3by;

.field public final A04:LX/2Y4;

.field public final A05:LX/1cz;

.field public final A06:LX/4LC;

.field public final A07:LX/4LC;

.field public final A08:LX/454;


# direct methods
.method public constructor <init>(LX/3by;LX/2Y4;LX/1cz;LX/354;LX/454;)V
    .locals 3

    const/4 v2, 0x1

    invoke-direct {p0}, LX/0V7;-><init>()V

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v1

    iput-object v1, p0, LX/122;->A02:LX/08S;

    invoke-static {}, LX/0yU;->A0H()LX/4LC;

    move-result-object v0

    iput-object v0, p0, LX/122;->A06:LX/4LC;

    invoke-static {}, LX/0yU;->A0H()LX/4LC;

    move-result-object v0

    iput-object v0, p0, LX/122;->A07:LX/4LC;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/122;->A01:LX/08S;

    iput-object p1, p0, LX/122;->A03:LX/3by;

    iput-object p5, p0, LX/122;->A08:LX/454;

    iput-boolean v2, p0, LX/122;->A00:Z

    iput-object p2, p0, LX/122;->A04:LX/2Y4;

    iput-object p3, p0, LX/122;->A05:LX/1cz;

    invoke-virtual {p4}, LX/354;->A1S()Z

    move-result v0

    invoke-static {v1, v0}, LX/0yP;->A12(LX/0Y8;Z)V

    return-void
.end method


# virtual methods
.method public final A0G()V
    .locals 4

    iget-object v0, p0, LX/122;->A05:LX/1cz;

    invoke-virtual {v0}, LX/1cz;->A0D()Z

    move-result v0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    iget-object v1, p0, LX/122;->A07:LX/4LC;

    new-instance v0, LX/76U;

    invoke-direct {v0}, LX/76U;-><init>()V

    invoke-virtual {v1, v0}, LX/0Y8;->A0G(Ljava/lang/Object;)V

    return-void

    :cond_0
    iget-object v1, p0, LX/122;->A01:LX/08S;

    const v0, 0x7f1211ad

    invoke-static {v1, v0}, LX/0Y8;->A03(LX/0Y8;I)V

    iget-object v1, p0, LX/122;->A08:LX/454;

    const/16 v0, 0x23

    invoke-static {v1, p0, v0}, LX/3hJ;->A00(LX/454;Ljava/lang/Object;I)V

    iput-boolean v2, p0, LX/122;->A00:Z

    iget-object v3, p0, LX/122;->A03:LX/3by;

    const/16 v0, 0x24

    new-instance v2, LX/3hJ;

    invoke-direct {v2, p0, v0}, LX/3hJ;-><init>(Ljava/lang/Object;I)V

    const-wide/16 v0, 0x3e8

    invoke-virtual {v3, v2, v0, v1}, LX/3by;->A0Y(Ljava/lang/Runnable;J)V

    return-void
.end method
