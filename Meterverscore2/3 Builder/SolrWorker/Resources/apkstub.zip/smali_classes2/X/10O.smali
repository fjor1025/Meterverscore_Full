.class public LX/10O;
.super Landroid/os/Handler;
.source ""


# instance fields
.field public A00:LX/382;

.field public A01:Z

.field public A02:Z

.field public final A03:Ljava/util/HashSet;

.field public final synthetic A04:LX/3IT;


# direct methods
.method public constructor <init>(Landroid/os/Looper;LX/3IT;)V
    .locals 1

    iput-object p2, p0, LX/10O;->A04:LX/3IT;

    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-static {}, LX/001;->A0z()Ljava/util/HashSet;

    move-result-object v0

    iput-object v0, p0, LX/10O;->A03:Ljava/util/HashSet;

    return-void
.end method


# virtual methods
.method public final A00()V
    .locals 219

    move-object/from16 v218, p0

    move-object/from16 v0, v218

    iget-object v0, v0, LX/10O;->A04:LX/3IT;

    iget-object v0, v0, LX/3IT;->A01:LX/2iX;

    iget-object v0, v0, LX/2iX;->A00:Landroid/content/Context;

    invoke-static {v0}, LX/244;->A00(Ljava/lang/Object;)LX/38w;

    move-result-object v2

    iget-object v1, v2, LX/38w;->ACR:LX/3GZ;

    invoke-static {v1}, LX/3GZ;->A2k(LX/3GZ;)LX/2sJ;

    move-result-object v151

    invoke-static {v1}, LX/3GZ;->A45(LX/3GZ;)LX/1Pl;

    move-result-object v174

    iget-object v0, v1, LX/3GZ;->AFv:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v61

    move-object/from16 v0, v61

    check-cast v0, LX/3by;

    move-object/from16 v61, v0

    iget-object v0, v1, LX/3GZ;->A07:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v19

    move-object/from16 v0, v19

    check-cast v0, LX/1Pl;

    move-object/from16 v19, v0

    iget-object v0, v1, LX/3GZ;->AJG:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v18

    move-object/from16 v0, v18

    check-cast v0, LX/2sr;

    move-object/from16 v18, v0

    iget-object v0, v1, LX/3GZ;->AZu:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v0, v17

    check-cast v0, LX/2iX;

    move-object/from16 v17, v0

    iget-object v0, v1, LX/3GZ;->AbH:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v0, v16

    check-cast v0, LX/454;

    move-object/from16 v16, v0

    iget-object v0, v1, LX/3GZ;->ARi:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, LX/3HW;

    invoke-virtual {v1}, LX/3GZ;->AhJ()LX/8nU;

    move-result-object v202

    iget-object v0, v1, LX/3GZ;->AUO:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, LX/3RL;

    invoke-virtual {v1}, LX/3GZ;->AjU()LX/2fD;

    move-result-object v204

    iget-object v0, v1, LX/3GZ;->AXz:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, LX/34w;

    iget-object v0, v1, LX/3GZ;->AS6:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, LX/6E2;

    iget-object v0, v2, LX/38w;->A20:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, LX/3Kb;

    iget-object v0, v1, LX/3GZ;->AMp:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LX/3RK;

    iget-object v0, v1, LX/3GZ;->AZj:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/whatsapp/voipcalling/camera/VoipCameraManager;

    iget-object v0, v2, LX/38w;->AC1:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/whatsapp/calling/audio/VoipSystemAudioManager;

    iget-object v0, v1, LX/3GZ;->AaO:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LX/34r;

    iget-object v0, v1, LX/3GZ;->AaR:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LX/354;

    iget-object v0, v1, LX/3GZ;->AZo:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LX/312;

    iget-object v0, v1, LX/3GZ;->AVV:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LX/2yj;

    iget-object v0, v1, LX/3GZ;->AaD:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2tD;

    iget-object v11, v2, LX/38w;->A9i:LX/41P;

    move-object/from16 v20, v11

    iget-object v11, v2, LX/38w;->A9j:LX/41P;

    new-instance v196, Lcom/whatsapp/voipcalling/JNIUtils;

    move-object/from16 v197, v19

    move-object/from16 v198, v18

    move-object/from16 v199, v17

    move-object/from16 v200, v16

    move-object/from16 v201, v15

    move-object/from16 v203, v14

    move-object/from16 v205, v13

    move-object/from16 v206, v12

    move-object/from16 v207, v10

    move-object/from16 v208, v9

    move-object/from16 v209, v8

    move-object/from16 v210, v7

    move-object/from16 v211, v6

    move-object/from16 v212, v5

    move-object/from16 v213, v4

    move-object/from16 v214, v3

    move-object/from16 v215, v0

    move-object/from16 v216, v20

    move-object/from16 v217, v11

    invoke-direct/range {v196 .. v217}, Lcom/whatsapp/voipcalling/JNIUtils;-><init>(LX/1Pl;LX/2sr;LX/2iX;LX/454;LX/3HW;LX/8nU;LX/3RL;LX/2fD;LX/34w;LX/6E2;LX/3Kb;LX/3RK;Lcom/whatsapp/voipcalling/camera/VoipCameraManager;Lcom/whatsapp/calling/audio/VoipSystemAudioManager;LX/34r;LX/354;LX/312;LX/2yj;LX/2tD;LX/41P;LX/41P;)V

    iget-object v0, v1, LX/3GZ;->A0k:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v64

    move-object/from16 v0, v64

    check-cast v0, LX/2iW;

    move-object/from16 v64, v0

    iget-object v0, v1, LX/3GZ;->A72:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v65

    move-object/from16 v0, v65

    check-cast v0, LX/2qa;

    move-object/from16 v65, v0

    iget-object v0, v1, LX/3GZ;->AJG:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v66

    move-object/from16 v0, v66

    check-cast v0, LX/2sr;

    move-object/from16 v66, v0

    iget-object v0, v1, LX/3GZ;->AZu:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v67

    move-object/from16 v0, v67

    check-cast v0, LX/2iX;

    move-object/from16 v67, v0

    invoke-static {v1}, LX/3GZ;->A8h(LX/3GZ;)LX/454;

    move-result-object v194

    iget-object v0, v1, LX/3GZ;->ARi:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v68

    move-object/from16 v0, v68

    check-cast v0, LX/3HW;

    move-object/from16 v68, v0

    iget-object v0, v1, LX/3GZ;->AWF:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v69

    move-object/from16 v0, v69

    check-cast v0, LX/2s4;

    move-object/from16 v69, v0

    invoke-virtual {v1}, LX/3GZ;->AhJ()LX/8nU;

    move-result-object v107

    iget-object v0, v1, LX/3GZ;->ASI:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v70

    move-object/from16 v0, v70

    check-cast v0, LX/44u;

    move-object/from16 v70, v0

    invoke-virtual {v1}, LX/3GZ;->AjU()LX/2fD;

    move-result-object v173

    iget-object v0, v1, LX/3GZ;->AUJ:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v72

    move-object/from16 v0, v72

    check-cast v0, LX/34b;

    move-object/from16 v72, v0

    iget-object v0, v1, LX/3GZ;->AVq:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v74

    move-object/from16 v0, v74

    check-cast v0, LX/31i;

    move-object/from16 v74, v0

    iget-object v0, v1, LX/3GZ;->AVy:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v76

    move-object/from16 v0, v76

    check-cast v0, LX/2sF;

    move-object/from16 v76, v0

    iget-object v0, v1, LX/3GZ;->AZ4:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v78

    move-object/from16 v0, v78

    check-cast v0, LX/350;

    move-object/from16 v78, v0

    iget-object v0, v1, LX/3GZ;->A4P:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v80

    move-object/from16 v0, v80

    check-cast v0, LX/6Dk;

    move-object/from16 v80, v0

    sget-object v91, LX/4U6;->A00:LX/4U6;

    iget-object v0, v1, LX/3GZ;->AJ2:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v82

    move-object/from16 v0, v82

    check-cast v0, LX/1bw;

    move-object/from16 v82, v0

    iget-object v0, v1, LX/3GZ;->A48:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v84

    move-object/from16 v0, v84

    check-cast v0, LX/2kd;

    move-object/from16 v84, v0

    iget-object v0, v2, LX/38w;->A2D:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v86

    move-object/from16 v0, v86

    check-cast v0, LX/1cX;

    move-object/from16 v86, v0

    iget-object v0, v1, LX/3GZ;->A7t:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v88

    move-object/from16 v0, v88

    check-cast v0, LX/1c0;

    move-object/from16 v88, v0

    iget-object v0, v1, LX/3GZ;->ASA:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v90

    move-object/from16 v0, v90

    check-cast v0, LX/2iC;

    move-object/from16 v90, v0

    iget-object v0, v1, LX/3GZ;->AZn:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v89

    move-object/from16 v0, v89

    check-cast v0, LX/2pn;

    move-object/from16 v89, v0

    iget-object v0, v1, LX/3GZ;->A23:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v87

    move-object/from16 v0, v87

    check-cast v0, LX/2cZ;

    move-object/from16 v87, v0

    iget-object v0, v2, LX/38w;->A26:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v85

    move-object/from16 v0, v85

    check-cast v0, LX/1d0;

    move-object/from16 v85, v0

    iget-object v0, v1, LX/3GZ;->A6L:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v83

    move-object/from16 v0, v83

    check-cast v0, LX/3J5;

    move-object/from16 v83, v0

    iget-object v0, v1, LX/3GZ;->AVo:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v81

    move-object/from16 v0, v81

    check-cast v0, LX/2f6;

    move-object/from16 v81, v0

    iget-object v0, v1, LX/3GZ;->AS6:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v79

    move-object/from16 v0, v79

    check-cast v0, LX/6E2;

    move-object/from16 v79, v0

    invoke-static {v1}, LX/3GZ;->A2j(LX/3GZ;)LX/34w;

    move-result-object v150

    iget-object v0, v1, LX/3GZ;->AZt:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v77

    move-object/from16 v0, v77

    check-cast v0, LX/352;

    move-object/from16 v77, v0

    invoke-static {v1}, LX/3GZ;->A2t(LX/3GZ;)LX/34x;

    move-result-object v157

    iget-object v0, v1, LX/3GZ;->A4H:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v75

    move-object/from16 v0, v75

    check-cast v0, LX/2fv;

    move-object/from16 v75, v0

    iget-object v0, v1, LX/3GZ;->AFp:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v73

    move-object/from16 v0, v73

    check-cast v0, LX/2LX;

    move-object/from16 v73, v0

    iget-object v0, v1, LX/3GZ;->AQs:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v71

    move-object/from16 v0, v71

    check-cast v0, LX/3Wk;

    move-object/from16 v71, v0

    iget-object v0, v2, LX/38w;->A25:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v63

    move-object/from16 v0, v63

    check-cast v0, LX/5Z9;

    move-object/from16 v63, v0

    iget-object v0, v1, LX/3GZ;->AG8:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v62

    move-object/from16 v0, v62

    check-cast v0, LX/3QV;

    move-object/from16 v62, v0

    iget-object v0, v1, LX/3GZ;->AaF:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v60

    move-object/from16 v0, v60

    check-cast v0, LX/2sO;

    move-object/from16 v60, v0

    iget-object v0, v1, LX/3GZ;->AMt:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v59

    move-object/from16 v0, v59

    check-cast v0, LX/1cE;

    move-object/from16 v59, v0

    iget-object v0, v1, LX/3GZ;->Ac1:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v58

    move-object/from16 v0, v58

    check-cast v0, LX/1cv;

    move-object/from16 v58, v0

    iget-object v0, v2, LX/38w;->A20:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v57

    move-object/from16 v0, v57

    check-cast v0, LX/3Kb;

    move-object/from16 v57, v0

    iget-object v0, v2, LX/38w;->A2A:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v56

    move-object/from16 v0, v56

    check-cast v0, LX/1cI;

    move-object/from16 v56, v0

    iget-object v0, v1, LX/3GZ;->A4Q:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v55

    move-object/from16 v0, v55

    check-cast v0, LX/2sa;

    move-object/from16 v55, v0

    iget-object v0, v1, LX/3GZ;->A4G:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v54

    move-object/from16 v0, v54

    check-cast v0, LX/2aM;

    move-object/from16 v54, v0

    iget-object v0, v1, LX/3GZ;->A4t:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v53

    move-object/from16 v0, v53

    check-cast v0, LX/89j;

    move-object/from16 v53, v0

    iget-object v0, v1, LX/3GZ;->A53:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v52

    move-object/from16 v0, v52

    check-cast v0, LX/1Mu;

    move-object/from16 v52, v0

    iget-object v0, v1, LX/3GZ;->A8A:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v51

    move-object/from16 v0, v51

    check-cast v0, LX/3GC;

    move-object/from16 v51, v0

    iget-object v0, v2, LX/38w;->A56:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v50

    move-object/from16 v0, v50

    check-cast v0, LX/2fw;

    move-object/from16 v50, v0

    iget-object v0, v1, LX/3GZ;->AH6:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v49

    move-object/from16 v0, v49

    check-cast v0, LX/1bt;

    move-object/from16 v49, v0

    iget-object v0, v1, LX/3GZ;->AOG:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v48

    move-object/from16 v0, v48

    check-cast v0, LX/3Qb;

    move-object/from16 v48, v0

    iget-object v0, v1, LX/3GZ;->AVn:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v47

    move-object/from16 v0, v47

    check-cast v0, LX/351;

    move-object/from16 v47, v0

    iget-object v0, v2, LX/38w;->AB2:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v46

    move-object/from16 v0, v46

    check-cast v0, LX/1m0;

    move-object/from16 v46, v0

    iget-object v0, v1, LX/3GZ;->AZ9:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v45

    move-object/from16 v0, v45

    check-cast v0, LX/31v;

    move-object/from16 v45, v0

    iget-object v0, v1, LX/3GZ;->AZj:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v44

    move-object/from16 v0, v44

    check-cast v0, Lcom/whatsapp/voipcalling/camera/VoipCameraManager;

    move-object/from16 v44, v0

    iget-object v0, v1, LX/3GZ;->AbH:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LX/454;

    iget-object v0, v1, LX/3GZ;->AJG:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LX/2sr;

    iget-object v0, v2, LX/38w;->ABb:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LX/3JX;

    iget-object v0, v2, LX/38w;->A6p:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LX/2Y2;

    new-instance v43, LX/2ZT;

    move-object/from16 v0, v43

    invoke-direct {v0, v5, v3, v4, v6}, LX/2ZT;-><init>(LX/2sr;LX/2Y2;LX/3JX;LX/454;)V

    iget-object v0, v2, LX/38w;->A6K:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v42

    move-object/from16 v0, v42

    check-cast v0, LX/5No;

    move-object/from16 v42, v0

    iget-object v0, v2, LX/38w;->A3I:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v41

    move-object/from16 v0, v41

    check-cast v0, LX/3cV;

    move-object/from16 v41, v0

    iget-object v0, v2, LX/38w;->A6u:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v40

    move-object/from16 v0, v40

    check-cast v0, LX/7Mz;

    move-object/from16 v40, v0

    iget-object v0, v1, LX/3GZ;->AIz:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v39

    move-object/from16 v0, v39

    check-cast v0, LX/2qy;

    move-object/from16 v39, v0

    iget-object v0, v1, LX/3GZ;->ARC:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v38

    move-object/from16 v0, v38

    check-cast v0, LX/2sM;

    move-object/from16 v38, v0

    iget-object v0, v1, LX/3GZ;->AU1:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v37

    move-object/from16 v0, v37

    check-cast v0, LX/2q7;

    move-object/from16 v37, v0

    invoke-virtual {v1}, LX/3GZ;->AhM()LX/3IT;

    move-result-object v125

    iget-object v0, v1, LX/3GZ;->AaO:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v36

    move-object/from16 v0, v36

    check-cast v0, LX/34r;

    move-object/from16 v36, v0

    invoke-static {v1}, LX/3GZ;->A2r(LX/3GZ;)LX/354;

    move-result-object v156

    iget-object v0, v1, LX/3GZ;->A24:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v35

    move-object/from16 v0, v35

    check-cast v0, LX/1ct;

    move-object/from16 v35, v0

    invoke-virtual {v2}, LX/38w;->AIQ()LX/5O6;

    move-result-object v109

    iget-object v0, v1, LX/3GZ;->A81:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v34

    move-object/from16 v0, v34

    check-cast v0, LX/34l;

    move-object/from16 v34, v0

    iget-object v0, v2, LX/38w;->A3t:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v33

    move-object/from16 v0, v33

    check-cast v0, LX/2Y1;

    move-object/from16 v33, v0

    iget-object v0, v1, LX/3GZ;->AIE:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v32

    move-object/from16 v0, v32

    check-cast v0, LX/2rl;

    move-object/from16 v32, v0

    iget-object v0, v1, LX/3GZ;->AOK:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v31

    move-object/from16 v0, v31

    check-cast v0, LX/2SV;

    move-object/from16 v31, v0

    iget-object v0, v2, LX/38w;->AC2:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v30

    move-object/from16 v0, v30

    check-cast v0, LX/37g;

    move-object/from16 v30, v0

    invoke-virtual {v2}, LX/38w;->AIb()LX/33c;

    move-result-object v128

    invoke-virtual {v1}, LX/3GZ;->Amj()LX/2bV;

    move-result-object v178

    iget-object v0, v1, LX/3GZ;->ATy:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v29

    move-object/from16 v0, v29

    check-cast v0, LX/1ch;

    move-object/from16 v29, v0

    iget-object v0, v1, LX/3GZ;->AZo:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v28

    move-object/from16 v0, v28

    check-cast v0, LX/312;

    move-object/from16 v28, v0

    invoke-static {v1}, LX/3GZ;->A2o(LX/3GZ;)LX/34c;

    move-result-object v154

    iget-object v0, v2, LX/38w;->A2E:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v27

    move-object/from16 v0, v27

    check-cast v0, LX/2AS;

    move-object/from16 v27, v0

    iget-object v0, v2, LX/38w;->A17:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v26

    move-object/from16 v0, v26

    check-cast v0, LX/0zY;

    move-object/from16 v26, v0

    iget-object v0, v2, LX/38w;->A2B:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v25

    move-object/from16 v0, v25

    check-cast v0, LX/2rz;

    move-object/from16 v25, v0

    iget-object v0, v1, LX/3GZ;->A6y:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v24

    move-object/from16 v0, v24

    check-cast v0, LX/3Qa;

    move-object/from16 v24, v0

    iget-object v0, v1, LX/3GZ;->AON:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v23

    move-object/from16 v0, v23

    check-cast v0, LX/2d5;

    move-object/from16 v23, v0

    iget-object v0, v1, LX/3GZ;->ARE:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v22

    move-object/from16 v0, v22

    check-cast v0, LX/2ot;

    move-object/from16 v22, v0

    iget-object v0, v1, LX/3GZ;->AU5:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v21

    move-object/from16 v0, v21

    check-cast v0, LX/1cl;

    move-object/from16 v21, v0

    iget-object v0, v1, LX/3GZ;->A1j:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v20

    move-object/from16 v0, v20

    check-cast v0, LX/1cc;

    move-object/from16 v20, v0

    invoke-virtual {v1}, LX/3GZ;->AhN()LX/2ZV;

    move-result-object v136

    iget-object v0, v1, LX/3GZ;->ATw:LX/41P;

    invoke-static {v0}, LX/3jM;->A00(LX/41P;)LX/8oO;

    move-result-object v198

    iget-object v0, v2, LX/38w;->AAM:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v19

    move-object/from16 v0, v19

    check-cast v0, LX/2nw;

    move-object/from16 v19, v0

    iget-object v0, v2, LX/38w;->AAN:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v18

    move-object/from16 v0, v18

    check-cast v0, Lcom/whatsapp/calling/screenshare/ScreenShareResourceManager;

    move-object/from16 v18, v0

    iget-object v0, v2, LX/38w;->ABo:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v0, v17

    check-cast v0, LX/2ao;

    move-object/from16 v17, v0

    iget-object v0, v1, LX/3GZ;->A0r:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v0, v16

    check-cast v0, LX/1cV;

    move-object/from16 v16, v0

    iget-object v0, v1, LX/3GZ;->A65:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, LX/1cz;

    iget-object v0, v1, LX/3GZ;->AZ6:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, LX/1bn;

    iget-object v0, v1, LX/3GZ;->A5l:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, LX/2aN;

    iget-object v0, v2, LX/38w;->A2F:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, LX/1zd;

    iget-object v0, v1, LX/3GZ;->AHl:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, LX/5pD;->A02(Ljava/lang/Object;)LX/5pD;

    move-result-object v92

    iget-object v0, v1, LX/3GZ;->A7V:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, LX/1Mk;

    iget-object v0, v1, LX/3GZ;->A7W:LX/41P;

    invoke-static {v0}, LX/3jM;->A00(LX/41P;)LX/8oO;

    move-result-object v199

    iget-object v0, v1, LX/3GZ;->A7y:LX/41P;

    invoke-static {v0}, LX/3jM;->A00(LX/41P;)LX/8oO;

    move-result-object v200

    iget-object v0, v2, LX/38w;->A6p:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, LX/2Y2;

    iget-object v0, v2, LX/38w;->A8b:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LX/5qv;

    iget-object v0, v1, LX/3GZ;->AUA:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, LX/3H3;

    iget-object v0, v2, LX/38w;->ABg:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LX/2hY;

    iget-object v0, v1, LX/3GZ;->AaD:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LX/2tD;

    iget-object v0, v1, LX/3GZ;->A5n:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LX/2pp;

    iget-object v0, v1, LX/3GZ;->A6r:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LX/2U8;

    iget-object v0, v1, LX/3GZ;->AFL:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LX/3Iz;

    iget-object v0, v1, LX/3GZ;->AOt:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LX/34v;

    iget-object v0, v1, LX/3GZ;->A4M:LX/41P;

    invoke-static {v0}, LX/3jM;->A00(LX/41P;)LX/8oO;

    move-result-object v201

    iget-object v0, v1, LX/3GZ;->AZe:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2ap;

    new-instance v1, LX/382;

    move-object/from16 v99, v59

    move-object/from16 v100, v69

    move-object/from16 v101, v78

    move-object/from16 v102, v58

    move-object/from16 v103, v88

    move-object/from16 v104, v46

    move-object/from16 v105, v87

    move-object/from16 v106, v35

    move-object/from16 v108, v28

    move-object/from16 v110, v63

    move-object/from16 v111, v85

    move-object/from16 v112, v84

    move-object/from16 v113, v56

    move-object/from16 v114, v80

    move-object/from16 v115, v12

    move-object/from16 v116, v33

    move-object/from16 v117, v54

    move-object/from16 v118, v40

    move-object/from16 v119, v25

    move-object/from16 v120, v89

    move-object/from16 v121, v19

    move-object/from16 v122, v18

    move-object/from16 v123, v75

    move-object/from16 v124, v42

    move-object/from16 v126, v43

    move-object/from16 v127, v8

    move-object/from16 v129, v50

    move-object/from16 v130, v23

    move-object/from16 v131, v9

    move-object/from16 v132, v17

    move-object/from16 v133, v0

    move-object/from16 v134, v30

    move-object/from16 v135, v57

    move-object/from16 v137, v10

    move-object/from16 v138, v90

    move-object/from16 v139, v13

    move-object/from16 v140, v15

    move-object/from16 v141, v83

    move-object/from16 v142, v38

    move-object/from16 v143, v77

    move-object/from16 v144, v51

    move-object/from16 v145, v53

    move-object/from16 v146, v4

    move-object/from16 v147, v64

    move-object/from16 v148, v20

    move-object/from16 v149, v5

    move-object/from16 v152, v67

    move-object/from16 v153, v6

    move-object/from16 v155, v36

    move-object/from16 v158, v47

    move-object/from16 v159, v81

    move-object/from16 v160, v74

    move-object/from16 v161, v41

    move-object/from16 v162, v11

    move-object/from16 v163, v27

    move-object/from16 v164, v55

    move-object/from16 v165, v24

    move-object/from16 v166, v32

    move-object/from16 v167, v2

    move-object/from16 v168, v37

    move-object/from16 v169, v14

    move-object/from16 v170, v60

    move-object/from16 v171, v34

    move-object/from16 v172, v45

    move-object/from16 v175, v3

    move-object/from16 v176, v70

    move-object/from16 v177, v62

    move-object/from16 v179, v72

    move-object/from16 v180, v39

    move-object/from16 v181, v48

    move-object/from16 v182, v71

    move-object/from16 v183, v22

    move-object/from16 v184, v31

    move-object/from16 v185, v73

    move-object/from16 v186, v82

    move-object/from16 v187, v29

    move-object/from16 v188, v21

    move-object/from16 v189, v52

    move-object/from16 v190, v76

    move-object/from16 v191, v26

    move-object/from16 v192, v7

    move-object/from16 v193, v79

    move-object/from16 v195, v86

    move-object/from16 v197, v44

    move-object/from16 v90, v1

    move-object/from16 v93, v16

    move-object/from16 v94, v65

    move-object/from16 v95, v68

    move-object/from16 v96, v61

    move-object/from16 v97, v49

    move-object/from16 v98, v66

    invoke-direct/range {v90 .. v201}, LX/382;-><init>(LX/5pD;LX/5pD;LX/1cV;LX/2qa;LX/3HW;LX/3by;LX/1bt;LX/2sr;LX/1cE;LX/2s4;LX/350;LX/1cv;LX/1c0;LX/1m0;LX/2cZ;LX/1ct;LX/8nU;LX/312;LX/5O6;LX/5Z9;LX/1d0;LX/2kd;LX/1cI;LX/6Dk;LX/1zd;LX/2Y1;LX/2aM;LX/7Mz;LX/2rz;LX/2pn;LX/2nw;Lcom/whatsapp/calling/screenshare/ScreenShareResourceManager;LX/2fv;LX/5No;LX/3IT;LX/2ZT;LX/3H3;LX/33c;LX/2fw;LX/2d5;LX/5qv;LX/2ao;LX/2ap;LX/37g;LX/3Kb;LX/2ZV;LX/2Y2;LX/2iC;LX/2aN;LX/1cz;LX/3J5;LX/2sM;LX/352;LX/3GC;LX/89j;LX/2U8;LX/2iW;LX/1cc;LX/2pp;LX/34w;LX/2sJ;LX/2iX;LX/2tD;LX/34c;LX/34r;LX/354;LX/34x;LX/351;LX/2f6;LX/31i;LX/3cV;LX/1Mk;LX/2AS;LX/2sa;LX/3Qa;LX/2rl;LX/34v;LX/2q7;LX/1bn;LX/2sO;LX/34l;LX/31v;LX/2fD;LX/1Pl;LX/3Iz;LX/44u;LX/3QV;LX/2bV;LX/34b;LX/2qy;LX/3Qb;LX/3Wk;LX/2ot;LX/2SV;LX/2LX;LX/1bw;LX/1ch;LX/1cl;LX/1Mu;LX/2sF;LX/0zY;LX/2hY;LX/6E2;LX/454;LX/1cX;Lcom/whatsapp/voipcalling/JNIUtils;Lcom/whatsapp/voipcalling/camera/VoipCameraManager;LX/8oO;LX/8oO;LX/8oO;LX/8oO;)V

    move-object/from16 v0, v218

    iput-object v1, v0, LX/10O;->A00:LX/382;

    invoke-virtual {v1}, LX/382;->A0C()V

    return-void
.end method

.method public handleMessage(Landroid/os/Message;)V
    .locals 3

    iget v2, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x1

    if-eq v2, v1, :cond_6

    const/4 v0, 0x2

    if-eq v2, v0, :cond_2

    const/4 v0, 0x4

    if-eq v2, v0, :cond_4

    const/4 v0, 0x5

    if-ne v2, v0, :cond_0

    iget-boolean v0, p0, LX/10O;->A01:Z

    if-nez v0, :cond_1

    const-string/jumbo v0, "voice-service-wrapper/handler WHAT_SERVICE_ON_UNBIND is called while isBound is false"

    :goto_0
    invoke-static {v0}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    :cond_0
    return-void

    :cond_1
    iget-object v2, p0, LX/10O;->A03:Ljava/util/HashSet;

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v0, "voice-service-wrapper/handler WHAT_SERVICE_ON_UNBIND is called with mismatch voiceServiceBinderComponent, actual "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", given "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    invoke-static {v0, v1}, LX/000;->A0R(Ljava/lang/Object;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_2
    const-string/jumbo v0, "voice-service-wrapper/handler WHAT_STOP_SERVICE"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, LX/10O;->A02:Z

    iget-boolean v0, p0, LX/10O;->A01:Z

    goto :goto_1

    :cond_3
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    invoke-static {v2}, LX/0yR;->A1X(Ljava/util/AbstractCollection;)Z

    move-result v2

    iput-boolean v2, p0, LX/10O;->A01:Z

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v0, "voice-service-wrapper/handler WHAT_SERVICE_ON_UNBIND -- isBound ? "

    invoke-static {v0, v1, v2}, LX/0yK;->A1C(Ljava/lang/String;Ljava/lang/StringBuilder;Z)V

    iget-boolean v0, p0, LX/10O;->A02:Z

    :goto_1
    if-nez v0, :cond_0

    const-string/jumbo v0, "voice-service-wrapper destroyVoiceService"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v0, p0, LX/10O;->A00:LX/382;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, LX/382;->A0D()V

    const/4 v0, 0x0

    iput-object v0, p0, LX/10O;->A00:LX/382;

    return-void

    :cond_4
    const-string/jumbo v0, "voice-service-wrapper/handler WHAT_SERVICE_ON_BIND"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v0, p0, LX/10O;->A00:LX/382;

    if-nez v0, :cond_5

    invoke-virtual {p0}, LX/10O;->A00()V

    :cond_5
    iput-boolean v1, p0, LX/10O;->A01:Z

    iget-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, LX/8nV;

    iget-object v0, p0, LX/10O;->A03:Ljava/util/HashSet;

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, LX/10O;->A00:LX/382;

    invoke-interface {v1, v0}, LX/8nV;->BZx(LX/382;)V

    return-void

    :cond_6
    iget-object v0, p0, LX/10O;->A00:LX/382;

    if-nez v0, :cond_7

    invoke-virtual {p0}, LX/10O;->A00()V

    iput-boolean v1, p0, LX/10O;->A02:Z

    :cond_7
    iget-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    invoke-static {v1}, LX/38Z;->A07(Ljava/lang/Object;)V

    check-cast v1, LX/35r;

    iget-object v0, p0, LX/10O;->A00:LX/382;

    invoke-static {v0}, LX/38Z;->A07(Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, LX/382;->A0S(LX/35r;)V

    return-void
.end method
