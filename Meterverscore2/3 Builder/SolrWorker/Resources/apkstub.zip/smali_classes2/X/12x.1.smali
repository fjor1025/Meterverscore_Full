.class public LX/12x;
.super LX/0Ve;
.source ""


# instance fields
.field public final A00:Landroid/widget/ImageView;

.field public final A01:Landroid/widget/ImageView;

.field public final A02:Landroid/widget/ImageView;

.field public final A03:Landroid/widget/TextView;

.field public final A04:Landroid/widget/TextView;

.field public final A05:LX/29u;

.field public final A06:LX/2sJ;

.field public final A07:LX/34x;

.field public final A08:LX/1Pl;


# direct methods
.method public constructor <init>(Landroid/view/View;LX/29u;LX/2sJ;LX/34x;LX/1Pl;)V
    .locals 1

    invoke-direct {p0, p1}, LX/0Ve;-><init>(Landroid/view/View;)V

    iput-object p3, p0, LX/12x;->A06:LX/2sJ;

    iput-object p5, p0, LX/12x;->A08:LX/1Pl;

    iput-object p4, p0, LX/12x;->A07:LX/34x;

    iput-object p2, p0, LX/12x;->A05:LX/29u;

    const v0, 0x7f0b0832

    invoke-static {p1, v0}, LX/0yU;->A05(Landroid/view/View;I)Landroid/widget/ImageView;

    move-result-object v0

    iput-object v0, p0, LX/12x;->A01:Landroid/widget/ImageView;

    const v0, 0x7f0b10d5

    invoke-static {p1, v0}, LX/0yQ;->A0O(Landroid/view/View;I)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, LX/12x;->A03:Landroid/widget/TextView;

    const v0, 0x7f0b198a

    invoke-static {p1, v0}, LX/0yQ;->A0O(Landroid/view/View;I)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, LX/12x;->A04:Landroid/widget/TextView;

    const v0, 0x7f0b1a89

    invoke-static {p1, v0}, LX/0yU;->A05(Landroid/view/View;I)Landroid/widget/ImageView;

    move-result-object v0

    iput-object v0, p0, LX/12x;->A02:Landroid/widget/ImageView;

    const v0, 0x7f0b09ea

    invoke-static {p1, v0}, LX/0yU;->A05(Landroid/view/View;I)Landroid/widget/ImageView;

    move-result-object v0

    iput-object v0, p0, LX/12x;->A00:Landroid/widget/ImageView;

    return-void
.end method
