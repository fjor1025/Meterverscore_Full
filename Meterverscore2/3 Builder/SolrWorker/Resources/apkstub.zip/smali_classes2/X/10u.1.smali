.class public final LX/10u;
.super Landroid/widget/LinearLayout;
.source ""


# instance fields
.field public A00:Landroid/widget/TextView;

.field public A01:Landroid/widget/TextView;

.field public A02:Lcom/gbwhatsapp/WaImageView;

.field public final A03:I

.field public final A04:LX/2Oz;

.field public final A05:LX/5OD;

.field public final A06:LX/2fS;

.field public final A07:LX/6Cs;

.field public final A08:LX/6Cs;


# direct methods
.method public constructor <init>(Landroid/content/Context;LX/2Oz;LX/5OD;LX/2fS;I)V
    .locals 4

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x5

    invoke-static {p3, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    invoke-static {p2, p4}, LX/0yK;->A0X(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-direct {p0, p1, v3, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance v0, LX/3rc;

    invoke-direct {v0, p0}, LX/3rc;-><init>(LX/10u;)V

    invoke-static {v0}, LX/7Zg;->A01(LX/8wH;)LX/6Cs;

    move-result-object v0

    iput-object v0, p0, LX/10u;->A08:LX/6Cs;

    new-instance v0, LX/3rb;

    invoke-direct {v0, p0}, LX/3rb;-><init>(LX/10u;)V

    invoke-static {v0}, LX/7Zg;->A01(LX/8wH;)LX/6Cs;

    move-result-object v0

    iput-object v0, p0, LX/10u;->A07:LX/6Cs;

    invoke-static {p0}, LX/0yN;->A0H(Landroid/view/View;)Landroid/view/LayoutInflater;

    move-result-object v1

    const v0, 0x7f0e0755

    invoke-virtual {v1, v0, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    const v0, 0x7f0b14a3

    invoke-static {v1, v0}, LX/0yP;->A0I(Landroid/view/View;I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/gbwhatsapp/WaImageView;

    iput-object v0, p0, LX/10u;->A02:Lcom/gbwhatsapp/WaImageView;

    const v0, 0x7f0b14a4

    invoke-static {v1, v0}, LX/0yO;->A0F(Landroid/view/View;I)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, LX/10u;->A01:Landroid/widget/TextView;

    const v0, 0x7f0b14a5

    invoke-static {v1, v0}, LX/0yO;->A0F(Landroid/view/View;I)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, LX/10u;->A00:Landroid/widget/TextView;

    iget-object v0, p0, LX/10u;->A01:Landroid/widget/TextView;

    invoke-static {v0, v2}, LX/5ad;->A06(Landroid/view/View;Z)V

    iput p5, p0, LX/10u;->A03:I

    iput-object p3, p0, LX/10u;->A05:LX/5OD;

    iput-object p2, p0, LX/10u;->A04:LX/2Oz;

    iput-object p4, p0, LX/10u;->A06:LX/2fS;

    return-void
.end method

.method private final getPaddingVerticalDivider()I
    .locals 1

    iget-object v0, p0, LX/10u;->A07:LX/6Cs;

    invoke-static {v0}, LX/0yO;->A06(LX/6Cs;)I

    move-result v0

    return v0
.end method

.method private final getPaddingVerticalFixed()I
    .locals 1

    iget-object v0, p0, LX/10u;->A08:LX/6Cs;

    invoke-static {v0}, LX/0yO;->A06(LX/6Cs;)I

    move-result v0

    return v0
.end method


# virtual methods
.method public final setItemPaddingIfNeeded(Z)V
    .locals 4

    iget-object v3, p0, LX/10u;->A08:LX/6Cs;

    invoke-static {v3}, LX/0yO;->A06(LX/6Cs;)I

    move-result v2

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    iget-object v0, p0, LX/10u;->A07:LX/6Cs;

    invoke-static {v0}, LX/0yO;->A06(LX/6Cs;)I

    move-result v0

    :goto_0
    add-int/2addr v2, v0

    invoke-static {v3}, LX/0yO;->A06(LX/6Cs;)I

    move-result v0

    invoke-virtual {p0, v1, v0, v1, v2}, Landroid/view/View;->setPadding(IIII)V

    return-void

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public final setSecondaryText(Ljava/lang/String;)V
    .locals 4

    iget-object v3, p0, LX/10u;->A05:LX/5OD;

    invoke-static {p0}, LX/0yQ;->A0F(Landroid/view/View;)Landroid/content/Context;

    move-result-object v2

    iget-object v1, p0, LX/10u;->A00:Landroid/widget/TextView;

    iget-object v0, p0, LX/10u;->A06:LX/2fS;

    invoke-virtual {v3, v2, v1, v0, p1}, LX/5OD;->A00(Landroid/content/Context;Landroid/widget/TextView;LX/2fS;Ljava/lang/String;)V

    return-void
.end method

.method public final setText(Ljava/lang/String;)V
    .locals 4

    iget-object v3, p0, LX/10u;->A05:LX/5OD;

    invoke-static {p0}, LX/0yQ;->A0F(Landroid/view/View;)Landroid/content/Context;

    move-result-object v2

    iget-object v1, p0, LX/10u;->A01:Landroid/widget/TextView;

    iget-object v0, p0, LX/10u;->A06:LX/2fS;

    invoke-virtual {v3, v2, v1, v0, p1}, LX/5OD;->A00(Landroid/content/Context;Landroid/widget/TextView;LX/2fS;Ljava/lang/String;)V

    return-void
.end method
