.class public abstract LX/10o;
.super Landroid/widget/FrameLayout;
.source ""


# instance fields
.field public A00:LX/69Q;

.field public A01:LX/5Ue;

.field public A02:LX/31S;

.field public A03:LX/34w;

.field public A04:LX/2ss;

.field public A05:LX/5Qe;

.field public A06:LX/2yj;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public final A00(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;
    .locals 4

    const/high16 v3, -0x1000000

    if-eqz p1, :cond_1

    new-instance v0, LX/0PR;

    invoke-direct {v0, p1}, LX/0PR;-><init>(Landroid/graphics/Bitmap;)V

    invoke-virtual {v0}, LX/0PR;->A00()LX/0UP;

    move-result-object v0

    const/high16 v2, -0x1000000

    iget-object v0, v0, LX/0UP;->A01:LX/0RY;

    if-eqz v0, :cond_0

    iget v2, v0, LX/0RY;->A08:I

    :cond_0
    :goto_0
    const/4 v1, -0x1

    const v0, 0x3e99999a    # 0.3f

    invoke-static {v0, v2, v1}, LX/0ZN;->A03(FII)I

    move-result v1

    invoke-static {v0, v2, v3}, LX/0ZN;->A03(FII)I

    move-result v0

    sget-object v2, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-static {v1, v0}, LX/0yS;->A1X(II)[I

    move-result-object v1

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0, v2, v1}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    return-object v0

    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const v0, 0x7f060019

    invoke-static {v1, v0}, LX/0ZW;->A03(Landroid/content/Context;I)I

    move-result v2

    goto :goto_0
.end method

.method public abstract getCardView()Landroidx/cardview/widget/CardView;
.end method

.method public final getChatsCache()LX/2ss;
    .locals 1

    iget-object v0, p0, LX/10o;->A04:LX/2ss;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string v0, "chatsCache"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0
.end method

.method public final getContactAvatars()LX/5Ue;
    .locals 1

    iget-object v0, p0, LX/10o;->A01:LX/5Ue;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string v0, "contactAvatars"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0
.end method

.method public final getContactPhotosBitmapManager()LX/31S;
    .locals 1

    iget-object v0, p0, LX/10o;->A02:LX/31S;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string v0, "contactPhotosBitmapManager"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0
.end method

.method public abstract getFollowersView()Landroid/widget/TextView;
.end method

.method public abstract getNameViewController()LX/5YE;
.end method

.method public final getNewsletterNumberFormatter()LX/5Qe;
    .locals 1

    iget-object v0, p0, LX/10o;->A05:LX/5Qe;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string/jumbo v0, "newsletterNumberFormatter"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0
.end method

.method public final getSharedPreferencesFactory()LX/2yj;
    .locals 1

    iget-object v0, p0, LX/10o;->A06:LX/2yj;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string/jumbo v0, "sharedPreferencesFactory"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0
.end method

.method public final getSystemServices()LX/34w;
    .locals 1

    iget-object v0, p0, LX/10o;->A03:LX/34w;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string/jumbo v0, "systemServices"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0
.end method

.method public final getTextEmojiLabelViewControllerFactory()LX/69Q;
    .locals 1

    iget-object v0, p0, LX/10o;->A00:LX/69Q;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string/jumbo v0, "textEmojiLabelViewControllerFactory"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0
.end method

.method public abstract getThumbnailView()Landroid/widget/ImageView;
.end method

.method public final setChatsCache(LX/2ss;)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {p1, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object p1, p0, LX/10o;->A04:LX/2ss;

    return-void
.end method

.method public final setContactAvatars(LX/5Ue;)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {p1, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object p1, p0, LX/10o;->A01:LX/5Ue;

    return-void
.end method

.method public final setContactPhotosBitmapManager(LX/31S;)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {p1, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object p1, p0, LX/10o;->A02:LX/31S;

    return-void
.end method

.method public final setNewsletterNumberFormatter(LX/5Qe;)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {p1, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object p1, p0, LX/10o;->A05:LX/5Qe;

    return-void
.end method

.method public final setSharedPreferencesFactory(LX/2yj;)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {p1, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object p1, p0, LX/10o;->A06:LX/2yj;

    return-void
.end method

.method public final setSystemServices(LX/34w;)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {p1, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object p1, p0, LX/10o;->A03:LX/34w;

    return-void
.end method

.method public final setTextEmojiLabelViewControllerFactory(LX/69Q;)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {p1, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    iput-object p1, p0, LX/10o;->A00:LX/69Q;

    return-void
.end method
