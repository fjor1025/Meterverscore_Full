.class public final LX/0yU;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static A00(Landroid/database/Cursor;)I
    .locals 1

    const-string v0, "jid"

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public static A01(Ljava/util/AbstractCollection;I)I
    .locals 0

    invoke-virtual {p0}, Ljava/util/AbstractCollection;->size()I

    move-result p0

    sub-int/2addr p0, p1

    return p0
.end method

.method public static A02(I)Landroid/content/ContentValues;
    .locals 1

    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0, p0}, Landroid/content/ContentValues;-><init>(I)V

    return-object v0
.end method

.method public static A03(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;
    .locals 1

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0, p0, p1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    return-object v0
.end method

.method public static A04(LX/6Cs;)Landroid/os/Handler;
    .locals 0

    invoke-interface {p0}, LX/6Cs;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/os/Handler;

    return-object p0
.end method

.method public static A05(Landroid/view/View;I)Landroid/widget/ImageView;
    .locals 0

    invoke-static {p0, p1}, LX/0Zj;->A02(Landroid/view/View;I)Landroid/view/View;

    move-result-object p0

    check-cast p0, Landroid/widget/ImageView;

    return-object p0
.end method

.method public static A06(LX/07x;I)Landroid/widget/ImageView;
    .locals 0

    invoke-virtual {p0, p1}, LX/07x;->findViewById(I)Landroid/view/View;

    move-result-object p0

    check-cast p0, Landroid/widget/ImageView;

    return-object p0
.end method

.method public static A07(Ljava/lang/Object;Ljava/lang/Object;)LX/0QC;
    .locals 1

    new-instance v0, LX/0QC;

    invoke-direct {v0, p0, p1}, LX/0QC;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v0
.end method

.method public static A08(LX/0t6;)LX/0YU;
    .locals 1

    new-instance v0, LX/0YU;

    invoke-direct {v0, p0}, LX/0YU;-><init>(LX/0t6;)V

    return-object v0
.end method

.method public static A09()LX/0B6;
    .locals 1

    new-instance v0, LX/0B6;

    invoke-direct {v0}, LX/0B6;-><init>()V

    return-object v0
.end method

.method public static A0A()LX/0B5;
    .locals 1

    new-instance v0, LX/0B5;

    invoke-direct {v0}, LX/0B5;-><init>()V

    return-object v0
.end method

.method public static A0B()LX/0B7;
    .locals 1

    new-instance v0, LX/0B7;

    invoke-direct {v0}, LX/0B7;-><init>()V

    return-object v0
.end method

.method public static A0C(Lcom/gbwhatsapp/wds/components/bottomsheet/Hilt_WDSBottomSheetDialogFragment;)LX/5hl;
    .locals 0

    invoke-virtual {p0}, Lcom/gbwhatsapp/wds/components/bottomsheet/Hilt_WDSBottomSheetDialogFragment;->generatedComponent()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LX/5hl;

    return-object p0
.end method

.method public static A0D(Ljava/util/Map$Entry;)Lcom/whatsapp/jid/DeviceJid;
    .locals 0

    invoke-interface {p0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/whatsapp/jid/DeviceJid;

    return-object p0
.end method

.method public static A0E(LX/6gE;)LX/1A5;
    .locals 0

    invoke-virtual {p0}, LX/6gE;->A0H()LX/6gn;

    move-result-object p0

    check-cast p0, LX/1A5;

    return-object p0
.end method

.method public static A0F(Ljava/util/Iterator;)LX/1fG;
    .locals 0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LX/1fG;

    return-object p0
.end method

.method public static A0G(LX/8oO;)LX/1YT;
    .locals 0

    invoke-interface {p0}, LX/8oO;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LX/1YT;

    return-object p0
.end method

.method public static A0H()LX/4LC;
    .locals 1

    new-instance v0, LX/4LC;

    invoke-direct {v0}, LX/4LC;-><init>()V

    return-object v0
.end method

.method public static A0I(Ljava/util/Iterator;)LX/3em;
    .locals 0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LX/3em;

    return-object p0
.end method

.method public static A0J(Landroid/content/Context;LX/0fI;)LX/4AO;
    .locals 1

    new-instance v0, LX/4AO;

    invoke-direct {v0, p0, p1}, LX/4AO;-><init>(Landroid/content/Context;LX/0fI;)V

    return-object v0
.end method

.method public static A0K([B)Ljava/io/ByteArrayInputStream;
    .locals 1

    new-instance v0, Ljava/io/ByteArrayInputStream;

    invoke-direct {v0, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    return-object v0
.end method

.method public static A0L()Ljava/io/ByteArrayOutputStream;
    .locals 1

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    return-object v0
.end method

.method public static A0M(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    .locals 1

    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public static A0N(Ljava/lang/String;)Ljava/io/FileNotFoundException;
    .locals 1

    new-instance v0, Ljava/io/FileNotFoundException;

    invoke-direct {v0, p0}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    return-object v0
.end method

.method public static A0O(Ljava/lang/String;)Ljava/io/InvalidObjectException;
    .locals 1

    new-instance v0, Ljava/io/InvalidObjectException;

    invoke-direct {v0, p0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    return-object v0
.end method

.method public static A0P(J)Ljava/lang/Double;
    .locals 2

    long-to-double v0, p0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    return-object v0
.end method

.method public static A0Q(Ljava/lang/Object;Ljava/util/AbstractMap;)Ljava/lang/Integer;
    .locals 0

    invoke-virtual {p1, p0}, Ljava/util/AbstractMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    return-object p0
.end method

.method public static A0R(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Number;
    .locals 0

    invoke-interface {p1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    return-object p0
.end method

.method public static A0S(LX/7th;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LX/7th;->A00:Ljava/lang/Object;

    invoke-static {p0}, LX/38Z;->A07(Ljava/lang/Object;)V

    return-object p0
.end method

.method public static A0T(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    .locals 1

    new-instance v0, Ljava/lang/RuntimeException;

    invoke-direct {v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    return-object v0
.end method

.method public static A0U(LX/381;)Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, LX/381;->A0o()Ljava/lang/String;

    move-result-object v0

    :cond_0
    return-object v0
.end method

.method public static A0V(Ljava/lang/Object;Ljava/lang/String;Ljava/util/Locale;[Ljava/lang/Object;I)Ljava/lang/String;
    .locals 0

    aput-object p0, p3, p4

    invoke-static {p2, p1, p3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static A0W(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .locals 1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    return-object v0
.end method

.method public static A0X(Ljava/lang/String;)Ljava/net/URL;
    .locals 1

    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    return-object v0
.end method

.method public static A0Y()Ljava/util/LinkedHashSet;
    .locals 1

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    return-object v0
.end method

.method public static A0Z()Ljava/util/LinkedList;
    .locals 1

    new-instance v0, Ljava/util/LinkedList;

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    return-object v0
.end method

.method public static A0a(Ljava/lang/Object;Ljava/util/AbstractMap;)Ljava/util/List;
    .locals 0

    invoke-virtual {p1, p0}, Ljava/util/AbstractMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    return-object p0
.end method

.method public static A0b()Ljava/util/Random;
    .locals 1

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    return-object v0
.end method

.method public static A0c()Ljava/util/concurrent/atomic/AtomicInteger;
    .locals 1

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    return-object v0
.end method

.method public static A0d(J)Ljava/util/concurrent/atomic/AtomicLong;
    .locals 1

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    invoke-direct {v0, p0, p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    return-object v0
.end method

.method public static A0e([B)Ljavax/crypto/spec/IvParameterSpec;
    .locals 1

    new-instance v0, Ljavax/crypto/spec/IvParameterSpec;

    invoke-direct {v0, p0}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    return-object v0
.end method

.method public static A0f(Ljava/util/Map;)Lorg/json/JSONObject;
    .locals 1

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/util/Map;)V

    return-object v0
.end method

.method public static A0g(Ljava/util/List;)Z
    .locals 0

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p0

    xor-int/lit8 p0, p0, 0x1

    return p0
.end method

.method public static A0h()[I
    .locals 1

    const/4 v0, 0x1

    new-array v0, v0, [I

    return-object v0
.end method

.method public static A0i()[LX/3C7;
    .locals 1

    const/4 v0, 0x1

    new-array v0, v0, [LX/3C7;

    return-object v0
.end method

.method public static A0j()[LX/3C7;
    .locals 1

    const/4 v0, 0x4

    new-array v0, v0, [LX/3C7;

    return-object v0
.end method

.method public static A0k()[Ljava/lang/Object;
    .locals 1

    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    return-object v0
.end method

.method public static A0l()[Ljava/lang/String;
    .locals 1

    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/String;

    return-object v0
.end method
