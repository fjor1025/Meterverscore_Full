.class public LX/10F;
.super Landroid/os/Handler;
.source ""


# instance fields
.field public final synthetic A00:LX/1bx;

.field public final synthetic A01:LX/2h2;

.field public final synthetic A02:LX/1cx;


# direct methods
.method public constructor <init>(Landroid/os/Looper;LX/1bx;LX/2h2;LX/1cx;)V
    .locals 0

    iput-object p3, p0, LX/10F;->A01:LX/2h2;

    iput-object p4, p0, LX/10F;->A02:LX/1cx;

    iput-object p2, p0, LX/10F;->A00:LX/1bx;

    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 5

    iget-object v4, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v4, LX/36P;

    iget v1, p1, Landroid/os/Message;->what:I

    const/4 v0, 0x3

    if-eq v1, v0, :cond_4

    const/4 v0, 0x4

    if-eq v1, v0, :cond_3

    const/4 v0, 0x5

    if-eq v1, v0, :cond_1

    const/4 v0, 0x6

    if-eq v1, v0, :cond_0

    const/4 v0, 0x7

    if-ne v1, v0, :cond_5

    iget-object v2, p0, LX/10F;->A02:LX/1cx;

    invoke-static {v2}, LX/30F;->A03(LX/30F;)Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-static {v2, v1}, LX/1cx;->A00(LX/1cx;Ljava/util/Iterator;)LX/458;

    move-result-object v0

    invoke-interface {v0}, LX/458;->BVv()V

    goto :goto_0

    :cond_0
    iget-object v0, p0, LX/10F;->A00:LX/1bx;

    invoke-virtual {v0}, LX/1bx;->A07()V

    return-void

    :cond_1
    iget-object v3, p0, LX/10F;->A01:LX/2h2;

    iget v1, p1, Landroid/os/Message;->arg1:I

    iget-object v0, v3, LX/2h2;->A04:LX/1cx;

    invoke-virtual {v0, v4, v1}, LX/1cx;->A09(LX/36P;I)V

    iget-object v2, v4, LX/36P;->A0P:LX/36O;

    if-eqz v2, :cond_2

    iget-object v0, v3, LX/2h2;->A05:LX/1cg;

    invoke-static {v0}, LX/30F;->A03(LX/30F;)Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/42W;

    invoke-interface {v0, v2}, LX/42W;->BWa(LX/36O;)V

    goto :goto_1

    :cond_2
    iget-object v2, v3, LX/2h2;->A03:LX/1bx;

    invoke-static {v4}, LX/30N;->A00(LX/36P;)LX/1ZJ;

    move-result-object v1

    const/4 v0, 0x0

    invoke-virtual {v2, v1, v0}, LX/1bx;->A09(LX/1ZJ;Z)V

    return-void

    :cond_3
    iget-object v3, p0, LX/10F;->A00:LX/1bx;

    invoke-static {v4}, LX/30N;->A00(LX/36P;)LX/1ZJ;

    move-result-object v2

    iget-object v1, v3, LX/1bx;->A00:LX/3bx;

    const/16 v0, 0x28

    invoke-static {v3, v2, v0}, LX/3fN;->A00(Ljava/lang/Object;Ljava/lang/Object;I)LX/3fN;

    move-result-object v0

    invoke-virtual {v1, v0}, LX/3bx;->Biw(Ljava/lang/Runnable;)V

    iget-object v1, p0, LX/10F;->A02:LX/1cx;

    iget v0, p1, Landroid/os/Message;->arg1:I

    invoke-virtual {v1, v4, v0}, LX/1cx;->A09(LX/36P;I)V

    return-void

    :cond_4
    iget-object v2, p0, LX/10F;->A02:LX/1cx;

    invoke-static {v2}, LX/30F;->A03(LX/30F;)Ljava/util/Iterator;

    move-result-object v1

    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-static {v2, v1}, LX/1cx;->A00(LX/1cx;Ljava/util/Iterator;)LX/458;

    move-result-object v0

    invoke-interface {v0, v4}, LX/458;->BQV(LX/36P;)V

    goto :goto_2

    :cond_5
    return-void
.end method
