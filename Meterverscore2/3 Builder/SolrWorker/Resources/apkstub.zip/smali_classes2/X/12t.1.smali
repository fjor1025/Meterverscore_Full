.class public LX/12t;
.super LX/0Ve;
.source ""


# instance fields
.field public final A00:Lcom/gbwhatsapp/WaTextView;

.field public final A01:LX/1Pl;


# direct methods
.method public constructor <init>(Landroid/view/View;LX/1Pl;)V
    .locals 1

    invoke-direct {p0, p1}, LX/0Ve;-><init>(Landroid/view/View;)V

    iput-object p2, p0, LX/12t;->A01:LX/1Pl;

    const v0, 0x7f0b0cd4

    invoke-static {p1, v0}, LX/0yT;->A0N(Landroid/view/View;I)Lcom/gbwhatsapp/WaTextView;

    move-result-object v0

    iput-object v0, p0, LX/12t;->A00:Lcom/gbwhatsapp/WaTextView;

    return-void
.end method
