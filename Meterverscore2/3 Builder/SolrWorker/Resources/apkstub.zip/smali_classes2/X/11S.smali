.class public LX/11S;
.super LX/08e;
.source ""


# instance fields
.field public final synthetic A00:LX/2w2;

.field public final synthetic A01:LX/3DC;


# direct methods
.method public constructor <init>(LX/2w2;LX/3DC;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            "this$0",
            "val$viewModelComponentBuilder"
        }
    .end annotation

    iput-object p2, p0, LX/11S;->A01:LX/3DC;

    iput-object p1, p0, LX/11S;->A00:LX/2w2;

    invoke-direct {p0}, LX/08e;-><init>()V

    return-void
.end method


# virtual methods
.method public A02(LX/0Yd;Ljava/lang/Class;Ljava/lang/String;)LX/0V7;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "key",
            "modelClass",
            "handle"
        }
    .end annotation

    new-instance v3, LX/2VW;

    invoke-direct {v3}, LX/2VW;-><init>()V

    iget-object v0, p0, LX/11S;->A00:LX/2w2;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, v0, LX/2w2;->A00:LX/0Yd;

    iput-object v3, v0, LX/2w2;->A01:LX/2VW;

    iget-object v2, v0, LX/2w2;->A03:LX/3GZ;

    iget-object v0, v0, LX/2w2;->A02:LX/4UP;

    new-instance v1, LX/1Ej;

    invoke-direct {v1, p1, v0, v2}, LX/1Ej;-><init>(LX/0Yd;LX/4UP;LX/3GZ;)V

    const-class v0, LX/3dp;

    invoke-static {v0, v1}, LX/244;->A01(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LX/3dp;

    check-cast v4, LX/1Ej;

    const/16 v0, 0x95

    invoke-static {v0}, LX/8HA;->builderWithExpectedSize(I)LX/7jg;

    move-result-object v2

    const-string v1, "com.whatsapp.calling.chatmessages.AdhocParticipantBottomSheetViewModel"

    iget-object v0, v4, LX/1Ej;->A00:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.status.advertise.AdvertiseViewModel"

    iget-object v0, v4, LX/1Ej;->A01:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.qrcode.AgentDeviceLoginViewModel"

    iget-object v0, v4, LX/1Ej;->A02:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.conversationslist.ArchiveHeaderViewModel"

    iget-object v0, v4, LX/1Ej;->A03:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.lightweightcalling.viewmodel.AudioChatBottomSheetViewModel"

    iget-object v0, v4, LX/1Ej;->A04:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.lightweightcalling.viewmodel.AudioChatCallingViewModel"

    iget-object v0, v4, LX/1Ej;->A05:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.expressionstray.avatars.AvatarExpressionsViewModel"

    iget-object v0, v4, LX/1Ej;->A07:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.avatar.home.AvatarHomeViewModel"

    iget-object v0, v4, LX/1Ej;->A0E:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.avatar.profilephoto.AvatarProfilePhotoViewModel"

    iget-object v0, v4, LX/1Ej;->A0F:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.userban.ui.viewmodel.BanAppealViewModel"

    iget-object v0, v4, LX/1Ej;->A0G:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.registration.report.BanReportViewModel"

    iget-object v0, v4, LX/1Ej;->A0I:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.blockbusiness.blockreasonlist.BlockReasonListViewModel"

    iget-object v0, v4, LX/1Ej;->A0L:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.bonsai.BonsaiConversationTitleViewModel"

    iget-object v0, v4, LX/1Ej;->A0M:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.bonsai.discovery.BonsaiDiscoveryViewModel"

    iget-object v0, v4, LX/1Ej;->A0N:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.bonsai.prompts.BonsaiPromptsViewModel"

    iget-object v0, v4, LX/1Ej;->A0O:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.bonsai.BonsaiSystemMessageBottomSheetViewModel"

    iget-object v0, v4, LX/1Ej;->A0P:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.bonsai.chatinfo.BotChatInfoViewModel"

    iget-object v0, v4, LX/1Ej;->A0Q:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.bonsai.embodiment.BotEmbodimentViewModel"

    iget-object v0, v4, LX/1Ej;->A0R:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.controls.viewmodel.BottomSheetViewModel"

    iget-object v0, v4, LX/1Ej;->A0S:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.BrazilAddPixKeyViewModel"

    iget-object v0, v4, LX/1Ej;->A0T:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.BrazilAddPixSelectionViewModel"

    iget-object v0, v4, LX/1Ej;->A0U:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.BrazilIncomeCollectionViewModel"

    iget-object v0, v4, LX/1Ej;->A0V:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.BrazilPixKeySettingViewModel"

    iget-object v0, v4, LX/1Ej;->A0W:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.report.BusinessActivityReportViewModel"

    iget-object v0, v4, LX/1Ej;->A0X:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.businessapisearch.viewmodel.BusinessApiSearchActivityViewModel"

    iget-object v0, v4, LX/1Ej;->A0Y:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.biz.compliance.viewmodel.BusinessComplianceViewModel"

    iget-object v0, v4, LX/1Ej;->A0Z:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.businessdirectory.viewmodel.BusinessDirectoryActivityViewModel"

    iget-object v0, v4, LX/1Ej;->A0a:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.businessdirectory.viewmodel.BusinessDirectoryConsumerHomeViewModel"

    iget-object v0, v4, LX/1Ej;->A0b:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.businessdirectory.viewmodel.BusinessDirectoryContextualSearchViewModel"

    iget-object v0, v4, LX/1Ej;->A0c:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.businessdirectory.viewmodel.BusinessDirectoryEducationNuxViewModel"

    iget-object v0, v4, LX/1Ej;->A0d:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.businessdirectory.viewmodel.BusinessDirectoryFrequentContactedViewModel"

    iget-object v0, v4, LX/1Ej;->A0e:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.businessdirectory.viewmodel.BusinessDirectoryPopularApiBusinessesViewModel"

    iget-object v0, v4, LX/1Ej;->A0f:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.community.communityInfo.viewModels.CAGInfoChatLockViewModel"

    iget-object v0, v4, LX/1Ej;->A0g:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.community.communityInfo.CAGInfoViewModel"

    iget-object v0, v4, LX/1Ej;->A0h:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.avatar.viewmodel.CallAvatarViewModel"

    iget-object v0, v4, LX/1Ej;->A0i:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.controls.viewmodel.CallControlButtonsViewModel"

    iget-object v0, v4, LX/1Ej;->A0j:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.callgrid.viewmodel.CallGridViewModel"

    iget-object v0, v4, LX/1Ej;->A0k:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.callheader.viewmodel.CallHeaderViewModel"

    iget-object v0, v4, LX/1Ej;->A0l:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.calllink.viewmodel.CallLinkViewModel"

    iget-object v0, v4, LX/1Ej;->A0m:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.chatmessages.CallLogMessageParticipantBottomSheetViewModel"

    iget-object v0, v4, LX/1Ej;->A0n:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.callrating.viewmodel.CallRatingViewModel"

    iget-object v0, v4, LX/1Ej;->A0o:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.callscreen.viewmodel.CallScreenViewModel"

    iget-object v0, v4, LX/1Ej;->A0p:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.contact.picker.viewmodels.CallSuggestionsViewModel"

    iget-object v0, v4, LX/1Ej;->A0q:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.callhistory.viewmodel.CallsHistoryFragmentV2ViewModel"

    iget-object v0, v4, LX/1Ej;->A0r:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.catalogcategory.view.viewmodel.CatalogAllCategoryViewModel"

    iget-object v0, v4, LX/1Ej;->A0s:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.catalogcategory.view.viewmodel.CatalogCategoryGroupsViewModel"

    iget-object v0, v4, LX/1Ej;->A0t:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.catalogcategory.view.viewmodel.CatalogCategoryTabsViewModel"

    iget-object v0, v4, LX/1Ej;->A0u:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.catalogsearch.view.viewmodel.CatalogSearchViewModel"

    iget-object v0, v4, LX/1Ej;->A0v:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.chatlock.ChatLockAuthViewModel"

    iget-object v0, v4, LX/1Ej;->A0w:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.migration.transfer.ui.ChatTransferViewModel"

    iget-object v0, v4, LX/1Ej;->A0x:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.authgraphql.ui.CommonViewModel"

    iget-object v0, v4, LX/1Ej;->A0y:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.community.communitysettings.viewmodel.CommunitySettingsViewModel"

    iget-object v0, v4, LX/1Ej;->A0z:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.companionmode.registration.CompanionRegistrationViewModel"

    iget-object v0, v4, LX/1Ej;->A10:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.biz.product.viewmodel.ComplianceInfoViewModel"

    iget-object v0, v4, LX/1Ej;->A11:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.datasharingdisclosure.ui.ConsumerDisclosureViewModel"

    iget-object v0, v4, LX/1Ej;->A13:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.inappsupport.ui.ContactUsWithAiViewModel"

    iget-object v0, v4, LX/1Ej;->A14:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.community.ConversationCommunityViewModel"

    iget-object v0, v4, LX/1Ej;->A15:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.conversation.viewmodel.ConversationSearchViewModel"

    iget-object v0, v4, LX/1Ej;->A16:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.conversation.viewmodel.ConversationTitleViewModel"

    iget-object v0, v4, LX/1Ej;->A17:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.countrygating.viewmodel.CountryGatingViewModel"

    iget-object v0, v4, LX/1Ej;->A18:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.countries.CountryListViewModel"

    iget-object v0, v4, LX/1Ej;->A19:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.status.crossposting.CrossPostingUpdatesViewModel"

    iget-object v0, v4, LX/1Ej;->A1A:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.status.advertise.CtwaStatusUpsellBottomSheetTriggerViewModel"

    iget-object v0, v4, LX/1Ej;->A1B:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.expressionstray.emoji.EmojiExpressionsViewModel"

    iget-object v0, v4, LX/1Ej;->A1D:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.backup.encryptedbackup.EncBackupViewModel"

    iget-object v0, v4, LX/1Ej;->A1E:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.migration.export.ui.ExportMigrationViewModel"

    iget-object v0, v4, LX/1Ej;->A1F:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.expressionstray.conversation.ExpressionsKeyboardViewModel"

    iget-object v0, v4, LX/1Ej;->A1G:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.expressionstray.ExpressionsSearchViewModel"

    iget-object v0, v4, LX/1Ej;->A1H:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.extensions.phoenix.viewmodel.ExtensionsFooterViewModel"

    iget-object v0, v4, LX/1Ej;->A1I:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.wabloks.base.GenericBkLayoutViewModelWithReload"

    iget-object v0, v4, LX/1Ej;->A1n:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.wabloks.base.GenericBkLayoutViewModel"

    iget-object v0, v4, LX/1Ej;->A1m:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.expressionstray.gifs.GifExpressionsSearchViewModel"

    iget-object v0, v4, LX/1Ej;->A1q:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.backup.google.viewmodel.GoogleDriveNewUserSetupViewModel"

    iget-object v0, v4, LX/1Ej;->A1r:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.migration.android.view.GoogleMigrateImporterViewModel"

    iget-object v0, v4, LX/1Ej;->A1s:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.callhistory.group.GroupCallParticipantSuggestionsViewModel"

    iget-object v0, v4, LX/1Ej;->A1t:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.psa.viewmodel.GroupCallPsaViewModel"

    iget-object v0, v4, LX/1Ej;->A1u:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.group.HistorySettingViewModel"

    iget-object v0, v4, LX/1Ej;->A1v:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.home.HomeViewModel"

    iget-object v0, v4, LX/1Ej;->A1w:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.inappbugreporting.InAppBugReportingViewModel"

    iget-object v0, v4, LX/1Ej;->A1x:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.callgrid.viewmodel.InCallBannerViewModel"

    iget-object v0, v4, LX/1Ej;->A1y:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.IndiaPaymentSettingsViewModel"

    iget-object v0, v4, LX/1Ej;->A1z:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.international.IndiaUpiInternationalActivationViewModel"

    iget-object v0, v4, LX/1Ej;->A20:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.international.IndiaUpiInternationalValidateQrViewModel"

    iget-object v0, v4, LX/1Ej;->A21:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.IndiaUpiMandateHistoryViewModel"

    iget-object v0, v4, LX/1Ej;->A22:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.mapper.register.IndiaUpiMapperLinkViewModel"

    iget-object v0, v4, LX/1Ej;->A23:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.IndiaUpiNumberSettingsViewModel"

    iget-object v0, v4, LX/1Ej;->A24:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.IndiaUpiPauseMandateViewModel"

    iget-object v0, v4, LX/1Ej;->A25:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.IndiaUpiPaymentTransactionConfirmationBottomSheetViewModel"

    iget-object v0, v4, LX/1Ej;->A26:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.viewmodel.IndiaUpiSecureQrCodeViewModel"

    iget-object v0, v4, LX/1Ej;->A27:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.conversationslist.InteropViewModel"

    iget-object v0, v4, LX/1Ej;->A28:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.contact.picker.viewmodels.InviteNonWhatsAppContactPickerViewModel"

    iget-object v0, v4, LX/1Ej;->A29:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.companiondevice.LinkedDeviceEditDeviceViewModel"

    iget-object v0, v4, LX/1Ej;->A2A:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.companiondevice.LinkedDeviceEnterNicknameViewModel"

    iget-object v0, v4, LX/1Ej;->A2B:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.companiondevice.LinkedDevicesSharedViewModel"

    iget-object v0, v4, LX/1Ej;->A2C:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.companiondevice.LinkedDevicesViewModel"

    iget-object v0, v4, LX/1Ej;->A2D:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.businessdirectory.viewmodel.LocationOptionPickerViewModel"

    iget-object v0, v4, LX/1Ej;->A2E:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.callgrid.viewmodel.MenuBottomSheetViewModel"

    iget-object v0, v4, LX/1Ej;->A2F:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.conversation.conversationrow.message.MessageDetailsViewModel"

    iget-object v0, v4, LX/1Ej;->A2G:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.conversation.conversationrow.messagerating.MessageRatingViewModel"

    iget-object v0, v4, LX/1Ej;->A2H:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.conversation.conversationrow.MessageSelectionViewModel"

    iget-object v0, v4, LX/1Ej;->A2I:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.mute.ui.MuteDialogViewModel"

    iget-object v0, v4, LX/1Ej;->A2J:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.registration.accountdefence.NewDeviceConfirmationRegistrationViewModel"

    iget-object v0, v4, LX/1Ej;->A2K:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.product.newsletterenforcements.geosuspend.NewsletterGeosuspensionInfoViewModel"

    iget-object v0, v4, LX/1Ej;->A2L:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.product.integrityappeals.NewsletterRequestReviewViewModel"

    iget-object v0, v4, LX/1Ej;->A2M:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.product.newsletterenforcements.suspension.NewsletterSuspensionInfoViewModel"

    iget-object v0, v4, LX/1Ej;->A2N:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.biz.order.viewmodel.OrderInfoViewModel"

    iget-object v0, v4, LX/1Ej;->A2O:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.callgrid.viewmodel.OrientationViewModel"

    iget-object v0, v4, LX/1Ej;->A2P:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.controls.viewmodel.ParticipantsListViewModel"

    iget-object v0, v4, LX/1Ej;->A2Q:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.PaymentIncentiveViewModel"

    iget-object v0, v4, LX/1Ej;->A2T:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.payments.ui.viewmodel.PaymentMerchantAccountViewModel"

    iget-object v0, v4, LX/1Ej;->A2U:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.pininchat.banner.PinInChatBannerViewModel"

    iget-object v0, v4, LX/1Ej;->A2V:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.polls.PollCreatorViewModel"

    iget-object v0, v4, LX/1Ej;->A2W:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.polls.PollResultsViewModel"

    iget-object v0, v4, LX/1Ej;->A2X:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.privacy.disclosure.ui.PrivacyDisclosureContainerViewModel"

    iget-object v0, v4, LX/1Ej;->A2Y:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.biz.product.viewmodel.ProductBottomSheetViewModel"

    iget-object v0, v4, LX/1Ej;->A2Z:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.quickactionbar.viewmodel.QuickActionBarViewModel"

    iget-object v0, v4, LX/1Ej;->A2b:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.reactions.ReactionsTrayViewModel"

    iget-object v0, v4, LX/1Ej;->A2c:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.pnh.RequestPhoneNumberViewModel"

    iget-object v0, v4, LX/1Ej;->A2d:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.backup.google.viewmodel.RestoreFromBackupViewModel"

    iget-object v0, v4, LX/1Ej;->A2e:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.screenshare.ScreenShareViewModel"

    iget-object v0, v4, LX/1Ej;->A2f:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.expressionstray.stickers.funstickers.viewmodels.SearchFunStickersViewModel"

    iget-object v0, v4, LX/1Ej;->A2g:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.conversation.selection.SelectedImageAlbumViewModel"

    iget-object v0, v4, LX/1Ej;->A2h:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.settings.SettingsAccountViewModel"

    iget-object v0, v4, LX/1Ej;->A2i:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.settings.SettingsChatViewModel"

    iget-object v0, v4, LX/1Ej;->A2j:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.settings.SettingsDataUsageViewModel"

    iget-object v0, v4, LX/1Ej;->A2k:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.backup.google.viewmodel.SettingsGoogleDriveViewModel"

    iget-object v0, v4, LX/1Ej;->A2l:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.settings.SettingsPasskeysViewModel"

    iget-object v0, v4, LX/1Ej;->A2m:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.settings.SettingsPrivacyCameraEffectsViewModel"

    iget-object v0, v4, LX/1Ej;->A2n:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.settings.SettingsSetupUserProxyViewModel"

    iget-object v0, v4, LX/1Ej;->A2o:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.settings.SettingsUserProxyViewModel"

    iget-object v0, v4, LX/1Ej;->A2p:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.conversation.conversationrow.viewmodel.SharePhoneNumberRowViewModel"

    iget-object v0, v4, LX/1Ej;->A2q:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.chatinfo.SharePhoneNumberViewModel"

    iget-object v0, v4, LX/1Ej;->A2r:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.biz.catalog.viewmodel.ShareProductViewModel"

    iget-object v0, v4, LX/1Ej;->A2s:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.shops.ShopsBkLayoutViewModel"

    iget-object v0, v4, LX/1Ej;->A2t:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.shops.ShopsProductPreviewFragmentViewModel"

    iget-object v0, v4, LX/1Ej;->A2u:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.status.archive.StatusArchiveSettingsViewModel"

    iget-object v0, v4, LX/1Ej;->A2v:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.expressionstray.stickers.StickerExpressionsViewModel"

    iget-object v0, v4, LX/1Ej;->A2x:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.inappsupport.ui.SupportBkLayoutViewModel"

    iget-object v0, v4, LX/1Ej;->A2y:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.conversation.viewmodel.SurveyViewModel"

    iget-object v0, v4, LX/1Ej;->A2z:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.tosgating.viewmodel.ToSGatingViewModel"

    iget-object v0, v4, LX/1Ej;->A30:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.schedulecall.upcomingcalls.viewmodel.UpcomingActivityViewModel"

    iget-object v0, v4, LX/1Ej;->A31:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.status.advertise.UpdatesAdvertiseViewModel"

    iget-object v0, v4, LX/1Ej;->A32:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.profile.UsernameViewModel"

    iget-object v0, v4, LX/1Ej;->A34:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.biz.catalog.view.variants.VariantsCarouselFragmentViewModel"

    iget-object v0, v4, LX/1Ej;->A35:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.whatsapp.calling.callgrid.viewmodel.VoiceChatGridViewModel"

    iget-object v0, v4, LX/1Ej;->A36:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.wabloks.commerce.ui.viewmodel.WaBkExtensionsLayoutViewModel"

    iget-object v0, v4, LX/1Ej;->A37:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.extensions.bloks.viewmodel.WaExtensionsNavBarViewModel"

    iget-object v0, v4, LX/1Ej;->A38:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.extensions.bloks.viewmodel.WaFlowsViewModel"

    iget-object v0, v4, LX/1Ej;->A39:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    const-string v1, "com.gbwhatsapp.waffle.wfac.ui.WfacBanViewModel"

    iget-object v0, v4, LX/1Ej;->A3A:LX/41P;

    invoke-virtual {v2, v1, v0}, LX/7jg;->put(Ljava/lang/Object;Ljava/lang/Object;)LX/7jg;

    invoke-virtual {v2}, LX/7jg;->build()LX/8HA;

    move-result-object v0

    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, LX/8HA;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/41P;

    if-eqz v0, :cond_0

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LX/0V7;

    new-instance v0, LX/3eC;

    invoke-direct {v0, v3}, LX/3eC;-><init>(LX/2VW;)V

    iget-object v1, v2, LX/0V7;->A01:Ljava/util/Set;

    monitor-enter v1

    :try_start_0
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    monitor-exit v1

    return-object v2

    :catchall_0
    move-exception v0

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    :cond_0
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "Expected the @HiltViewModel-annotated class \'"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\' to be available in the multi-binding of @HiltViewModelMap but none was found."

    invoke-static {v0, v1}, LX/000;->A0J(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalStateException;

    move-result-object v0

    throw v0
.end method
