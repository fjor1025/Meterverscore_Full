.class public LX/12Q;
.super LX/0V7;
.source ""


# instance fields
.field public final A00:LX/2T2;

.field public final A01:LX/2sr;

.field public final A02:LX/3J5;

.field public final A03:LX/2Fd;

.field public final A04:LX/2W6;

.field public final A05:LX/2mt;

.field public final A06:LX/2sJ;

.field public final A07:LX/2ss;

.field public final A08:LX/2oL;

.field public final A09:LX/2sk;

.field public final A0A:LX/2kp;

.field public final A0B:LX/30K;

.field public final A0C:LX/1Pl;

.field public final A0D:LX/2ct;

.field public final A0E:LX/1bo;

.field public final A0F:LX/1ZI;

.field public final A0G:LX/2X5;

.field public final A0H:LX/11b;

.field public final A0I:LX/11b;

.field public final A0J:LX/11b;

.field public final A0K:LX/11b;

.field public final A0L:LX/5Zk;

.field public final A0M:LX/11a;

.field public final A0N:LX/11a;

.field public final A0O:LX/454;


# direct methods
.method public constructor <init>(LX/2T2;LX/2sr;LX/3J5;LX/2Fd;LX/2W6;LX/2mt;LX/2sJ;LX/2ss;LX/2oL;LX/2sk;LX/2kp;LX/30K;LX/1Pl;LX/1bo;LX/1ZI;LX/2X5;LX/5Zk;LX/454;)V
    .locals 3

    invoke-direct {p0}, LX/0V7;-><init>()V

    new-instance v0, LX/11b;

    invoke-direct {v0}, LX/11b;-><init>()V

    iput-object v0, p0, LX/12Q;->A0H:LX/11b;

    new-instance v0, LX/11b;

    invoke-direct {v0}, LX/11b;-><init>()V

    iput-object v0, p0, LX/12Q;->A0K:LX/11b;

    new-instance v0, LX/11b;

    invoke-direct {v0}, LX/11b;-><init>()V

    iput-object v0, p0, LX/12Q;->A0I:LX/11b;

    new-instance v0, LX/11b;

    invoke-direct {v0}, LX/11b;-><init>()V

    iput-object v0, p0, LX/12Q;->A0J:LX/11b;

    invoke-static {}, LX/0yO;->A0W()Ljava/lang/Integer;

    move-result-object v1

    new-instance v0, LX/11a;

    invoke-direct {v0, v1}, LX/11a;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12Q;->A0M:LX/11a;

    new-instance v0, LX/11a;

    invoke-direct {v0, v1}, LX/11a;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12Q;->A0N:LX/11a;

    new-instance v0, LX/1Xs;

    invoke-direct {v0, p0}, LX/1Xs;-><init>(LX/12Q;)V

    iput-object v0, p0, LX/12Q;->A0D:LX/2ct;

    iput-object p7, p0, LX/12Q;->A06:LX/2sJ;

    move-object/from16 v1, p13

    iput-object v1, p0, LX/12Q;->A0C:LX/1Pl;

    move-object/from16 v1, p17

    iput-object v1, p0, LX/12Q;->A0L:LX/5Zk;

    iput-object p2, p0, LX/12Q;->A01:LX/2sr;

    move-object/from16 v1, p18

    iput-object v1, p0, LX/12Q;->A0O:LX/454;

    iput-object p8, p0, LX/12Q;->A07:LX/2ss;

    iput-object p3, p0, LX/12Q;->A02:LX/3J5;

    iput-object p11, p0, LX/12Q;->A0A:LX/2kp;

    move-object/from16 v2, p14

    iput-object v2, p0, LX/12Q;->A0E:LX/1bo;

    iput-object p6, p0, LX/12Q;->A05:LX/2mt;

    iput-object p4, p0, LX/12Q;->A03:LX/2Fd;

    iput-object p10, p0, LX/12Q;->A09:LX/2sk;

    iput-object p12, p0, LX/12Q;->A0B:LX/30K;

    iput-object p5, p0, LX/12Q;->A04:LX/2W6;

    iput-object p9, p0, LX/12Q;->A08:LX/2oL;

    iput-object p1, p0, LX/12Q;->A00:LX/2T2;

    move-object/from16 v1, p15

    iput-object v1, p0, LX/12Q;->A0F:LX/1ZI;

    move-object/from16 v1, p16

    iput-object v1, p0, LX/12Q;->A0G:LX/2X5;

    invoke-virtual {v2, v0}, LX/30F;->A05(Ljava/lang/Object;)V

    return-void
.end method

.method public static A00(LX/3xg;LX/1ZI;LX/2X5;)LX/0vx;
    .locals 2

    const/4 v1, 0x3

    new-instance v0, LX/48H;

    invoke-direct {v0, p2, p0, p1, v1}, LX/48H;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    return-object v0
.end method


# virtual methods
.method public A0F()V
    .locals 2

    iget-object v1, p0, LX/12Q;->A0E:LX/1bo;

    iget-object v0, p0, LX/12Q;->A0D:LX/2ct;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    return-void
.end method

.method public A0G()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12Q;->A0H:LX/11b;

    return-object v0
.end method

.method public A0H()V
    .locals 3

    iget-object v2, p0, LX/12Q;->A0O:LX/454;

    const/16 v1, 0x1e

    new-instance v0, LX/3fE;

    invoke-direct {v0, p0, v1}, LX/3fE;-><init>(Ljava/lang/Object;I)V

    invoke-interface {v2, v0}, LX/454;->Bit(Ljava/lang/Runnable;)V

    return-void
.end method

.method public A0I(LX/2UN;)V
    .locals 2

    iget-object v0, p0, LX/12Q;->A0H:LX/11b;

    invoke-virtual {v0}, LX/0Y8;->A06()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2YN;

    if-eqz v0, :cond_1

    iget-object v0, v0, LX/2YN;->A00:Ljava/util/List;

    invoke-static {p1, v0}, LX/3ep;->A0B(LX/2UN;Ljava/util/List;)Z

    iget-object v1, p0, LX/12Q;->A0K:LX/11b;

    invoke-virtual {v1}, LX/0Y8;->A06()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v1, v0}, LX/0Y8;->A0F(Ljava/lang/Object;)V

    :cond_0
    iget-object v1, p0, LX/12Q;->A0I:LX/11b;

    invoke-virtual {v1}, LX/0Y8;->A06()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v1, v0}, LX/0Y8;->A0F(Ljava/lang/Object;)V

    :cond_1
    return-void
.end method

.method public A0J(Lcom/whatsapp/jid/UserJid;)Z
    .locals 2

    iget-object v0, p0, LX/12Q;->A0H:LX/11b;

    invoke-virtual {v0}, LX/0Y8;->A06()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2YN;

    if-eqz v0, :cond_0

    iget-object v0, v0, LX/2YN;->A01:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v0, 0x1

    if-nez v1, :cond_1

    :cond_0
    const/4 v0, 0x0

    :cond_1
    return v0
.end method
