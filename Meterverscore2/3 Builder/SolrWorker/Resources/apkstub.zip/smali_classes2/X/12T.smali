.class public LX/12T;
.super LX/0V7;
.source ""


# instance fields
.field public A00:I

.field public A01:J

.field public A02:LX/3IZ;

.field public A03:LX/31w;

.field public A04:LX/3ep;

.field public A05:Ljava/lang/Integer;

.field public A06:Ljava/lang/String;

.field public A07:Ljava/lang/String;

.field public A08:LX/8wH;

.field public A09:Z

.field public A0A:Z

.field public final A0B:LX/08P;

.field public final A0C:LX/08S;

.field public final A0D:LX/08S;

.field public final A0E:LX/08S;

.field public final A0F:LX/08S;

.field public final A0G:LX/08S;

.field public final A0H:LX/08S;

.field public final A0I:LX/08S;

.field public final A0J:LX/2qa;

.field public final A0K:LX/26h;

.field public final A0L:LX/3by;

.field public final A0M:LX/2sr;

.field public final A0N:LX/2d6;

.field public final A0O:LX/2so;

.field public final A0P:LX/3iN;

.field public final A0Q:LX/5jS;

.field public final A0R:LX/3iY;

.field public final A0S:Lcom/gbwhatsapp/community/membersuggestedgroups/MemberSuggestedGroupsManager;

.field public final A0T:LX/3J5;

.field public final A0U:LX/2sI;

.field public final A0V:LX/1cw;

.field public final A0W:LX/352;

.field public final A0X:LX/2sJ;

.field public final A0Y:LX/354;

.field public final A0Z:LX/2ss;

.field public final A0a:LX/44p;

.field public final A0b:LX/1bz;

.field public final A0c:LX/3Qa;

.field public final A0d:LX/2sk;

.field public final A0e:LX/2rV;

.field public final A0f:LX/1Pl;

.field public final A0g:Lcom/gbwhatsapp/group/CreateSubGroupSuggestionProtocolHelper;

.field public final A0h:LX/3QV;

.field public final A0i:LX/3zY;

.field public final A0j:LX/2ic;

.field public final A0k:LX/2qc;

.field public final A0l:LX/1cd;

.field public final A0m:LX/3QW;

.field public final A0n:LX/2rg;

.field public final A0o:LX/1cp;

.field public final A0p:LX/2Si;

.field public final A0q:LX/2Ug;

.field public final A0r:LX/2kw;

.field public final A0s:LX/1ZI;

.field public final A0t:LX/34u;

.field public final A0u:LX/34b;

.field public final A0v:LX/2s1;

.field public final A0w:LX/2pv;

.field public final A0x:LX/11a;

.field public final A0y:LX/11a;

.field public final A0z:LX/11a;

.field public final A10:LX/11a;

.field public final A11:LX/11a;

.field public final A12:LX/3iy;

.field public final A13:LX/4LC;

.field public final A14:LX/4LC;

.field public final A15:LX/4LC;

.field public final A16:LX/4LC;

.field public final A17:LX/454;

.field public final A18:Ljava/util/List;

.field public final A19:Ljava/util/List;

.field public final A1A:Ljava/util/List;

.field public final A1B:Ljava/util/List;

.field public final A1C:Ljava/util/Set;

.field public final A1D:LX/8wH;

.field public final A1E:LX/8wH;


# direct methods
.method public constructor <init>(LX/2qa;LX/26h;LX/3by;LX/2sr;LX/2d6;LX/2so;LX/5jS;Lcom/gbwhatsapp/community/membersuggestedgroups/MemberSuggestedGroupsManager;LX/3J5;LX/1cw;LX/352;LX/2sJ;LX/354;LX/2ss;LX/1bz;LX/3Qa;LX/2sk;LX/2rV;LX/1Pl;Lcom/gbwhatsapp/group/CreateSubGroupSuggestionProtocolHelper;LX/3QV;LX/2ic;LX/1cd;LX/3QW;LX/1cp;LX/2Si;LX/2Ug;LX/2kw;LX/1ZI;LX/34u;LX/34b;LX/2s1;LX/2pv;LX/454;)V
    .locals 19

    move-object/from16 v9, p0

    invoke-direct {v9}, LX/0V7;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, v9, LX/12T;->A0A:Z

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A0D:LX/08S;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    new-instance v8, LX/11a;

    invoke-direct {v8, v0}, LX/11a;-><init>(Ljava/lang/Object;)V

    iput-object v8, v9, LX/12T;->A0z:LX/11a;

    new-instance v7, LX/11a;

    invoke-direct {v7, v0}, LX/11a;-><init>(Ljava/lang/Object;)V

    iput-object v7, v9, LX/12T;->A10:LX/11a;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A0C:LX/08S;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A0E:LX/08S;

    new-instance v6, LX/08P;

    invoke-direct {v6}, LX/08P;-><init>()V

    iput-object v6, v9, LX/12T;->A0B:LX/08P;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A0H:LX/08S;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A0I:LX/08S;

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v1

    new-instance v0, LX/11a;

    invoke-direct {v0, v1}, LX/11a;-><init>(Ljava/lang/Object;)V

    iput-object v0, v9, LX/12T;->A11:LX/11a;

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v1

    new-instance v0, LX/11a;

    invoke-direct {v0, v1}, LX/11a;-><init>(Ljava/lang/Object;)V

    iput-object v0, v9, LX/12T;->A0y:LX/11a;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    new-instance v0, LX/11a;

    invoke-direct {v0, v2}, LX/11a;-><init>(Ljava/lang/Object;)V

    iput-object v0, v9, LX/12T;->A0x:LX/11a;

    invoke-static {}, LX/0yU;->A0H()LX/4LC;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A16:LX/4LC;

    invoke-static {}, LX/0yU;->A0H()LX/4LC;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A15:LX/4LC;

    invoke-static {}, LX/0yU;->A0H()LX/4LC;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A14:LX/4LC;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A0G:LX/08S;

    const/4 v2, 0x0

    new-instance v0, LX/4LC;

    invoke-direct {v0, v2}, LX/4LC;-><init>(Ljava/lang/Object;)V

    iput-object v0, v9, LX/12T;->A13:LX/4LC;

    const/4 v10, 0x2

    new-instance v0, LX/49D;

    invoke-direct {v0, v9, v10}, LX/49D;-><init>(Ljava/lang/Object;I)V

    iput-object v0, v9, LX/12T;->A1E:LX/8wH;

    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object v0, v9, LX/12T;->A19:Ljava/util/List;

    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object v0, v9, LX/12T;->A18:Ljava/util/List;

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A1B:Ljava/util/List;

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A1A:Ljava/util/List;

    invoke-static {}, LX/001;->A0z()Ljava/util/HashSet;

    move-result-object v0

    iput-object v0, v9, LX/12T;->A1C:Ljava/util/Set;

    iput-object v2, v9, LX/12T;->A05:Ljava/lang/Integer;

    iput-boolean v1, v9, LX/12T;->A09:Z

    const/4 v0, -0x1

    iput v0, v9, LX/12T;->A00:I

    new-instance v5, LX/46V;

    invoke-direct {v5, v9, v10}, LX/46V;-><init>(Ljava/lang/Object;I)V

    iput-object v5, v9, LX/12T;->A0U:LX/2sI;

    new-instance v4, LX/47D;

    invoke-direct {v4, v9, v1}, LX/47D;-><init>(Ljava/lang/Object;I)V

    iput-object v4, v9, LX/12T;->A0i:LX/3zY;

    const/4 v0, 0x1

    new-instance v3, LX/46a;

    invoke-direct {v3, v9, v0}, LX/46a;-><init>(Ljava/lang/Object;I)V

    iput-object v3, v9, LX/12T;->A0k:LX/2qc;

    new-instance v2, LX/46b;

    invoke-direct {v2, v9, v1}, LX/46b;-><init>(Ljava/lang/Object;I)V

    iput-object v2, v9, LX/12T;->A0n:LX/2rg;

    new-instance v1, LX/47Q;

    invoke-direct {v1, v9, v10}, LX/47Q;-><init>(Ljava/lang/Object;I)V

    iput-object v1, v9, LX/12T;->A0a:LX/44p;

    new-instance v0, LX/3iN;

    invoke-direct {v0}, LX/3iN;-><init>()V

    iput-object v0, v9, LX/12T;->A0P:LX/3iN;

    const/4 v10, 0x3

    new-instance v0, LX/49D;

    invoke-direct {v0, v9, v10}, LX/49D;-><init>(Ljava/lang/Object;I)V

    iput-object v0, v9, LX/12T;->A08:LX/8wH;

    const/4 v10, 0x4

    new-instance v0, LX/49D;

    invoke-direct {v0, v9, v10}, LX/49D;-><init>(Ljava/lang/Object;I)V

    iput-object v0, v9, LX/12T;->A1D:LX/8wH;

    move-object/from16 v0, p12

    iput-object v0, v9, LX/12T;->A0X:LX/2sJ;

    move-object/from16 v0, p19

    iput-object v0, v9, LX/12T;->A0f:LX/1Pl;

    move-object/from16 v0, p3

    iput-object v0, v9, LX/12T;->A0L:LX/3by;

    move-object/from16 v0, p1

    iput-object v0, v9, LX/12T;->A0J:LX/2qa;

    move-object/from16 v0, p4

    iput-object v0, v9, LX/12T;->A0M:LX/2sr;

    move-object/from16 v10, p34

    iput-object v10, v9, LX/12T;->A17:LX/454;

    move-object/from16 v16, p14

    move-object/from16 v0, v16

    iput-object v0, v9, LX/12T;->A0Z:LX/2ss;

    move-object/from16 v0, p31

    iput-object v0, v9, LX/12T;->A0u:LX/34b;

    move-object/from16 v0, p30

    iput-object v0, v9, LX/12T;->A0t:LX/34u;

    move-object/from16 v18, p9

    move-object/from16 v0, v18

    iput-object v0, v9, LX/12T;->A0T:LX/3J5;

    move-object/from16 v0, p11

    iput-object v0, v9, LX/12T;->A0W:LX/352;

    move-object/from16 v17, p10

    move-object/from16 v0, v17

    iput-object v0, v9, LX/12T;->A0V:LX/1cw;

    move-object/from16 v0, p27

    iput-object v0, v9, LX/12T;->A0q:LX/2Ug;

    move-object/from16 v0, p16

    iput-object v0, v9, LX/12T;->A0c:LX/3Qa;

    move-object/from16 v0, p33

    iput-object v0, v9, LX/12T;->A0w:LX/2pv;

    move-object/from16 v0, p21

    iput-object v0, v9, LX/12T;->A0h:LX/3QV;

    move-object/from16 v0, p24

    iput-object v0, v9, LX/12T;->A0m:LX/3QW;

    move-object/from16 v0, p28

    iput-object v0, v9, LX/12T;->A0r:LX/2kw;

    move-object/from16 v0, p32

    iput-object v0, v9, LX/12T;->A0v:LX/2s1;

    move-object/from16 v0, p13

    iput-object v0, v9, LX/12T;->A0Y:LX/354;

    move-object/from16 v0, p6

    iput-object v0, v9, LX/12T;->A0O:LX/2so;

    move-object/from16 v15, p25

    iput-object v15, v9, LX/12T;->A0o:LX/1cp;

    move-object/from16 v14, p15

    iput-object v14, v9, LX/12T;->A0b:LX/1bz;

    move-object/from16 v0, p5

    iput-object v0, v9, LX/12T;->A0N:LX/2d6;

    move-object/from16 v13, p22

    iput-object v13, v9, LX/12T;->A0j:LX/2ic;

    move-object/from16 v0, p17

    iput-object v0, v9, LX/12T;->A0d:LX/2sk;

    move-object/from16 v12, p23

    iput-object v12, v9, LX/12T;->A0l:LX/1cd;

    move-object/from16 v0, p8

    iput-object v0, v9, LX/12T;->A0S:Lcom/gbwhatsapp/community/membersuggestedgroups/MemberSuggestedGroupsManager;

    move-object/from16 v0, p26

    iput-object v0, v9, LX/12T;->A0p:LX/2Si;

    move-object/from16 v0, p2

    iput-object v0, v9, LX/12T;->A0K:LX/26h;

    move-object/from16 v0, p20

    iput-object v0, v9, LX/12T;->A0g:Lcom/gbwhatsapp/group/CreateSubGroupSuggestionProtocolHelper;

    move-object/from16 v0, p7

    iput-object v0, v9, LX/12T;->A0Q:LX/5jS;

    move-object/from16 v11, p29

    iput-object v11, v9, LX/12T;->A0s:LX/1ZI;

    move-object/from16 v0, p18

    iput-object v0, v9, LX/12T;->A0e:LX/2rV;

    move-object/from16 v0, v18

    invoke-virtual {v0, v11}, LX/3J5;->A06(LX/1ZJ;)LX/3ep;

    move-result-object v11

    iput-object v11, v9, LX/12T;->A04:LX/3ep;

    if-nez v11, :cond_0

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    :goto_0
    iput-object v0, v9, LX/12T;->A0F:LX/08S;

    invoke-virtual {v15, v2}, LX/30F;->A05(Ljava/lang/Object;)V

    move-object/from16 v0, v17

    invoke-virtual {v0, v5}, LX/30F;->A05(Ljava/lang/Object;)V

    invoke-virtual {v14, v1}, LX/30F;->A05(Ljava/lang/Object;)V

    invoke-virtual {v13, v4}, LX/2ic;->A00(LX/3zY;)V

    invoke-virtual {v12, v3}, LX/30F;->A05(Ljava/lang/Object;)V

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "CommunitySubgroupsViewModel/init/Creating serialExecutor: "

    invoke-static {v1, v0, v9}, LX/0yK;->A1P(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v1, 0x0

    new-instance v0, LX/3iy;

    invoke-direct {v0, v10, v1}, LX/3iy;-><init>(LX/454;Z)V

    iput-object v0, v9, LX/12T;->A12:LX/3iy;

    new-instance v1, LX/3iY;

    move-object/from16 v0, v16

    invoke-direct {v1, v0}, LX/3iY;-><init>(LX/2ss;)V

    iput-object v1, v9, LX/12T;->A0R:LX/3iY;

    const/16 v1, 0x23

    new-instance v0, LX/49I;

    invoke-direct {v0, v9, v1}, LX/49I;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v6, v7, v0}, LX/08P;->A0I(LX/0Y8;LX/0t5;)V

    new-instance v0, LX/49I;

    invoke-direct {v0, v9, v1}, LX/49I;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v6, v8, v0}, LX/08P;->A0I(LX/0Y8;LX/0t5;)V

    return-void

    :cond_0
    new-instance v0, LX/08S;

    invoke-direct {v0, v11}, LX/08S;-><init>(Ljava/lang/Object;)V

    goto :goto_0
.end method

.method public static A00(LX/0t6;LX/26g;LX/5MY;LX/1ZI;)LX/12T;
    .locals 2

    const/4 v1, 0x0

    new-instance v0, LX/48H;

    invoke-direct {v0, p3, p1, p2, v1}, LX/48H;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    new-instance v1, LX/0YU;

    invoke-direct {v1, v0, p0}, LX/0YU;-><init>(LX/0vx;LX/0t6;)V

    const-class v0, LX/12T;

    invoke-virtual {v1, v0}, LX/0YU;->A01(Ljava/lang/Class;)LX/0V7;

    move-result-object v0

    check-cast v0, LX/12T;

    return-object v0
.end method


# virtual methods
.method public A0F()V
    .locals 2

    iget-object v1, p0, LX/12T;->A0o:LX/1cp;

    iget-object v0, p0, LX/12T;->A0n:LX/2rg;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    iget-object v1, p0, LX/12T;->A0V:LX/1cw;

    iget-object v0, p0, LX/12T;->A0U:LX/2sI;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    iget-object v1, p0, LX/12T;->A0b:LX/1bz;

    iget-object v0, p0, LX/12T;->A0a:LX/44p;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    iget-object v1, p0, LX/12T;->A0j:LX/2ic;

    iget-object v0, p0, LX/12T;->A0i:LX/3zY;

    invoke-virtual {v1, v0}, LX/2ic;->A01(LX/3zY;)V

    iget-object v1, p0, LX/12T;->A0l:LX/1cd;

    iget-object v0, p0, LX/12T;->A0k:LX/2qc;

    invoke-virtual {v1, v0}, LX/30F;->A06(Ljava/lang/Object;)V

    return-void
.end method

.method public A0G()LX/3IZ;
    .locals 1

    iget-object v0, p0, LX/12T;->A02:LX/3IZ;

    return-object v0
.end method

.method public A0H()V
    .locals 2

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "CommunitySubgroupsViewModel/updateActivitySeen: "

    invoke-static {v1, v0, p0}, LX/0yK;->A1P(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/Object;)V

    iget-object v1, p0, LX/12T;->A12:LX/3iy;

    const/16 v0, 0x24

    invoke-static {v1, p0, v0}, LX/3hV;->A00(LX/3iy;Ljava/lang/Object;I)V

    return-void
.end method

.method public final A0I()V
    .locals 13

    iget-object v7, p0, LX/12T;->A19:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->clear()V

    iget-object v6, p0, LX/12T;->A1B:Ljava/util/List;

    iget-object v0, p0, LX/12T;->A0R:LX/3iY;

    invoke-static {v6, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v0, 0x1

    iget-object v5, p0, LX/12T;->A0s:LX/1ZI;

    invoke-virtual {p0, v5, v5, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    iget-object v0, p0, LX/12T;->A0Y:LX/354;

    invoke-static {v0}, LX/0yM;->A0C(LX/354;)Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v0, "dismissed_invite_member_row"

    invoke-static {v1, v0}, LX/0yO;->A1S(Landroid/content/SharedPreferences;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, LX/12T;->A0d:LX/2sk;

    invoke-virtual {v0, v5}, LX/2sk;->A0I(LX/1ZI;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v1, p0, LX/12T;->A0r:LX/2kw;

    iget-object v0, p0, LX/12T;->A04:LX/3ep;

    invoke-virtual {v1, v0}, LX/2kw;->A00(LX/3ep;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, LX/12T;->A0N:LX/2d6;

    iget-object v2, v0, LX/2d6;->A00:LX/1Pl;

    const/16 v1, 0xe20

    sget-object v0, LX/2vP;->A02:LX/2vP;

    invoke-virtual {v2, v0, v1}, LX/2sp;->A0W(LX/2vP;I)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, LX/12T;->A08:LX/8wH;

    new-instance v1, LX/2jJ;

    invoke-direct {v1, v5, v0}, LX/2jJ;-><init>(Lcom/whatsapp/jid/GroupJid;LX/8wH;)V

    const/4 v0, 0x2

    invoke-virtual {p0, v5, v1, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    :cond_0
    iget-object v2, p0, LX/12T;->A0f:LX/1Pl;

    const/16 v1, 0x1058

    sget-object v0, LX/2vP;->A02:LX/2vP;

    invoke-virtual {v2, v0, v1}, LX/2sp;->A0W(LX/2vP;I)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, LX/12T;->A05:Ljava/lang/Integer;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v3

    if-lez v3, :cond_1

    const/4 v0, 0x2

    new-instance v1, LX/49C;

    invoke-direct {v1, p0, v0}, LX/49C;-><init>(Ljava/lang/Object;I)V

    iget-object v0, p0, LX/12T;->A0d:LX/2sk;

    invoke-virtual {v0, v5}, LX/2sk;->A0E(Lcom/whatsapp/jid/GroupJid;)Z

    move-result v0

    if-eqz v0, :cond_c

    sget-object v0, LX/1u4;->A02:LX/1u4;

    :goto_0
    new-instance v2, LX/2lg;

    invoke-direct {v2, v0, v5, v1, v3}, LX/2lg;-><init>(LX/1u4;LX/1ZI;LX/8wI;I)V

    const/4 v1, 0x0

    const/16 v0, 0x13

    invoke-virtual {p0, v1, v2, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    :cond_1
    iget-object v0, p0, LX/12T;->A0d:LX/2sk;

    invoke-virtual {v0, v5}, LX/2sk;->A0E(Lcom/whatsapp/jid/GroupJid;)Z

    move-result v0

    if-eqz v0, :cond_2

    const/16 v0, 0xf

    invoke-virtual {p0, v5, v5, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    :cond_2
    const/16 v0, 0x10

    invoke-virtual {p0, v5, v5, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    iget-object v4, p0, LX/12T;->A0Q:LX/5jS;

    iget-object v3, v4, LX/5jS;->A01:LX/5MY;

    iget-boolean v0, v3, LX/5MY;->A03:Z

    if-nez v0, :cond_4

    const/4 v0, 0x1

    new-instance v8, LX/49C;

    invoke-direct {v8, p0, v0}, LX/49C;-><init>(Ljava/lang/Object;I)V

    const/4 v0, 0x0

    invoke-static {v6, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v8, v1}, LX/49C;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, LX/001;->A1Z(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    :goto_1
    check-cast v1, LX/2py;

    if-eqz v1, :cond_4

    iget-object v2, v1, LX/2py;->A02:Lcom/whatsapp/jid/GroupJid;

    const/4 v0, 0x2

    new-instance v1, LX/501;

    invoke-direct {v1, v2, v0}, LX/501;-><init>(LX/1ZJ;I)V

    const/4 v0, 0x4

    invoke-virtual {p0, v2, v1, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    :cond_4
    iget-boolean v0, v3, LX/5MY;->A07:Z

    if-eqz v0, :cond_17

    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_d

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v12

    const/4 v11, 0x0

    const/4 v10, 0x0

    :cond_5
    :goto_2
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_d

    invoke-static {v12}, LX/0yR;->A0T(Ljava/util/Iterator;)LX/2py;

    move-result-object v9

    iget-boolean v0, v3, LX/5MY;->A03:Z

    if-nez v0, :cond_6

    iget v1, v9, LX/2py;->A00:I

    const/4 v0, 0x3

    if-ne v1, v0, :cond_6

    goto :goto_2

    :cond_6
    if-nez v11, :cond_9

    iget-boolean v8, v3, LX/5MY;->A0D:Z

    const v0, 0x7f1215ac

    if-eqz v8, :cond_7

    const v0, 0x7f1215ab

    :cond_7
    const/4 v2, 0x0

    const/4 v1, 0x3

    if-eqz v8, :cond_8

    const/16 v1, 0xe

    :cond_8
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p0, v2, v0, v1}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    const/4 v11, 0x1

    :cond_9
    iget-boolean v0, p0, LX/12T;->A09:Z

    if-nez v0, :cond_a

    iget-object v1, p0, LX/12T;->A0Z:LX/2ss;

    iget-object v0, v9, LX/2py;->A02:Lcom/whatsapp/jid/GroupJid;

    invoke-virtual {v1, v0}, LX/2ss;->A0N(LX/1ZJ;)Z

    move-result v0

    if-eqz v0, :cond_a

    if-nez v10, :cond_5

    iget-boolean v1, p0, LX/12T;->A09:Z

    iget-object v0, p0, LX/12T;->A1E:LX/8wH;

    new-instance v8, LX/2jL;

    invoke-direct {v8, v0, v1}, LX/2jL;-><init>(LX/8wH;Z)V

    const/4 v2, 0x0

    const/16 v1, 0x14

    new-instance v0, LX/5QD;

    invoke-direct {v0, v2, v8, v1}, LX/5QD;-><init>(LX/1ZJ;Ljava/lang/Object;I)V

    invoke-interface {v7, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x1

    goto :goto_2

    :cond_a
    iget-object v2, v9, LX/2py;->A02:Lcom/whatsapp/jid/GroupJid;

    const/4 v0, 0x2

    new-instance v1, LX/501;

    invoke-direct {v1, v2, v0}, LX/501;-><init>(LX/1ZJ;I)V

    const/4 v0, 0x4

    invoke-virtual {p0, v2, v1, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    goto :goto_2

    :cond_b
    const/4 v1, 0x0

    goto/16 :goto_1

    :cond_c
    sget-object v0, LX/1u4;->A03:LX/1u4;

    goto/16 :goto_0

    :cond_d
    iget-object v0, p0, LX/12T;->A0O:LX/2so;

    invoke-virtual {v0, v5}, LX/2so;->A0E(LX/1ZI;)Z

    move-result v0

    const/16 v10, 0xc

    const/4 v12, 0x0

    const/4 v8, 0x1

    if-eqz v0, :cond_e

    invoke-virtual {v4, v10, v5}, LX/5jS;->Bp0(ILjava/lang/Object;)Z

    move-result v0

    const/4 v11, 0x1

    if-nez v0, :cond_f

    :cond_e
    const/4 v11, 0x0

    :cond_f
    const/4 v2, 0x0

    if-nez v11, :cond_10

    iget-object v9, p0, LX/12T;->A1A:Ljava/util/List;

    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_16

    :cond_10
    iget-boolean v4, v3, LX/5MY;->A0D:Z

    const v0, 0x7f12140b

    const/4 v1, 0x3

    if-eqz v4, :cond_11

    const v0, 0x7f12140a

    const/16 v1, 0xe

    :cond_11
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p0, v2, v0, v1}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    if-eqz v11, :cond_12

    invoke-virtual {p0, v5, v5, v10}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    :cond_12
    iget-object v9, p0, LX/12T;->A1A:Ljava/util/List;

    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_16

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v11

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_3
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_13

    invoke-static {v10}, LX/0yR;->A0T(Ljava/util/Iterator;)LX/2py;

    move-result-object v4

    iget-object v1, p0, LX/12T;->A1C:Ljava/util/Set;

    iget-object v0, v4, LX/2py;->A02:Lcom/whatsapp/jid/GroupJid;

    invoke-interface {v1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    new-instance v0, LX/2Jm;

    invoke-direct {v0, v4, v5, v1}, LX/2Jm;-><init>(LX/2py;Lcom/whatsapp/jid/GroupJid;Z)V

    invoke-virtual {v11, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_13
    iget v1, p0, LX/12T;->A00:I

    invoke-virtual {v11}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v10

    const/4 v0, -0x1

    if-ne v10, v0, :cond_14

    invoke-virtual {v11}, Ljava/util/AbstractCollection;->size()I

    move-result v10

    :cond_14
    iget-object v0, p0, LX/12T;->A0P:LX/3iN;

    invoke-static {v11, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :goto_4
    if-ge v12, v10, :cond_15

    invoke-virtual {v11, v12}, Ljava/util/AbstractList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LX/2Jm;

    iget-object v0, v4, LX/2Jm;->A00:LX/2py;

    iget-object v1, v0, LX/2py;->A02:Lcom/whatsapp/jid/GroupJid;

    const/4 v0, 0x5

    invoke-virtual {p0, v1, v4, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_4

    :cond_15
    invoke-virtual {v11}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    if-le v0, v10, :cond_16

    invoke-static {v11, v10}, LX/0yU;->A01(Ljava/util/AbstractCollection;I)I

    move-result v4

    iget-object v0, p0, LX/12T;->A1D:LX/8wH;

    new-instance v1, LX/2jK;

    invoke-direct {v1, v0, v4}, LX/2jK;-><init>(LX/8wH;I)V

    const/4 v0, 0x6

    invoke-virtual {p0, v2, v1, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    :cond_16
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v1

    const/4 v0, 0x2

    if-gt v1, v0, :cond_17

    const/4 v0, 0x3

    new-instance v4, LX/49C;

    invoke-direct {v4, p0, v0}, LX/49C;-><init>(Ljava/lang/Object;I)V

    instance-of v0, v6, Ljava/util/Collection;

    if-eqz v0, :cond_18

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_18

    :cond_17
    :goto_5
    const/16 v0, 0x11

    invoke-virtual {p0, v5, v5, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    const/16 v0, 0xb

    invoke-virtual {p0, v5, v5, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    iget-object v2, p0, LX/12T;->A0x:LX/11a;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v1

    iget-object v0, p0, LX/12T;->A1A:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    add-int/2addr v1, v0

    invoke-static {v2, v1}, LX/0Y8;->A04(LX/0Y8;I)V

    iget-object v0, p0, LX/12T;->A11:LX/11a;

    invoke-virtual {v0, v7}, LX/0Y8;->A0F(Ljava/lang/Object;)V

    return-void

    :cond_18
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_19
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_17

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v4, v0}, LX/49C;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, LX/001;->A1Z(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_17

    iget-boolean v0, v3, LX/5MY;->A06:Z

    if-eqz v0, :cond_17

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v0

    if-ne v0, v8, :cond_1a

    const v0, 0x7f120af1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/16 v0, 0xe

    invoke-virtual {p0, v2, v1, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    :cond_1a
    invoke-static {v6}, LX/0yR;->A0k(Ljava/util/List;)Ljava/lang/Integer;

    move-result-object v1

    const/16 v0, 0x12

    invoke-virtual {p0, v2, v1, v0}, LX/12T;->A0K(LX/1ZJ;Ljava/lang/Object;I)V

    goto :goto_5
.end method

.method public final A0J()V
    .locals 2

    iget-object v1, p0, LX/12T;->A18:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    iget-object v0, p0, LX/12T;->A1B:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, LX/12T;->A1A:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, LX/12T;->A0y:LX/11a;

    invoke-virtual {v0, v1}, LX/0Y8;->A0F(Ljava/lang/Object;)V

    return-void
.end method

.method public final A0K(LX/1ZJ;Ljava/lang/Object;I)V
    .locals 2

    iget-object v0, p0, LX/12T;->A0Q:LX/5jS;

    invoke-virtual {v0, p3, p2}, LX/5jS;->Bp0(ILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, LX/12T;->A02:LX/3IZ;

    invoke-virtual {v0, p3, p2}, LX/3IZ;->Bp0(ILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v1, p0, LX/12T;->A19:Ljava/util/List;

    new-instance v0, LX/5QD;

    invoke-direct {v0, p1, p2, p3}, LX/5QD;-><init>(LX/1ZJ;Ljava/lang/Object;I)V

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    return-void
.end method

.method public A0L(LX/1ZI;Ljava/lang/String;)V
    .locals 7

    move-object v2, p0

    if-eqz p2, :cond_0

    iput-object p2, p0, LX/12T;->A07:Ljava/lang/String;

    :cond_0
    iget-object v0, p0, LX/12T;->A10:LX/11a;

    invoke-static {v0}, LX/0yT;->A1Q(LX/0Y8;)V

    iget-object v0, p0, LX/12T;->A0m:LX/3QW;

    iget-object v4, p0, LX/12T;->A0h:LX/3QV;

    iget-object v3, p0, LX/12T;->A0b:LX/1bz;

    iget-object v6, p0, LX/12T;->A07:Ljava/lang/String;

    new-instance v1, LX/1Y5;

    move-object v5, p1

    invoke-direct/range {v1 .. v6}, LX/1Y5;-><init>(LX/12T;LX/1bz;LX/3QV;LX/1ZI;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, LX/3QW;->A0A(LX/1Ey;)V

    return-void
.end method

.method public final A0M(LX/36P;J)V
    .locals 3

    instance-of v0, p1, LX/1h3;

    if-eqz v0, :cond_0

    check-cast p1, LX/1h3;

    iget v1, p1, LX/1eo;->A00:I

    const/16 v0, 0x58

    if-ne v1, v0, :cond_1

    iget-wide v1, p1, LX/36P;->A0K:J

    cmp-long v0, v1, p2

    if-lez v0, :cond_1

    iget-object v0, p1, LX/1h3;->A03:Ljava/util/Set;

    :goto_0
    if-eqz v0, :cond_1

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {v2}, LX/0yR;->A0T(Ljava/util/Iterator;)LX/2py;

    move-result-object v0

    iget-object v1, p0, LX/12T;->A1C:Ljava/util/Set;

    iget-object v0, v0, LX/2py;->A02:Lcom/whatsapp/jid/GroupJid;

    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    instance-of v0, p1, LX/1hJ;

    if-eqz v0, :cond_1

    check-cast p1, LX/1hR;

    iget-wide v1, p1, LX/36P;->A0K:J

    cmp-long v0, v1, p2

    if-lez v0, :cond_1

    invoke-virtual {p1}, LX/1hR;->A1x()Ljava/util/HashSet;

    move-result-object v0

    goto :goto_0

    :cond_1
    return-void
.end method
