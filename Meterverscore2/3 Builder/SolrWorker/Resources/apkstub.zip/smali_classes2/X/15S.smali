.class public LX/15S;
.super LX/2uw;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LX/2uw;-><init>()V

    return-void
.end method

.method public constructor <init>(LX/6Yu;)V
    .locals 0

    invoke-direct {p0, p1}, LX/2uw;-><init>(LX/8lU;)V

    return-void
.end method
