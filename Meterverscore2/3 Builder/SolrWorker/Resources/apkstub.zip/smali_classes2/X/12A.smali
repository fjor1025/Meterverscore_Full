.class public final LX/12A;
.super LX/0V7;
.source ""


# instance fields
.field public A00:Lcom/whatsapp/jid/UserJid;

.field public A01:Lcom/whatsapp/jid/UserJid;

.field public A02:Ljava/util/List;

.field public final A03:LX/2O8;

.field public final A04:LX/2m5;

.field public final A05:LX/11a;

.field public final A06:LX/454;

.field public final A07:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(LX/2O8;Lcom/whatsapp/jid/UserJid;LX/2m5;LX/454;)V
    .locals 2

    const/4 v0, 0x3

    invoke-static {p4, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    invoke-direct {p0}, LX/0V7;-><init>()V

    iput-object p2, p0, LX/12A;->A00:Lcom/whatsapp/jid/UserJid;

    iput-object p3, p0, LX/12A;->A04:LX/2m5;

    iput-object p4, p0, LX/12A;->A06:LX/454;

    iput-object p1, p0, LX/12A;->A03:LX/2O8;

    const/4 v0, 0x0

    new-instance v1, LX/2zY;

    invoke-direct {v1, v0, v0, v0}, LX/2zY;-><init>(Landroid/graphics/Bitmap;Lcom/whatsapp/jid/UserJid;Ljava/util/List;)V

    new-instance v0, LX/11a;

    invoke-direct {v0, v1}, LX/11a;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LX/12A;->A05:LX/11a;

    const/16 v0, 0x1d

    new-instance v1, LX/3hT;

    invoke-direct {v1, p0, v0}, LX/3hT;-><init>(Ljava/lang/Object;I)V

    iput-object v1, p0, LX/12A;->A07:Ljava/lang/Runnable;

    iget-object v0, p0, LX/12A;->A06:LX/454;

    invoke-interface {v0, v1}, LX/454;->Biq(Ljava/lang/Runnable;)V

    return-void
.end method


# virtual methods
.method public A0F()V
    .locals 2

    iget-object v1, p0, LX/12A;->A06:LX/454;

    iget-object v0, p0, LX/12A;->A07:Ljava/lang/Runnable;

    invoke-interface {v1, v0}, LX/454;->Bhu(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final A0G(Lcom/whatsapp/jid/UserJid;)V
    .locals 2

    iget-object v0, p0, LX/12A;->A01:Lcom/whatsapp/jid/UserJid;

    invoke-static {p1, v0}, LX/7nJ;->A0a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iput-object p1, p0, LX/12A;->A01:Lcom/whatsapp/jid/UserJid;

    iget-object v1, p0, LX/12A;->A06:LX/454;

    iget-object v0, p0, LX/12A;->A07:Ljava/lang/Runnable;

    invoke-interface {v1, v0}, LX/454;->Bhu(Ljava/lang/Runnable;)V

    invoke-interface {v1, v0}, LX/454;->Biq(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method
