.class public final LX/10V;
.super Landroid/os/Handler;
.source ""

# interfaces
.implements LX/3xj;


# instance fields
.field public final synthetic A00:LX/10Z;


# direct methods
.method public constructor <init>(LX/10Z;)V
    .locals 1

    iput-object p1, p0, LX/10V;->A00:LX/10Z;

    invoke-virtual {p1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 2

    iget v1, p1, Landroid/os/Message;->what:I

    if-eqz v1, :cond_2

    const/4 v0, 0x1

    if-eq v1, v0, :cond_1

    const/4 v0, 0x2

    if-ne v1, v0, :cond_0

    iget-object v1, p0, LX/10V;->A00:LX/10Z;

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, LX/30N;

    invoke-static {v1, v0}, LX/10Z;->A0X(LX/10Z;LX/30N;)V

    :cond_0
    return-void

    :cond_1
    iget-object v1, p0, LX/10V;->A00:LX/10Z;

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, LX/31G;

    invoke-static {v1, v0}, LX/10Z;->A0Y(LX/10Z;LX/31G;)V

    return-void

    :cond_2
    const-string v0, "ConnectionThread/WriterThreadObserver/sending_channel_ready"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v1, p0, LX/10V;->A00:LX/10Z;

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, LX/43o;

    invoke-static {v1, v0}, LX/10Z;->A0W(LX/10Z;LX/43o;)V

    return-void
.end method
