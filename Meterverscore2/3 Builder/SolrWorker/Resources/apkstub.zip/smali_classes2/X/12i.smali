.class public LX/12i;
.super LX/09N;
.source ""


# static fields
.field public static final A02:LX/0Os;


# instance fields
.field public A00:LX/5Uu;

.field public final A01:LX/26e;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, LX/12f;

    invoke-direct {v0}, LX/12f;-><init>()V

    sput-object v0, LX/12i;->A02:LX/0Os;

    return-void
.end method

.method public constructor <init>(LX/26e;)V
    .locals 1

    sget-object v0, LX/12i;->A02:LX/0Os;

    invoke-direct {p0, v0}, LX/09N;-><init>(LX/0Os;)V

    iput-object p1, p0, LX/12i;->A01:LX/26e;

    return-void
.end method


# virtual methods
.method public BMT(LX/0Ve;I)V
    .locals 7

    invoke-virtual {p0}, LX/0S8;->A0B()I

    move-result v0

    if-lt p2, v0, :cond_0

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "UpcomingScheduledCallsAdapter/onBindViewHolder no item exists at position "

    :goto_0
    invoke-static {v0, v1, p2}, LX/0yK;->A0x(Ljava/lang/String;Ljava/lang/StringBuilder;I)V

    return-void

    :cond_0
    invoke-virtual {p0, p2}, LX/09N;->A0K(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LX/41v;

    if-nez v1, :cond_1

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "UpcomingScheduledCallsAdapter/onBindViewHolder null item at position "

    goto :goto_0

    :cond_1
    invoke-interface {v1}, LX/41v;->B7T()I

    move-result v0

    if-eqz v0, :cond_2

    check-cast p1, LX/12z;

    check-cast v1, LX/3IR;

    invoke-virtual {p1, v1}, LX/12z;->A08(LX/3IR;)V

    return-void

    :cond_2
    check-cast v1, LX/3IQ;

    iget-object v6, v1, LX/3IQ;->A00:LX/2jD;

    iget-object v5, p1, LX/0Ve;->A0H:Landroid/view/View;

    invoke-virtual {v5}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    const v3, 0x7f12214c

    invoke-static {}, LX/002;->A08()[Ljava/lang/Object;

    move-result-object v2

    const/4 v1, 0x0

    iget-object v0, v6, LX/2jD;->A01:Ljava/lang/String;

    aput-object v0, v2, v1

    const/4 v1, 0x1

    iget-object v0, v6, LX/2jD;->A00:Ljava/lang/String;

    invoke-static {v4, v0, v2, v1, v3}, LX/0yP;->A0Z(Landroid/content/Context;Ljava/lang/Object;[Ljava/lang/Object;II)Ljava/lang/String;

    move-result-object v1

    const v0, 0x7f0b1b26

    invoke-static {v5, v0}, LX/0yQ;->A0O(Landroid/view/View;I)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public BPF(Landroid/view/ViewGroup;I)LX/0Ve;
    .locals 21

    move-object/from16 v4, p1

    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, LX/38Z;->A07(Ljava/lang/Object;)V

    const/4 v2, 0x0

    move/from16 v3, p2

    if-eqz p2, :cond_1

    const/4 v0, 0x1

    if-ne v3, v0, :cond_0

    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const v0, 0x7f0e08da

    invoke-virtual {v1, v0, v4, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v3

    move-object/from16 v0, p0

    iget-object v1, v0, LX/12i;->A01:LX/26e;

    iget-object v8, v0, LX/12i;->A00:LX/5Uu;

    const-string v0, "UpcomingScheduledCallsAdapter/onCreateViewHolder single contact photo loader null"

    invoke-static {v8, v0}, LX/38Z;->A08(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v1, LX/26e;->A00:LX/5qP;

    iget-object v0, v0, LX/5qP;->A03:LX/3GZ;

    invoke-static {v0}, LX/3GZ;->A2l(LX/3GZ;)LX/2sJ;

    move-result-object v9

    invoke-static {v0}, LX/3GZ;->A44(LX/3GZ;)LX/1Pl;

    move-result-object v16

    invoke-static {v0}, LX/3GZ;->A03(LX/3GZ;)LX/3by;

    move-result-object v4

    invoke-static {v0}, LX/3GZ;->A04(LX/3GZ;)LX/2sr;

    move-result-object v5

    invoke-static {v0}, LX/3GZ;->A8i(LX/3GZ;)LX/454;

    move-result-object v19

    iget-object v1, v0, LX/3GZ;->A4P:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LX/6Dk;

    iget-object v1, v0, LX/3GZ;->AZt:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    iget-object v1, v0, LX/3GZ;->AbE:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    iget-object v1, v0, LX/3GZ;->A8d:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, LX/30u;

    invoke-static {v0}, LX/3GZ;->A85(LX/3GZ;)LX/2pv;

    move-result-object v18

    iget-object v1, v0, LX/3GZ;->A4Q:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, LX/2sa;

    iget-object v1, v0, LX/3GZ;->ABC:LX/41P;

    invoke-interface {v1}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LX/36j;

    iget-object v2, v0, LX/3GZ;->AU1:LX/41P;

    invoke-interface {v2}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, LX/2q7;

    iget-object v2, v0, LX/3GZ;->AIE:LX/41P;

    invoke-interface {v2}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, LX/2rl;

    invoke-static {v0}, LX/3GZ;->A3B(LX/3GZ;)LX/3Qa;

    move-result-object v11

    iget-object v2, v0, LX/3GZ;->AKS:LX/41P;

    invoke-interface {v2}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, LX/2i0;

    iget-object v2, v0, LX/3GZ;->A7y:LX/41P;

    invoke-static {v2}, LX/3jM;->A00(LX/41P;)LX/8oO;

    move-result-object v20

    iget-object v0, v0, LX/3GZ;->AE9:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LX/69Q;

    new-instance v2, LX/12z;

    move-object/from16 v17, v1

    invoke-direct/range {v2 .. v20}, LX/12z;-><init>(Landroid/view/View;LX/3by;LX/2sr;LX/69Q;LX/6Dk;LX/5Uu;LX/2sJ;LX/2sa;LX/3Qa;LX/30u;LX/2rl;LX/2q7;LX/2i0;LX/1Pl;LX/36j;LX/2pv;LX/454;LX/8oO;)V

    return-object v2

    :cond_0
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "UpcomingScheduledCallsAdapter/onCreateViewHolder failed to match type to view: "

    invoke-static {v0, v1, v3}, LX/0yK;->A0v(Ljava/lang/String;Ljava/lang/StringBuilder;I)V

    const-string v0, "UpcomingScheduledCallsAdapter/onCreateViewHolder type mismatch"

    invoke-static {v0}, LX/001;->A0g(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v0

    throw v0

    :cond_1
    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const v0, 0x7f0e08db

    invoke-virtual {v1, v0, v4, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/view/View;->setEnabled(Z)V

    new-instance v2, LX/12q;

    invoke-direct {v2, v0}, LX/12q;-><init>(Landroid/view/View;)V

    return-object v2
.end method

.method public getItemViewType(I)I
    .locals 1

    invoke-virtual {p0, p1}, LX/09N;->A0K(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/41v;

    invoke-interface {v0}, LX/41v;->B7T()I

    move-result v0

    return v0
.end method
