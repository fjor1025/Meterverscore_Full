.class public LX/0zz;
.super Landroid/os/CountDownTimer;
.source ""


# instance fields
.field public final synthetic A00:Lcom/gbwhatsapp/registration/RegisterPhone;


# direct methods
.method public constructor <init>(Lcom/gbwhatsapp/registration/RegisterPhone;)V
    .locals 2

    const-wide/16 v0, 0xc8

    iput-object p1, p0, LX/0zz;->A00:Lcom/gbwhatsapp/registration/RegisterPhone;

    invoke-direct {p0, v0, v1, v0, v1}, Landroid/os/CountDownTimer;-><init>(JJ)V

    return-void
.end method


# virtual methods
.method public onFinish()V
    .locals 18

    move-object/from16 v17, p0

    move-object/from16 v0, v17

    iget-object v3, v0, LX/0zz;->A00:Lcom/gbwhatsapp/registration/RegisterPhone;

    iget-object v0, v3, LX/1ib;->A0I:LX/5Lp;

    iget-object v0, v0, LX/5Lp;->A02:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-static {v0}, LX/0yL;->A0U(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    iget-object v0, v3, LX/1ib;->A0I:LX/5Lp;

    iget-object v0, v0, LX/5Lp;->A03:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-static {v0}, LX/0yL;->A0U(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    if-eqz v8, :cond_6

    if-eqz v11, :cond_6

    const-string v10, ""

    invoke-virtual {v8, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    iget-object v1, v3, LX/1ib;->A03:LX/315;

    iget-object v0, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A0Z:Ljava/lang/String;

    invoke-static {v1, v11, v8, v0}, LX/38g;->A0A(LX/315;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_6

    iget-object v0, v3, LX/1ib;->A03:LX/315;

    invoke-static {v0, v8, v1}, LX/38g;->A09(LX/315;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v0

    if-lt v2, v0, :cond_6

    const v6, 0x7f121a8d

    const/4 v5, 0x1

    new-array v2, v5, [Ljava/lang/Object;

    iget-object v0, v3, LX/1GJ;->A00:LX/34x;

    invoke-virtual {v0, v4}, LX/34x;->A0J(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    invoke-static {v3, v0, v2, v4, v6}, LX/0yP;->A0Z(Landroid/content/Context;Ljava/lang/Object;[Ljava/lang/Object;II)Ljava/lang/String;

    move-result-object v12

    iget-object v0, v3, LX/1ib;->A03:LX/315;

    invoke-static {v0, v8, v11}, LX/37i;->A02(LX/315;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v8, v1}, LX/0yQ;->A0v(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v9, "\\D"

    invoke-virtual {v0, v9, v10}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v2, v9, v10}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/String;->length()I

    move-result v6

    invoke-virtual {v13}, Ljava/lang/String;->length()I

    move-result v0

    invoke-static {v6, v0}, LX/001;->A0C(II)I

    move-result v14

    if-ne v14, v5, :cond_1

    if-le v6, v0, :cond_1

    :goto_0
    const/4 v7, -0x1

    :cond_0
    iget-boolean v0, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A0e:Z

    if-eqz v0, :cond_7

    iget v0, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A01:I

    if-ne v0, v7, :cond_7

    return-void

    :cond_1
    const/4 v2, 0x0

    const/4 v7, 0x0

    :goto_1
    if-lt v2, v6, :cond_2

    if-nez v14, :cond_4

    goto :goto_0

    :cond_2
    :goto_2
    :try_start_0
    invoke-virtual {v12, v7}, Ljava/lang/String;->charAt(I)C

    move-result v15

    invoke-virtual {v13, v2}, Ljava/lang/String;->charAt(I)C

    move-result v0

    if-eq v15, v0, :cond_3

    add-int/lit8 v7, v7, 0x1

    goto :goto_2

    :cond_3
    move-object/from16 v0, v16

    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v15

    invoke-virtual {v13, v2}, Ljava/lang/String;->charAt(I)C

    move-result v0

    if-ne v15, v0, :cond_5

    add-int/lit8 v7, v7, 0x1

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_4
    :goto_3
    invoke-virtual {v12, v7}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-virtual {v13, v6}, Ljava/lang/String;->charAt(I)C

    move-result v0

    if-eq v2, v0, :cond_5

    add-int/lit8 v7, v7, 0x1

    goto :goto_3
    :try_end_0
    .catch Ljava/lang/StringIndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception v1

    const-string v0, "RegistrationUtils/getIndexOfDifference/skip"

    invoke-static {v0, v1}, Lcom/whatsapp/util/Log;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_4

    :cond_5
    const/4 v0, -0x2

    if-ne v7, v0, :cond_0

    :cond_6
    :goto_4
    invoke-virtual {v3}, Lcom/gbwhatsapp/registration/RegisterPhone;->A6K()V

    return-void

    :cond_7
    iput v7, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A01:I

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v13

    add-int/lit8 v0, v13, -0x2

    if-ne v7, v0, :cond_b

    sput-boolean v5, Lcom/gbwhatsapp/registration/RegisterPhone;->A0n:Z

    :goto_5
    iget-object v2, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A08:Landroid/widget/ScrollView;

    iget-object v0, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A09:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v0

    invoke-virtual {v2, v4, v0}, Landroid/view/View;->scrollTo(II)V

    new-instance v6, Landroid/text/SpannableString;

    invoke-direct {v6, v12}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    new-instance v2, LX/4Bh;

    move-object/from16 v0, v17

    invoke-direct {v2, v0, v8, v1}, LX/4Bh;-><init>(LX/0zz;Ljava/lang/String;Ljava/lang/String;)V

    const/16 v12, 0x11

    invoke-virtual {v6, v2, v4, v13, v12}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    iget-object v2, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A09:Landroid/widget/TextView;

    invoke-static {}, Landroid/text/method/LinkMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    const/4 v0, -0x1

    if-eq v7, v0, :cond_8

    const/high16 v0, -0x10000

    new-instance v2, Landroid/text/style/ForegroundColorSpan;

    invoke-direct {v2, v0}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    add-int/lit8 v0, v7, 0x1

    invoke-virtual {v6, v2, v7, v0, v12}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    :cond_8
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v9, v10}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v11, v9, v10}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "RegisterPhone/suggested/cc/"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " pn="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " suggest="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " s="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A0Z:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " disp="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " same="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v8}, LX/000;->A0j(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v0, v3, LX/1ib;->A03:LX/315;

    invoke-static {v0, v8, v9}, LX/37i;->A02(LX/315;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v2, v0}, LX/0yK;->A1U(Ljava/lang/StringBuilder;Z)V

    iput-boolean v5, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A0g:Z

    iget v2, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A00:I

    const/16 v1, 0x1f

    if-ne v2, v1, :cond_a

    const/16 v1, 0x20

    :goto_6
    iput v1, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A00:I

    :cond_9
    iget-object v1, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A09:Landroid/widget/TextView;

    sget-object v0, Landroid/widget/TextView$BufferType;->SPANNABLE:Landroid/widget/TextView$BufferType;

    invoke-virtual {v1, v6, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;Landroid/widget/TextView$BufferType;)V

    invoke-static {}, LX/0yR;->A0N()Landroid/view/animation/AlphaAnimation;

    move-result-object v2

    const-wide/16 v0, 0x96

    invoke-virtual {v2, v0, v1}, Landroid/view/animation/Animation;->setDuration(J)V

    iget-object v0, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A09:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    iget-object v0, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A09:Landroid/widget/TextView;

    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    iput-boolean v5, v3, Lcom/gbwhatsapp/registration/RegisterPhone;->A0e:Z

    return-void

    :cond_a
    const/16 v0, 0x1e

    if-ne v2, v0, :cond_9

    goto :goto_6

    :cond_b
    sput-boolean v5, Lcom/gbwhatsapp/registration/RegisterPhone;->A0o:Z

    goto/16 :goto_5
.end method

.method public onTick(J)V
    .locals 0

    return-void
.end method
