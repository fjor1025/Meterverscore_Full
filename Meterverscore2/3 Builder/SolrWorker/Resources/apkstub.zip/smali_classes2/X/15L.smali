.class public LX/15L;
.super LX/30n;
.source ""


# instance fields
.field public final synthetic A00:LX/30f;


# direct methods
.method public constructor <init>(LX/30f;LX/7SB;Ljava/util/Map;)V
    .locals 0

    iput-object p1, p0, LX/15L;->A00:LX/30f;

    invoke-direct {p0, p2, p3}, LX/30n;-><init>(LX/7SB;Ljava/util/Map;)V

    return-void
.end method
