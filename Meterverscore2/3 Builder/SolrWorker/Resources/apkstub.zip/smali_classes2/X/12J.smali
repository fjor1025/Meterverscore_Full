.class public LX/12J;
.super LX/0V7;
.source ""


# instance fields
.field public A00:LX/1nB;

.field public final A01:LX/0Y8;

.field public final A02:LX/0Y8;

.field public final A03:LX/0Y8;

.field public final A04:LX/0Y8;

.field public final A05:LX/0Y8;

.field public final A06:LX/0Y8;

.field public final A07:LX/0Y8;

.field public final A08:LX/08S;

.field public final A09:LX/08S;

.field public final A0A:LX/08S;

.field public final A0B:LX/08S;

.field public final A0C:LX/08S;

.field public final A0D:LX/08S;

.field public final A0E:LX/08S;

.field public final A0F:LX/26f;

.field public final A0G:LX/1ZJ;

.field public final A0H:LX/454;


# direct methods
.method public constructor <init>(LX/26f;LX/1ZJ;LX/454;)V
    .locals 1

    invoke-direct {p0}, LX/0V7;-><init>()V

    iput-object p3, p0, LX/12J;->A0H:LX/454;

    iput-object p2, p0, LX/12J;->A0G:LX/1ZJ;

    iput-object p1, p0, LX/12J;->A0F:LX/26f;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/12J;->A09:LX/08S;

    iput-object v0, p0, LX/12J;->A02:LX/0Y8;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/12J;->A0C:LX/08S;

    iput-object v0, p0, LX/12J;->A05:LX/0Y8;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/12J;->A0E:LX/08S;

    iput-object v0, p0, LX/12J;->A07:LX/0Y8;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/12J;->A0A:LX/08S;

    iput-object v0, p0, LX/12J;->A03:LX/0Y8;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/12J;->A0D:LX/08S;

    iput-object v0, p0, LX/12J;->A06:LX/0Y8;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/12J;->A0B:LX/08S;

    iput-object v0, p0, LX/12J;->A04:LX/0Y8;

    invoke-static {}, LX/0yT;->A0J()LX/08S;

    move-result-object v0

    iput-object v0, p0, LX/12J;->A08:LX/08S;

    iput-object v0, p0, LX/12J;->A01:LX/0Y8;

    return-void
.end method


# virtual methods
.method public final A0G()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12J;->A02:LX/0Y8;

    return-object v0
.end method

.method public final A0H()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12J;->A04:LX/0Y8;

    return-object v0
.end method

.method public final A0I()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12J;->A05:LX/0Y8;

    return-object v0
.end method

.method public final A0J()LX/0Y8;
    .locals 1

    iget-object v0, p0, LX/12J;->A07:LX/0Y8;

    return-object v0
.end method

.method public A0K()V
    .locals 8

    move-object v2, p0

    invoke-virtual {p0}, LX/12J;->A0L()V

    iget-object v0, p0, LX/12J;->A0F:LX/26f;

    iget-object v7, p0, LX/12J;->A0G:LX/1ZJ;

    iget-object v0, v0, LX/26f;->A00:LX/5qP;

    iget-object v1, v0, LX/5qP;->A03:LX/3GZ;

    invoke-static {v1}, LX/3GZ;->A2s(LX/3GZ;)LX/34x;

    move-result-object v3

    iget-object v0, v1, LX/3GZ;->AIo:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LX/2yp;

    iget-object v0, v1, LX/3GZ;->AJf:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LX/31u;

    iget-object v0, v1, LX/3GZ;->A00:LX/38w;

    iget-object v0, v0, LX/38w;->A3l:LX/41P;

    invoke-interface {v0}, LX/41P;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LX/2WL;

    new-instance v1, LX/1nB;

    invoke-direct/range {v1 .. v7}, LX/1nB;-><init>(LX/12J;LX/34x;LX/2WL;LX/2yp;LX/31u;LX/1ZJ;)V

    iget-object v0, p0, LX/12J;->A0H:LX/454;

    invoke-static {v1, v0}, LX/0yL;->A10(LX/7jt;LX/454;)V

    iput-object v1, p0, LX/12J;->A00:LX/1nB;

    return-void
.end method

.method public final A0L()V
    .locals 2

    iget-object v1, p0, LX/12J;->A00:LX/1nB;

    if-eqz v1, :cond_0

    const/4 v0, 0x1

    invoke-virtual {v1, v0}, LX/7jt;->A06(Z)V

    const/4 v0, 0x0

    iput-object v0, p0, LX/12J;->A00:LX/1nB;

    :cond_0
    return-void
.end method
