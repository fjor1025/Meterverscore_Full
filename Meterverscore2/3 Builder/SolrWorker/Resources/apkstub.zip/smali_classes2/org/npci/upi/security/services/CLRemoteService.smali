.class public interface abstract Lorg/npci/upi/security/services/CLRemoteService;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract B1c(Ljava/lang/String;)V
.end method

.method public abstract B43(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
.end method

.method public abstract B4w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/npci/upi/security/services/CLResultReceiver;)V
.end method

.method public abstract Bh8(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
.end method
