.class public interface abstract Lorg/npci/upi/security/services/CLResultReceiver;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract B29(Landroid/os/Bundle;)V
.end method

.method public abstract Bjn(Landroid/os/Bundle;)V
.end method

.method public abstract BpV(Landroid/os/Bundle;)V
.end method

.method public abstract BpW(Landroid/os/Bundle;)V
.end method
