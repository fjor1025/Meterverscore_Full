.class public abstract Lorg/whispersystems/jobqueue/Job;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public transient A00:I

.field public transient A01:J

.field public transient A02:Landroid/os/PowerManager$WakeLock;

.field public final parameters:Lorg/whispersystems/jobqueue/JobParameters;


# direct methods
.method public constructor <init>(Lorg/whispersystems/jobqueue/JobParameters;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/whispersystems/jobqueue/Job;->parameters:Lorg/whispersystems/jobqueue/JobParameters;

    return-void
.end method


# virtual methods
.method public A02(J)V
    .locals 3

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;

    if-eqz v0, :cond_0

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;

    iput-wide p1, v2, Lorg/whispersystems/jobqueue/Job;->A01:J

    sput-wide p1, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A01:J

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v0, "set persistent id for send status privacy job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_0
    iput-wide p1, p0, Lorg/whispersystems/jobqueue/Job;->A01:J

    return-void
.end method

.method public A03()Z
    .locals 7

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;

    if-eqz v0, :cond_3

    move-object v4, p0

    check-cast v4, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;

    iget-object v0, v4, Lorg/whispersystems/jobqueue/Job;->parameters:Lorg/whispersystems/jobqueue/JobParameters;

    iget-object v0, v0, Lorg/whispersystems/jobqueue/JobParameters;->requirements:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x1

    if-eqz v0, :cond_a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/whispersystems/jobqueue/requirements/Requirement;

    invoke-interface {v2}, Lorg/whispersystems/jobqueue/requirements/Requirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncDeviceAndResendMessageJob/isRequirementsMet/req "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " not present: "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1G(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    instance-of v0, v2, Lcom/gbwhatsapp/jobqueue/requirement/ChatConnectionRequirement;

    if-eqz v0, :cond_2

    iput v3, v4, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;->A00:I

    iput-boolean v3, v4, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;->A0L:Z

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return v0

    :cond_2
    const/4 v0, 0x2

    iput v0, v4, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;->A00:I

    goto :goto_0

    :cond_3
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;

    if-eqz v0, :cond_8

    move-object v4, p0

    check-cast v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;

    iget-object v0, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0I:LX/2sJ;

    invoke-virtual {v0}, LX/2sJ;->A0H()J

    move-result-wide v5

    iget-wide v1, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->expireTimeMs:J

    cmp-long v0, v5, v1

    invoke-static {v0}, LX/001;->A1U(I)Z

    move-result v0

    const/4 v3, 0x1

    if-nez v0, :cond_a

    iget-object v0, v4, Lorg/whispersystems/jobqueue/Job;->parameters:Lorg/whispersystems/jobqueue/JobParameters;

    iget-object v0, v0, Lorg/whispersystems/jobqueue/JobParameters;->requirements:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_4
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/whispersystems/jobqueue/requirements/Requirement;

    iget-object v0, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0i:LX/2Kp;

    if-eqz v0, :cond_7

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;

    if-nez v0, :cond_5

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;

    if-nez v0, :cond_5

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlMultiDeviceSessionRequirement;

    if-eqz v0, :cond_7

    :cond_5
    iget-boolean v0, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A14:Z

    if-nez v0, :cond_4

    iget-boolean v0, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A16:Z

    if-nez v0, :cond_4

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;

    if-nez v0, :cond_6

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;

    if-nez v0, :cond_6

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlMultiDeviceSessionRequirement;

    if-eqz v0, :cond_4

    :cond_6
    iput-boolean v3, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A16:Z

    iget-object v2, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0I:LX/2sJ;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A03:J

    invoke-virtual {v2}, LX/2sJ;->A0H()J

    move-result-wide v0

    iput-wide v0, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A02:J

    goto :goto_1

    :cond_7
    invoke-interface {v1}, Lorg/whispersystems/jobqueue/requirements/Requirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_5

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/ChatConnectionRequirement;

    if-eqz v0, :cond_1

    iput-boolean v3, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A18:Z

    goto :goto_0

    :cond_8
    iget-object v0, p0, Lorg/whispersystems/jobqueue/Job;->parameters:Lorg/whispersystems/jobqueue/JobParameters;

    iget-object v0, v0, Lorg/whispersystems/jobqueue/JobParameters;->requirements:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/whispersystems/jobqueue/requirements/Requirement;

    invoke-interface {v0}, Lorg/whispersystems/jobqueue/requirements/Requirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_9

    goto/16 :goto_0

    :cond_a
    const/4 v0, 0x1

    return v0
.end method

.method public A04()V
    .locals 15

    move-object v2, p0

    instance-of v0, p0, LX/3we;

    if-nez v0, :cond_0

    instance-of v0, p0, LX/3wl;

    if-eqz v0, :cond_1

    check-cast v2, LX/3wl;

    invoke-virtual {v2}, LX/3wl;->A08()Ljava/lang/String;

    :cond_0
    return-void

    :cond_1
    instance-of v0, p0, LX/3xE;

    if-nez v0, :cond_0

    instance-of v0, p0, LX/1bD;

    if-eqz v0, :cond_3

    check-cast v2, LX/1bD;

    const-string v0, "NewsletterSubscribersGraphqlJob/onAdded"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v0, v2, LX/1bD;->A02:LX/2g9;

    if-nez v0, :cond_2

    const-string v0, "graphqlClient"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_2
    iget-object v0, v0, LX/2g9;->A03:LX/34u;

    invoke-virtual {v0}, LX/34u;->A0J()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, v2, LX/1bD;->callback:LX/401;

    if-eqz v0, :cond_0

    new-instance v0, LX/6rK;

    invoke-direct {v0}, LX/6rK;-><init>()V

    return-void

    :cond_3
    instance-of v0, p0, LX/1bA;

    if-eqz v0, :cond_4

    const-string v0, "GetNewsletterMyAddOnsMessagesJob/onAdded"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    return-void

    :cond_4
    instance-of v0, p0, LX/1bB;

    if-eqz v0, :cond_5

    const-string v0, "GetNewsletterMessagesUpdatesJob/onAdded"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    return-void

    :cond_5
    instance-of v0, p0, LX/1bC;

    if-eqz v0, :cond_6

    const-string v0, "GetNewsletterMessagesJob/onAdded"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    return-void

    :cond_6
    instance-of v0, p0, LX/3wg;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;

    if-eqz v0, :cond_7

    const-string v0, "SyncdTableEmptyKeyCheckJob/onadded"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    return-void

    :cond_7
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;

    if-eqz v0, :cond_8

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncProfilePictureJob/onAdded/sync profile picture job added param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_8
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;

    if-eqz v0, :cond_9

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncDevicesJob/onAdded/sync devices job added param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_9
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;

    if-eqz v0, :cond_a

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncDevicesAndSendInvisibleMessageJob/onAdded/sync devices job added param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_a
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;

    if-eqz v0, :cond_b

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v0, "SyncDeviceForAdvValidationJob/onAdded/sync devices job added param="

    invoke-static {v0, v3}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "; jids="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;->jids:[Ljava/lang/String;

    invoke-static {v0}, LX/38f;->A07([Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_b
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;

    if-eqz v0, :cond_c

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncDeviceAndResendMessageJob/onAdded/sync devices job added param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_c
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;

    if-eqz v0, :cond_d

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->A08()Ljava/lang/String;

    return-void

    :cond_d
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;

    if-eqz v0, :cond_e

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->A08()Ljava/lang/String;

    return-void

    :cond_e
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;

    if-eqz v0, :cond_12

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v0, "SendPeerMessageJob/onAdded/job added="

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v0, "; peer_msg_row_id="

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;->peerMessageRowId:J

    invoke-static {v3, v0, v1}, LX/001;->A0o(Ljava/lang/StringBuilder;J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v0, v2, Lorg/whispersystems/jobqueue/Job;->parameters:Lorg/whispersystems/jobqueue/JobParameters;

    iget-object v0, v0, Lorg/whispersystems/jobqueue/JobParameters;->requirements:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_f
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/whispersystems/jobqueue/requirements/Requirement;

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlPeerDeviceSessionRequirement;

    if-eqz v0, :cond_11

    check-cast v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlPeerDeviceSessionRequirement;

    iget-object v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlPeerDeviceSessionRequirement;->targetJidRawString:Ljava/lang/String;

    invoke-static {v0}, Lcom/whatsapp/jid/DeviceJid;->getNullable(Ljava/lang/String;)Lcom/whatsapp/jid/DeviceJid;

    move-result-object v3

    invoke-static {v3}, LX/38Z;->A07(Ljava/lang/Object;)V

    iget-object v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlPeerDeviceSessionRequirement;->A01:LX/31v;

    invoke-virtual {v0}, LX/31v;->A04()LX/6fe;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_10

    iget-object v1, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlPeerDeviceSessionRequirement;->A00:LX/351;

    invoke-static {v3}, LX/37y;->A02(Lcom/whatsapp/jid/DeviceJid;)LX/2oX;

    move-result-object v0

    invoke-virtual {v1, v0}, LX/351;->A0Z(LX/2oX;)Z

    move-result v0

    if-nez v0, :cond_10

    invoke-static {v3}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_f

    sget-object v0, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;->A0E:[Lcom/whatsapp/jid/DeviceJid;

    invoke-interface {v1, v0}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Lcom/whatsapp/jid/DeviceJid;

    iget-object v3, v2, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;->A01:LX/2qG;

    const/4 v1, 0x0

    const/4 v0, 0x5

    invoke-virtual {v3, v4, v0, v1}, LX/2qG;->A04([Lcom/whatsapp/jid/DeviceJid;IZ)V

    goto :goto_0

    :cond_10
    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v1

    goto :goto_1

    :cond_11
    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;

    if-eqz v0, :cond_f

    check-cast v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;

    invoke-virtual {v1}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_f

    iget-object v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;->A01:Lcom/whatsapp/jid/DeviceJid;

    invoke-static {v0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    goto :goto_1

    :cond_12
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendLiveLocationKeyJob;

    if-eqz v0, :cond_15

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendLiveLocationKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v0, "live location key notification send job added"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendLiveLocationKeyJob;->A09()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    invoke-static {}, LX/001;->A0z()Ljava/util/HashSet;

    move-result-object v4

    iget-object v0, v2, Lorg/whispersystems/jobqueue/Job;->parameters:Lorg/whispersystems/jobqueue/JobParameters;

    iget-object v0, v0, Lorg/whispersystems/jobqueue/JobParameters;->requirements:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_13
    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_32

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/whispersystems/jobqueue/requirements/Requirement;

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;

    if-eqz v0, :cond_14

    check-cast v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;

    invoke-virtual {v1}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_13

    iget-object v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;->A01:Lcom/whatsapp/jid/DeviceJid;

    :goto_3
    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_14
    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;

    if-eqz v0, :cond_13

    check-cast v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;

    invoke-virtual {v1}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_13

    iget-object v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;->A01:Lcom/whatsapp/jid/DeviceJid;

    goto :goto_3

    :cond_15
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;

    if-eqz v0, :cond_19

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;

    iget-object v0, v2, Lorg/whispersystems/jobqueue/Job;->parameters:Lorg/whispersystems/jobqueue/JobParameters;

    iget-object v3, v0, Lorg/whispersystems/jobqueue/JobParameters;->requirements:Ljava/util/List;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->rawDeviceJid:Ljava/lang/String;

    invoke-static {v0}, Lcom/whatsapp/jid/DeviceJid;->getNullable(Ljava/lang/String;)Lcom/whatsapp/jid/DeviceJid;

    move-result-object v7

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "final live location notification send retry job added"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    const/4 v5, 0x0

    const/4 v4, 0x0

    :cond_16
    :goto_4
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lorg/whispersystems/jobqueue/requirements/Requirement;

    instance-of v0, v3, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;

    const/4 v1, 0x1

    if-eqz v0, :cond_17

    check-cast v3, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;->BHE()Z

    move-result v0

    :goto_5
    if-nez v0, :cond_18

    const/4 v4, 0x1

    :goto_6
    iget-object v3, v2, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A01:LX/2qG;

    new-array v1, v1, [Lcom/whatsapp/jid/DeviceJid;

    aput-object v7, v1, v5

    const/4 v0, 0x3

    invoke-virtual {v3, v1, v0, v5}, LX/2qG;->A04([Lcom/whatsapp/jid/DeviceJid;IZ)V

    goto :goto_4

    :cond_17
    instance-of v0, v3, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;

    if-eqz v0, :cond_18

    check-cast v3, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;->BHE()Z

    move-result v0

    goto :goto_5

    :cond_18
    if-eqz v4, :cond_16

    goto :goto_6

    :cond_19
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;

    if-eqz v0, :cond_1b

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;

    iget-object v0, v2, Lorg/whispersystems/jobqueue/Job;->parameters:Lorg/whispersystems/jobqueue/JobParameters;

    iget-object v3, v0, Lorg/whispersystems/jobqueue/JobParameters;->requirements:Ljava/util/List;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "final live location notification send job added"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A09()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1a
    :goto_7
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/whispersystems/jobqueue/requirements/Requirement;

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlFastRatchetSenderKeyRequirement;

    if-eqz v0, :cond_1a

    check-cast v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlFastRatchetSenderKeyRequirement;

    invoke-virtual {v1}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlFastRatchetSenderKeyRequirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_1a

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A04:LX/353;

    invoke-virtual {v0}, LX/353;->A0c()Z

    goto :goto_7

    :cond_1b
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;

    if-eqz v0, :cond_2b

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendE2EMessageJob/e2e message send job added"

    invoke-static {v2, v0, v1}, LX/0yT;->A12(Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-boolean v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->duplicate:Z

    if-eqz v0, :cond_1c

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendE2EMessageJob/e2e messasge job is duplicate, skipping requirement check"

    invoke-static {v2, v0, v1}, LX/0yT;->A12(Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_1c
    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0C()Z

    move-result v0

    const/4 v4, 0x1

    if-eqz v0, :cond_28

    const/16 v11, 0xb

    :cond_1d
    :goto_8
    iput-boolean v4, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A16:Z

    iget-object v0, v2, Lorg/whispersystems/jobqueue/Job;->parameters:Lorg/whispersystems/jobqueue/JobParameters;

    iget-object v0, v0, Lorg/whispersystems/jobqueue/JobParameters;->requirements:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    const/4 v3, 0x0

    :cond_1e
    :goto_9
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v14, 0x0

    if-eqz v0, :cond_29

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lorg/whispersystems/jobqueue/requirements/Requirement;

    instance-of v0, v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;

    if-eqz v0, :cond_1f

    check-cast v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;

    invoke-virtual {v5}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_1e

    iget-object v3, v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;->A01:Lcom/whatsapp/jid/DeviceJid;

    goto :goto_9

    :cond_1f
    instance-of v0, v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;

    if-eqz v0, :cond_20

    check-cast v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;

    invoke-virtual {v5}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_1e

    iget-object v3, v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlDifferentAliceBaseKeyRequirement;->A01:Lcom/whatsapp/jid/DeviceJid;

    goto :goto_9

    :cond_20
    instance-of v0, v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlMultiDeviceSessionRequirement;

    if-eqz v0, :cond_24

    check-cast v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlMultiDeviceSessionRequirement;

    invoke-virtual {v5}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlMultiDeviceSessionRequirement;->A00()Ljava/util/List;

    move-result-object v0

    if-nez v0, :cond_23

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v7

    :cond_21
    invoke-interface {v7}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1e

    new-array v0, v14, [Lcom/whatsapp/jid/DeviceJid;

    invoke-interface {v7, v0}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v10

    check-cast v10, [Lcom/whatsapp/jid/DeviceJid;

    iput-boolean v4, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A15:Z

    iput-boolean v14, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A16:Z

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A04:J

    invoke-interface {v7}, Ljava/util/Collection;->size()I

    move-result v6

    iput v6, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A01:I

    iget-object v9, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0F:LX/2qG;

    instance-of v1, v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlMultiDeviceSenderKeyRequirement;

    iget-object v0, v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlMultiDeviceSessionRequirement;->A04:LX/1ZJ;

    if-eqz v1, :cond_22

    invoke-static {v0}, LX/2tX;->A00(Lcom/whatsapp/jid/Jid;)LX/1Z5;

    move-result-object v0

    :cond_22
    invoke-static {v0}, LX/384;->A04(Lcom/whatsapp/jid/Jid;)I

    move-result v12

    invoke-static {v6}, LX/384;->A00(I)I

    move-result v13

    invoke-virtual/range {v9 .. v14}, LX/2qG;->A03([Lcom/whatsapp/jid/DeviceJid;IIIZ)V

    goto :goto_9

    :cond_23
    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_a
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_21

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iget-object v0, v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlMultiDeviceSessionRequirement;->A01:LX/351;

    invoke-virtual {v0, v1}, LX/351;->A0H(Ljava/util/List;)Ljava/util/Set;

    move-result-object v0

    invoke-static {v0}, LX/37y;->A05(Ljava/util/Collection;)Ljava/util/List;

    move-result-object v0

    invoke-virtual {v7, v0}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    goto :goto_a

    :cond_24
    instance-of v0, v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlFastRatchetSenderKeyRequirement;

    if-eqz v0, :cond_25

    check-cast v5, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlFastRatchetSenderKeyRequirement;

    invoke-virtual {v5}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlFastRatchetSenderKeyRequirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_1e

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0k:LX/353;

    invoke-virtual {v0}, LX/353;->A0c()Z

    goto/16 :goto_9

    :cond_25
    instance-of v0, v5, Lcom/gbwhatsapp/jobqueue/requirement/ChatConnectionRequirement;

    if-eqz v0, :cond_27

    check-cast v5, Lcom/gbwhatsapp/jobqueue/requirement/ChatConnectionRequirement;

    iget-object v0, v5, Lcom/gbwhatsapp/jobqueue/requirement/ChatConnectionRequirement;->A00:LX/1cv;

    iget v1, v0, LX/1cv;->A04:I

    const/4 v0, 0x2

    invoke-static {v1, v0}, LX/000;->A1U(II)Z

    move-result v0

    if-nez v0, :cond_1e

    iput-boolean v4, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A18:Z

    iget v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->retryCount:I

    if-nez v0, :cond_1e

    iget-object v5, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0v:LX/2Yp;

    const-string v0, "Scheduling job for unsent messages"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v1, v5, LX/2Yp;->A00:LX/34w;

    iget-object v6, v1, LX/34w;->A05:Landroid/app/job/JobScheduler;

    if-nez v6, :cond_26

    const-string v0, "jobscheduler"

    invoke-virtual {v1, v0, v4}, LX/34w;->A0R(Ljava/lang/String;Z)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/app/job/JobScheduler;

    iput-object v6, v1, LX/34w;->A05:Landroid/app/job/JobScheduler;

    :cond_26
    iget-object v0, v5, LX/2Yp;->A01:LX/2iX;

    iget-object v1, v0, LX/2iX;->A00:Landroid/content/Context;

    const-class v0, Lcom/gbwhatsapp/service/UnsentMessagesNetworkAvailableJob;

    new-instance v5, Landroid/content/ComponentName;

    invoke-direct {v5, v1, v0}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v1, 0x6

    new-instance v0, Landroid/app/job/JobInfo$Builder;

    invoke-direct {v0, v1, v5}, Landroid/app/job/JobInfo$Builder;-><init>(ILandroid/content/ComponentName;)V

    invoke-virtual {v0, v4}, Landroid/app/job/JobInfo$Builder;->setRequiredNetworkType(I)Landroid/app/job/JobInfo$Builder;

    move-result-object v0

    invoke-virtual {v0, v4}, Landroid/app/job/JobInfo$Builder;->setPersisted(Z)Landroid/app/job/JobInfo$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/job/JobInfo$Builder;->build()Landroid/app/job/JobInfo;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/app/job/JobScheduler;->schedule(Landroid/app/job/JobInfo;)I

    goto/16 :goto_9

    :cond_27
    iget-object v1, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0A:LX/5pD;

    invoke-virtual {v1}, LX/5pD;->A07()Z

    move-result v0

    if-eqz v0, :cond_1e

    invoke-virtual {v1}, LX/5pD;->A04()Ljava/lang/Object;

    const-string v0, "isValidVNameRequirementNotFulfilled"

    invoke-static {v0}, LX/001;->A0j(Ljava/lang/String;)Ljava/lang/NullPointerException;

    move-result-object v0

    throw v0

    :cond_28
    iget v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->retryCount:I

    const/4 v11, 0x1

    if-lez v0, :cond_1d

    const/16 v11, 0xc

    goto/16 :goto_8

    :cond_29
    if-eqz v3, :cond_2a

    iput-boolean v4, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A15:Z

    iput-boolean v14, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A16:Z

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A04:J

    iget-object v5, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0F:LX/2qG;

    new-array v0, v4, [Lcom/whatsapp/jid/DeviceJid;

    aput-object v3, v0, v14

    invoke-static {v3}, LX/384;->A04(Lcom/whatsapp/jid/Jid;)I

    move-result v8

    move v10, v14

    move-object v6, v0

    move v7, v11

    move v9, v14

    invoke-virtual/range {v5 .. v10}, LX/2qG;->A03([Lcom/whatsapp/jid/DeviceJid;IIIZ)V

    :cond_2a
    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0F:LX/2qG;

    invoke-virtual {v0}, LX/2qG;->A00()V

    iget-boolean v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A15:Z

    if-eqz v0, :cond_0

    iget-object v1, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0E:LX/37u;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->id:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    iget v3, v2, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->messageType:I

    const/16 v2, 0x8

    iget-boolean v0, v1, LX/37u;->A0d:Z

    if-eqz v0, :cond_0

    iget-object v1, v1, LX/37u;->A0O:LX/30y;

    const/4 v0, -0x1

    invoke-virtual {v1, v4, v2, v0, v3}, LX/30y;->A05(IIII)V

    return-void

    :cond_2b
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;

    if-eqz v0, :cond_2c

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "disable live location job added"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_2c
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;

    if-eqz v0, :cond_2d

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v0, "rotate signed pre key job added"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_2d
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;

    if-eqz v0, :cond_2e

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "ReceiptProcessingJob/onAdded "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_2e
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;

    if-eqz v0, :cond_2f

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "ReceiptMultiTargetProcessingJob/onAdded "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_2f
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;

    if-eqz v0, :cond_31

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "GetVNameCertificateJob/onAdded"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    sget-object v3, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A02:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v1, v2, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->jid:Ljava/lang/String;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v3, v1, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v2, Lorg/whispersystems/jobqueue/Job;->parameters:Lorg/whispersystems/jobqueue/JobParameters;

    iget-object v0, v0, Lorg/whispersystems/jobqueue/JobParameters;->requirements:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_30
    :goto_b
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/whispersystems/jobqueue/requirements/Requirement;

    instance-of v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;

    if-eqz v0, :cond_30

    check-cast v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;

    invoke-virtual {v1}, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;->BHE()Z

    move-result v0

    if-nez v0, :cond_30

    iget-object v4, v2, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A00:LX/2qG;

    const/4 v0, 0x1

    new-array v3, v0, [Lcom/whatsapp/jid/DeviceJid;

    iget-object v0, v1, Lcom/gbwhatsapp/jobqueue/requirement/AxolotlSessionRequirement;->A01:Lcom/whatsapp/jid/DeviceJid;

    const/4 v1, 0x0

    aput-object v0, v3, v1

    const/4 v0, 0x2

    invoke-virtual {v4, v3, v0, v1}, LX/2qG;->A04([Lcom/whatsapp/jid/DeviceJid;IZ)V

    goto :goto_b

    :cond_31
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/GetStatusPrivacyJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/DeleteAccountFromHsmServerJob;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;

    if-eqz v0, :cond_0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "bulk get pre key job added"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_32
    iget-object v3, v2, Lcom/gbwhatsapp/jobqueue/job/SendLiveLocationKeyJob;->A01:LX/2qG;

    const/4 v2, 0x0

    new-array v0, v2, [Lcom/whatsapp/jid/DeviceJid;

    invoke-virtual {v4, v0}, Ljava/util/AbstractCollection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Lcom/whatsapp/jid/DeviceJid;

    const/4 v0, 0x4

    invoke-virtual {v3, v1, v0, v2}, LX/2qG;->A04([Lcom/whatsapp/jid/DeviceJid;IZ)V

    return-void
.end method

.method public A05()V
    .locals 7

    instance-of v0, p0, LX/3we;

    if-eqz v0, :cond_0

    const-string v0, "Fetch2FAEmailStatusJob/canceled"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    return-void

    :cond_0
    instance-of v0, p0, LX/3wl;

    if-eqz v0, :cond_1

    move-object v2, p0

    check-cast v2, LX/3wl;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendViewReceiptJob/onAdded; "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, LX/3wl;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_1
    instance-of v0, p0, LX/3xE;

    if-eqz v0, :cond_2

    move-object v2, p0

    check-cast v2, LX/3xE;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v0, "sendNewsletterMessageJob/e2e send job canceled"

    invoke-static {v2, v0, v1}, LX/3xE;->A01(LX/3xE;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {v2, v0}, LX/3xE;->A09(LX/36P;)V

    return-void

    :cond_2
    instance-of v0, p0, LX/1bD;

    if-eqz v0, :cond_3

    move-object v1, p0

    check-cast v1, LX/1bD;

    const-string v0, "NewsletterSubscribersGraphqlJob/onCanceled"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    const/4 v0, 0x0

    iput-object v0, v1, LX/1bD;->callback:LX/401;

    return-void

    :cond_3
    instance-of v0, p0, LX/1bA;

    if-eqz v0, :cond_4

    const-string v0, "GetNewsletterMyAddOnsMessagesJob/onCanceled"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    return-void

    :cond_4
    instance-of v0, p0, LX/1bB;

    if-eqz v0, :cond_5

    const-string v0, "GetNewsletterMessagesUpdatesJob/onCanceled"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    return-void

    :cond_5
    instance-of v0, p0, LX/1bC;

    if-eqz v0, :cond_7

    move-object v2, p0

    check-cast v2, LX/1bC;

    const-string v0, "GetNewsletterMessagesJob/onCanceled"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v1, v2, LX/1bC;->callback:LX/402;

    if-eqz v1, :cond_6

    iget-object v0, v2, LX/1bC;->token:Ljava/lang/String;

    invoke-interface {v1, v0}, LX/402;->BiH(Ljava/lang/String;)V

    :cond_6
    return-void

    :cond_7
    instance-of v0, p0, LX/3wg;

    if-nez v0, :cond_6

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;

    if-eqz v0, :cond_9

    move-object v4, p0

    check-cast v4, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v0, "asyncMessageJob/canceled async message job"

    invoke-static {v0, v3}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "; rowId="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v0, v4, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;->rowId:J

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, "; job="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    instance-of v0, v4, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;

    if-eqz v0, :cond_8

    const-string/jumbo v0, "processVCard"

    :goto_0
    invoke-static {v0, v2}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_8
    const-string v0, "asyncTokenize"

    goto :goto_0

    :cond_9
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;

    if-eqz v0, :cond_a

    move-object v1, p0

    check-cast v1, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;

    const-string v0, "SyncdTableEmptyKeyCheckJob/onCanceled"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v1, v1, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;->A00:LX/31Z;

    const/4 v0, 0x7

    invoke-virtual {v1, v0}, LX/31Z;->A04(I)V

    return-void

    :cond_a
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;

    if-eqz v0, :cond_b

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncProfilePictureJob/onCanceled/cancel sync picture job param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;->jids:[Ljava/lang/String;

    invoke-static {v0}, LX/38f;->A0A([Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    const-string v0, "jid list is empty"

    invoke-static {v0, v1}, LX/38Z;->A0A(Ljava/lang/String;Ljava/util/Collection;)V

    return-void

    :cond_b
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;

    if-eqz v0, :cond_c

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncDevicesJob/onCanceled/cancel sync devices job param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, v2, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->A01:LX/2fx;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->jids:[Ljava/lang/String;

    invoke-virtual {v1, v0}, LX/2fx;->A00([Ljava/lang/String;)V

    return-void

    :cond_c
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;

    if-eqz v0, :cond_d

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncDeviceAndResendMessageJob/onCanceled/param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, v2, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A01:LX/2fx;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A04:LX/30N;

    iget-object v1, v1, LX/2fx;->A02:Ljava/util/Set;

    monitor-enter v1

    goto/16 :goto_1

    :cond_d
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;

    if-nez v0, :cond_6

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;

    if-eqz v0, :cond_e

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncDeviceAndResendMessageJob/onCanceled/param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, v2, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;->A05:LX/2fx;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;->A0H:LX/30N;

    iget-object v1, v1, LX/2fx;->A02:Ljava/util/Set;

    monitor-enter v1

    goto/16 :goto_2

    :cond_e
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;

    if-eqz v0, :cond_f

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled send status privacy job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_f
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;

    if-eqz v0, :cond_10

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled sent read receipts job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->A09()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_10
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;

    if-eqz v0, :cond_11

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled sent read receipts job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_11
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;

    if-eqz v0, :cond_12

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendPlayedReceiptJobV2/onCanceled; "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_12
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;

    if-eqz v0, :cond_13

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendPlayedReceiptJob/canceled send played receipts job; id="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;->messageId:Ljava/lang/String;

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_13
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;

    if-eqz v0, :cond_14

    move-object v3, p0

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "canceled send permananent-failure receipt job"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "; jid="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->jid:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "; participant="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->participant:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "; id="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->messageKeyId:Ljava/lang/String;

    invoke-static {v0, v1}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_14
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;

    if-eqz v0, :cond_15

    move-object v1, p0

    check-cast v1, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v0, "SendPeerMessageJob/onCanceled/cancel send job"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "; peer_msg_row_id="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v0, v1, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;->peerMessageRowId:J

    invoke-static {v2, v0, v1}, LX/001;->A0o(Ljava/lang/StringBuilder;J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_15
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;

    if-eqz v0, :cond_16

    move-object v3, p0

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "canceled send order-status-update-failure receipt job"

    invoke-static {v0, v2}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "; jid="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;->jid:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "; id="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;->messageKeyId:Ljava/lang/String;

    invoke-static {v0, v1}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_16
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;

    if-eqz v0, :cond_17

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendMediaErrorReceiptJob/canceled send played receipts job id="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->messageId:Ljava/lang/String;

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_17
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendLiveLocationKeyJob;

    if-eqz v0, :cond_18

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendLiveLocationKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled send live location key job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendLiveLocationKeyJob;->A09()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_18
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;

    if-eqz v0, :cond_19

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled send final live location retry job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_19
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;

    if-eqz v0, :cond_1a

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled send final live location job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A09()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_1a
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;

    if-eqz v0, :cond_1b

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled sent engaged receipts job: "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_1b
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;

    if-eqz v0, :cond_1e

    move-object v4, p0

    check-cast v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendE2EMessageJob/e2e send job canceled"

    invoke-static {v4, v0, v1}, LX/0yT;->A12(Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    sget-object v6, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A19:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v5, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->jid:Ljava/lang/String;

    iget-object v3, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->id:Ljava/lang/String;

    iget v2, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->editVersion:I

    iget-object v1, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->participant:Ljava/lang/String;

    new-instance v0, LX/2gC;

    invoke-direct {v0, v5, v3, v1, v2}, LX/2gC;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v6, v0}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0q:LX/1Eb;

    iget v0, v1, LX/1Eb;->bitField1_:I

    and-int/lit16 v0, v0, 0x100

    if-eqz v0, :cond_6

    iget-object v0, v1, LX/1Eb;->keepInChatMessage_:LX/1CJ;

    if-nez v0, :cond_1c

    sget-object v0, LX/1CJ;->DEFAULT_INSTANCE:LX/1CJ;

    if-eqz v0, :cond_6

    :cond_1c
    iget-object v0, v0, LX/1CJ;->key_:LX/1Ea;

    if-nez v0, :cond_1d

    sget-object v0, LX/1Ea;->DEFAULT_INSTANCE:LX/1Ea;

    :cond_1d
    iget-object v0, v0, LX/1Ea;->remoteJid_:Ljava/lang/String;

    invoke-static {v0}, LX/33Q;->A02(Ljava/lang/String;)LX/1ZJ;

    move-result-object v3

    if-eqz v3, :cond_6

    iget-object v2, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0n:LX/2l7;

    const/4 v1, 0x1

    iget-object v0, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->id:Ljava/lang/String;

    invoke-static {v3, v0, v1}, LX/30N;->A05(LX/1ZJ;Ljava/lang/String;Z)LX/30N;

    move-result-object v1

    iget-object v0, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0e:Lcom/whatsapp/jid/DeviceJid;

    invoke-virtual {v2, v0, v1}, LX/2l7;->A02(Lcom/whatsapp/jid/DeviceJid;LX/30N;)V

    iget-object v1, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0C:LX/3by;

    const/16 v0, 0x17

    invoke-static {v1, v4, v3, v0}, LX/3by;->A0D(LX/3by;Ljava/lang/Object;Ljava/lang/Object;I)V

    return-void

    :goto_1
    :try_start_0
    invoke-interface {v1, v0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit v1

    return-void

    :catchall_0
    move-exception v0

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    :goto_2
    :try_start_1
    invoke-interface {v1, v0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit v1

    return-void

    :catchall_1
    move-exception v0

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    throw v0

    :cond_1e
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;

    if-eqz v0, :cond_1f

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled disable live location job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_1f
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;

    if-eqz v0, :cond_20

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendDeleteHistorySyncMmsJob/ cancelled chunkId="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;->chunkId:Ljava/lang/String;

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_20
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;

    if-eqz v0, :cond_21

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled rotate signed pre key job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_21
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;

    if-eqz v0, :cond_22

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "ReceiptProcessingJob/onCanceled/cancel job param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_22
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;

    if-eqz v0, :cond_23

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "ReceiptMultiTargetProcessingJob/onCanceled/cancel job param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_23
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;

    if-eqz v0, :cond_24

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "GetVNameCertificateJob/canceled get vname certificate job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    sget-object v1, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A02:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->jid:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_24
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/GetStatusPrivacyJob;

    if-eqz v0, :cond_25

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/GetStatusPrivacyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled get status privacy job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {v0, v2}, LX/0yL;->A1I(Ljava/lang/StringBuilder;Lorg/whispersystems/jobqueue/Job;)V

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_25
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;

    if-eqz v0, :cond_27

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;

    iget-object v1, v2, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A01:Lcom/whatsapp/jid/UserJid;

    if-eqz v1, :cond_26

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A03:LX/2ot;

    invoke-virtual {v0, v1}, LX/2ot;->A01(Lcom/whatsapp/jid/UserJid;)V

    :cond_26
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled generate privacy token job"

    invoke-static {v0, v1}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {v0, v2}, LX/0yL;->A1I(Ljava/lang/StringBuilder;Lorg/whispersystems/jobqueue/Job;)V

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_27
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/DeleteAccountFromHsmServerJob;

    if-eqz v0, :cond_28

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "DeleteAccountFromHsmServerJob/canceled delete account from hsm server job"

    invoke-static {v0, v1}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {v0, p0}, LX/0yL;->A1I(Ljava/lang/StringBuilder;Lorg/whispersystems/jobqueue/Job;)V

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_28
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;

    if-eqz v0, :cond_29

    move-object v2, p0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "canceled bulk get pre key job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_29
    instance-of v0, p0, LX/3wu;

    if-eqz v0, :cond_2a

    const-string v0, "GroupInfoBatchProcessor/FetchTruncatedGroupJob canceled"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    return-void

    :cond_2a
    instance-of v0, p0, LX/3wh;

    if-eqz v0, :cond_2b

    move-object v3, p0

    check-cast v3, LX/3wh;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "GroupFetchAllMembershipApprovalRequestsJob canceled"

    invoke-static {v0, v2}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v1, v3}, LX/0yL;->A1I(Ljava/lang/StringBuilder;Lorg/whispersystems/jobqueue/Job;)V

    const-string v0, "; groupJid="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, LX/3wh;->groupJidRawString:Ljava/lang/String;

    invoke-static {v0, v1}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_2b
    move-object v2, p0

    check-cast v2, LX/3wk;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "MemberSuggestedGroupsSyncJob/canceled; "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, LX/3wk;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void
.end method

.method public A06(Ljava/lang/Exception;)Z
    .locals 15

    move-object/from16 v4, p1

    move-object v3, p0

    instance-of v0, p0, LX/3we;

    if-eqz v0, :cond_2

    const-string v0, "Fetch2FAEmailStatusJob/exception"

    invoke-static {v0, v4}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v1, 0x1

    :cond_1
    return v1

    :cond_2
    instance-of v0, p0, LX/3wl;

    if-nez v0, :cond_0

    instance-of v0, p0, LX/3xE;

    if-eqz v0, :cond_4

    check-cast v3, LX/3xE;

    const/4 v0, 0x0

    invoke-static {v4, v0}, LX/0yO;->A0s(Ljava/lang/Object;I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v0, "sendNewsletterMessageJob/exception while sending message"

    invoke-static {v3, v0, v1}, LX/3xE;->A01(LX/3xE;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    invoke-virtual {v4}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    instance-of v0, v0, LX/1tD;

    if-eqz v0, :cond_0

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v0, "sendNewsletterMessageJob/Cannot send message due to large payload "

    invoke-static {v3, v0, v1}, LX/3xE;->A01(LX/3xE;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {v3, v0}, LX/3xE;->A09(LX/36P;)V

    :cond_3
    :goto_1
    const/4 v1, 0x0

    return v1

    :cond_4
    instance-of v0, p0, LX/1bD;

    if-nez v0, :cond_3

    instance-of v0, p0, LX/1bA;

    if-nez v0, :cond_0

    instance-of v0, p0, LX/1bB;

    if-nez v0, :cond_3

    instance-of v0, p0, LX/1bC;

    if-nez v0, :cond_3

    instance-of v0, p0, LX/3wg;

    if-nez v0, :cond_0

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;

    if-eqz v0, :cond_6

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v0, "asyncMessageJob/exception while running async message job"

    invoke-static {v0, v5}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "; rowId="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v0, v3, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;->rowId:J

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, "; job="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    instance-of v0, v3, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;

    if-eqz v0, :cond_5

    const-string/jumbo v0, "processVCard"

    :goto_2
    invoke-static {v0, v2}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v5, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto :goto_0

    :cond_5
    const-string v0, "asyncTokenize"

    goto :goto_2

    :cond_6
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;

    if-eqz v0, :cond_7

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;

    const-string v0, "SyncdTableEmptyKeyCheckJob/onShouldRetry"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v1, v3, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;->A00:LX/31Z;

    const/4 v0, 0x7

    invoke-virtual {v1, v0}, LX/31Z;->A04(I)V

    goto :goto_1

    :cond_7
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;

    if-eqz v0, :cond_8

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncProfilePictureJob/onShouldReply/exception while running picture sync param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_8
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;

    if-eqz v0, :cond_9

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncDevicesJob/onShouldReply/exception while running devices sync param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_9
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;

    if-eqz v0, :cond_a

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncDeviceAndResendMessageJob/onShouldReply/param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " ;exception="

    invoke-static {v1, v0, v4}, LX/0yK;->A1Q(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/Object;)V

    goto/16 :goto_0

    :cond_a
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;

    if-nez v0, :cond_3

    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;

    if-eqz v0, :cond_b

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SyncDeviceAndResendMessageJob/onShouldReply/param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceAndResendMessageJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " ;exception="

    invoke-static {v1, v0, v4}, LX/0yK;->A1Q(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/Object;)V

    goto/16 :goto_0

    :cond_b
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;

    if-eqz v0, :cond_c

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running send status privacy job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_c
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;

    if-eqz v0, :cond_d

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running sent persistent retry job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->A09()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_d
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;

    if-eqz v0, :cond_e

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running sent read receipts job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_e
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;

    if-eqz v0, :cond_f

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->A08()Ljava/lang/String;

    goto/16 :goto_0

    :cond_f
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;

    if-eqz v0, :cond_10

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendPlayedReceiptJob/exception while running sent played receipt job; id="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;->messageId:Ljava/lang/String;

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_10
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;

    if-eqz v0, :cond_11

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "exception while running send permanent failure receipt job"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "; jid="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->jid:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "; participant="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->participant:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "; id="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->messageKeyId:Ljava/lang/String;

    invoke-static {v0, v1}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_11
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;

    if-eqz v0, :cond_12

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v0, "SendPeerMessageJob/onShouldReply/exception while running"

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "; peer_msg_row_id="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendPeerMessageJob;->peerMessageRowId:J

    invoke-static {v2, v0, v1}, LX/001;->A0o(Ljava/lang/StringBuilder;J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v5, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_12
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;

    if-eqz v0, :cond_13

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "exception while running send order status update failure receipt job"

    invoke-static {v0, v2}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "; jid="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;->jid:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "; id="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;->messageKeyId:Ljava/lang/String;

    invoke-static {v0, v1}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_13
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;

    if-eqz v0, :cond_14

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendMediaErrorReceiptJob/exception while running sent played receipt job id="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->messageId:Ljava/lang/String;

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_14
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendLiveLocationKeyJob;

    if-eqz v0, :cond_15

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendLiveLocationKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running send live location key job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SendLiveLocationKeyJob;->A09()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_15
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;

    if-eqz v0, :cond_16

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running send final live location retry job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_16
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;

    if-eqz v0, :cond_17

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running send final live location job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A09()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_17
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;

    if-eqz v0, :cond_18

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;

    invoke-static {v4}, LX/0yL;->A0c(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running sent engaged receipts job: "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_18
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;

    if-eqz v0, :cond_1c

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendE2EMessageJob/exception while sending e2e message"

    invoke-static {v3, v0, v1}, LX/0yT;->A12(Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    instance-of v0, v4, Lcom/gbwhatsapp/jobqueue/job/E2eMessageEncryptor$EncryptionFailException;

    const/4 v8, 0x0

    if-eqz v0, :cond_1a

    iget-object v2, v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0E:LX/37u;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->id:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v0, 0x7

    invoke-virtual {v2, v1, v0}, LX/37u;->A0C(II)V

    move-object v2, v4

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/E2eMessageEncryptor$EncryptionFailException;

    iget v0, v2, Lcom/gbwhatsapp/jobqueue/job/E2eMessageEncryptor$EncryptionFailException;->encryptionRetryCount:I

    const/4 v6, 0x3

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    if-le v0, v6, :cond_2a

    const-string v0, "SendE2EMessageJob/encryption failure limit reached for "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/E2eMessageEncryptor$EncryptionFailException;->jid:Lcom/whatsapp/jid/DeviceJid;

    invoke-static {v0, v1}, LX/0yK;->A0o(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    iget-object v1, v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0E:LX/37u;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->id:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    iget-boolean v0, v1, LX/37u;->A0d:Z

    if-eqz v0, :cond_19

    iget-object v4, v1, LX/37u;->A0O:LX/30y;

    iget-object v2, v4, LX/30y;->A00:LX/2Un;

    monitor-enter v2

    :try_start_0
    iget-object v1, v2, LX/2Un;->A00:Ljava/util/Map;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v2

    if-eqz v0, :cond_19

    invoke-virtual {v4, v5, v6}, LX/30y;->A06(IS)V

    :cond_19
    iget-object v1, v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0E:LX/37u;

    iget-object v2, v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0r:LX/36P;

    iget v5, v2, LX/36P;->A1d:I

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0r:LX/36P;

    iget v6, v0, LX/36P;->A0B:I

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0h:LX/2bX;

    invoke-virtual {v0}, LX/2bX;->A00()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v7

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A0D()Z

    move-result v13

    iget-boolean v14, v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A18:Z

    const/16 v4, 0xc

    const/4 v3, 0x0

    move v10, v8

    move v11, v8

    move v12, v8

    move v9, v8

    invoke-virtual/range {v1 .. v14}, LX/37u;->A0N(LX/36P;Ljava/lang/Integer;IIIIIIIZZZZ)V

    goto/16 :goto_1

    :cond_1a
    instance-of v0, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob$OutOfMemoryException;

    if-eqz v0, :cond_1b

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendE2EMessageJob/Cannot send message due to oom "

    invoke-static {v3, v0, v1}, LX/0yT;->A12(Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1G(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    check-cast v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob$OutOfMemoryException;

    iget v0, v4, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob$OutOfMemoryException;->messageDistributionType:I

    invoke-virtual {v3, v0, v8}, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A09(II)V

    goto/16 :goto_1

    :cond_1b
    invoke-virtual {v4}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    instance-of v0, v0, LX/1tD;

    if-eqz v0, :cond_2b

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendE2EMessageJob/Cannot send message due to large payload "

    invoke-static {v3, v0, v1}, LX/0yT;->A12(Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1G(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    check-cast v0, LX/1tD;

    iget v1, v3, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A00:I

    iget v0, v0, LX/1tD;->excessPayloadByteSize:I

    invoke-virtual {v3, v1, v0}, Lcom/gbwhatsapp/jobqueue/job/SendE2EMessageJob;->A09(II)V

    goto/16 :goto_1

    :cond_1c
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;

    if-eqz v0, :cond_1d

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running disable live location job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_1d
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;

    if-eqz v0, :cond_1e

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "SendDeleteHistorySyncMmsJob/ exception while running job chunkId="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;->chunkId:Ljava/lang/String;

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_1e
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;

    if-eqz v0, :cond_1f

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running rotate signed pre key job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_1f
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;

    if-eqz v0, :cond_20

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "ReceiptProcessingJob/onShouldRetry/exception while running param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_20
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;

    if-eqz v0, :cond_21

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "ReceiptMultiTargetProcessingJob/onShouldRetry/exception while running param="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_21
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;

    if-eqz v0, :cond_22

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "GetVNameCertificateJob/onShouldRetry, exception while running get vname certificate job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_22
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/GetStatusPrivacyJob;

    if-eqz v0, :cond_23

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/GetStatusPrivacyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running get status privacy job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {v0, v3}, LX/0yL;->A1I(Ljava/lang/StringBuilder;Lorg/whispersystems/jobqueue/Job;)V

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_23
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;

    if-eqz v0, :cond_27

    invoke-virtual {v4}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    instance-of v0, v1, LX/1xz;

    if-eqz v0, :cond_24

    check-cast v1, LX/1xz;

    iget-object v0, v1, LX/1xz;->node:LX/381;

    if-eqz v0, :cond_24

    invoke-static {v0}, LX/2tk;->A01(LX/381;)I

    move-result v1

    const/16 v0, 0x190

    if-lt v1, v0, :cond_24

    const/16 v0, 0x1f4

    const/4 v2, 0x0

    if-lt v1, v0, :cond_25

    :cond_24
    const/4 v2, 0x1

    :cond_25
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running generate privacy token job, "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v2, :cond_26

    const-string v0, ""

    :goto_3
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "retrying"

    invoke-static {v0, v1}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {v0, p0}, LX/0yL;->A1I(Ljava/lang/StringBuilder;Lorg/whispersystems/jobqueue/Job;)V

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    return v2

    :cond_26
    const-string/jumbo v0, "not "

    goto :goto_3

    :cond_27
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/DeleteAccountFromHsmServerJob;

    if-eqz v0, :cond_28

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "DeleteAccountFromHsmServerJob/exception while running delete account from hsm server job"

    invoke-static {v0, v1}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {v0, p0}, LX/0yL;->A1I(Ljava/lang/StringBuilder;Lorg/whispersystems/jobqueue/Job;)V

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_28
    instance-of v0, p0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;

    if-eqz v0, :cond_29

    check-cast v3, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "exception while running bulk get pre key job"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    goto/16 :goto_0

    :cond_29
    instance-of v0, p0, LX/3wu;

    if-eqz v0, :cond_2c

    const/4 v0, 0x0

    invoke-static {v4, v0}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    instance-of v0, v4, LX/1yA;

    if-nez v0, :cond_0

    invoke-virtual {v4}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    instance-of v0, v0, LX/1yA;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    monitor-exit v2

    throw v0

    :cond_2a
    const-string v0, "SendE2EMessageJob/retrying job due to encryption failure for "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v2, Lcom/gbwhatsapp/jobqueue/job/E2eMessageEncryptor$EncryptionFailException;->jid:Lcom/whatsapp/jid/DeviceJid;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "; encRetryCount "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, v2, Lcom/gbwhatsapp/jobqueue/job/E2eMessageEncryptor$EncryptionFailException;->encryptionRetryCount:I

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-static {v1}, LX/0yM;->A18(Ljava/lang/Object;)V

    :cond_2b
    instance-of v0, v4, Lcom/gbwhatsapp/jobqueue/job/E2eMessageEncryptor$UnrecoverableErrorException;

    xor-int/lit8 v1, v0, 0x1

    return v1

    :cond_2c
    instance-of v0, p0, LX/3wh;

    if-eqz v0, :cond_31

    check-cast v3, LX/3wh;

    const/4 v2, 0x0

    if-eqz p1, :cond_30

    invoke-virtual {v4}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    :goto_4
    instance-of v0, v1, LX/1xz;

    if-eqz v0, :cond_2d

    check-cast v1, LX/1xz;

    iget-object v2, v1, LX/1xz;->node:LX/381;

    :cond_2d
    const/4 v5, 0x1

    if-eqz v2, :cond_2e

    invoke-static {v2}, LX/2tk;->A01(LX/381;)I

    move-result v1

    const/16 v0, 0x190

    if-gt v0, v1, :cond_2e

    const/16 v0, 0x1f4

    if-ge v1, v0, :cond_2e

    const/4 v5, 0x0

    :cond_2e
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v0, "GroupFetchAllMembershipApprovalRequestsJob/ exception while running iq call "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v5, :cond_2f

    const-string v0, ""

    :goto_5
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "retrying"

    invoke-static {v0, v2}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v1, v3}, LX/0yL;->A1I(Ljava/lang/StringBuilder;Lorg/whispersystems/jobqueue/Job;)V

    const-string v0, "; groupJid="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v3, LX/3wh;->groupJidRawString:Ljava/lang/String;

    invoke-static {v0, v1}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    return v5

    :cond_2f
    const-string/jumbo v0, "not "

    goto :goto_5

    :cond_30
    move-object v1, v2

    goto :goto_4

    :cond_31
    check-cast v3, LX/3wk;

    const/4 v2, 0x0

    if-eqz p1, :cond_35

    invoke-virtual {v4}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    :goto_6
    instance-of v0, v1, LX/1xz;

    if-eqz v0, :cond_32

    move-object v2, v1

    check-cast v2, LX/1xz;

    :cond_32
    const/4 v5, 0x1

    if-eqz v2, :cond_33

    iget-object v0, v2, LX/1xz;->node:LX/381;

    if-eqz v0, :cond_33

    invoke-static {v0}, LX/2tk;->A01(LX/381;)I

    move-result v1

    const/16 v0, 0x190

    if-gt v0, v1, :cond_34

    const/16 v0, 0x1f4

    if-ge v1, v0, :cond_34

    :cond_33
    const-string v2, ""

    :goto_7
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "MemberSuggestedGroupsSyncJob/exception while running iq call,"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " retrying; "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, LX/3wk;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1, v4}, LX/0yK;->A13(Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/Throwable;)V

    return v5

    :cond_34
    const/4 v5, 0x0

    const-string v2, " not"

    goto :goto_7

    :cond_35
    move-object v1, v2

    goto :goto_6
.end method

.method public A07()V
    .locals 29

    move-object/from16 v0, p0

    instance-of v1, v0, LX/3we;

    if-eqz v1, :cond_0

    check-cast v0, LX/3we;

    const-string v1, "Fetch2FAEmailStatusJob/onRun: asking for 2FA status"

    invoke-static {v1}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v4, v0, LX/3we;->A01:LX/2Lo;

    iget-object v6, v4, LX/2Lo;->A01:LX/34u;

    invoke-virtual {v6}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v9

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "TwoFactorXmppMethods/sendGetTwoFactorAuth; iq="

    invoke-static {v2, v1, v9}, LX/0yK;->A1S(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v3, LX/15f;

    invoke-direct {v3}, LX/15f;-><init>()V

    const/16 v1, 0x13

    new-instance v7, LX/49d;

    invoke-direct {v7, v3, v1, v4}, LX/49d;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    const/16 v10, 0x72

    const-string v1, "2fa"

    invoke-static {v1}, LX/381;->A0I(Ljava/lang/String;)LX/381;

    move-result-object v5

    invoke-static {}, LX/0yU;->A0j()[LX/3C7;

    move-result-object v4

    const-string/jumbo v2, "to"

    sget-object v1, LX/1ZP;->A00:LX/1ZP;

    invoke-static {v1, v2, v4}, LX/3C7;->A03(Lcom/whatsapp/jid/Jid;Ljava/lang/String;[Ljava/lang/Object;)V

    const-string v1, "id"

    invoke-static {v1, v9, v4}, LX/3C7;->A07(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const-string/jumbo v2, "xmlns"

    const-string/jumbo v1, "urn:xmpp:whatsapp:account"

    invoke-static {v2, v1, v4}, LX/3C7;->A08(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const-string/jumbo v2, "type"

    const-string v1, "get"

    invoke-static {v5, v2, v1, v4}, LX/381;->A0E(LX/381;Ljava/lang/String;Ljava/lang/String;[LX/3C7;)LX/381;

    move-result-object v8

    const-wide/16 v11, 0x7d00

    invoke-virtual/range {v6 .. v12}, LX/34u;->A0L(LX/43r;LX/381;Ljava/lang/String;IJ)Z

    :try_start_0
    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v3, v11, v12, v1}, LX/6gB;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    iget-object v0, v0, LX/3we;->A00:LX/31M;

    invoke-virtual {v0}, LX/31M;->A00()Landroid/content/SharedPreferences;

    move-result-object v1

    const-string/jumbo v0, "two_factor_auth_email_set"

    invoke-static {v1, v0}, LX/0yO;->A01(Landroid/content/SharedPreferences;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_9c

    const-string v0, "Fetch2FAEmailStatusJob/onRun: email status fetching failed"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    const-string v1, "Failing Fetch2FAEmailStatusJob, fetching status failed"

    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_0
    const-string v0, "Fetch2FAEmailStatusJob/onRun: timeout waiting for response"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    const-string v1, "Failing Fetch2FAEmailStatusJob, timeout for response"

    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_0
    instance-of v1, v0, LX/3wl;

    if-eqz v1, :cond_9

    check-cast v0, LX/3wl;

    invoke-virtual {v0}, LX/3wl;->A08()Ljava/lang/String;

    sget-object v2, LX/1Z7;->A03:LX/33T;

    iget-object v1, v0, LX/3wl;->newsletterRawJid:Ljava/lang/String;

    invoke-virtual {v2, v1}, LX/33T;->A02(Ljava/lang/String;)LX/1Z7;

    move-result-object v7

    if-eqz v7, :cond_9c

    iget-object v1, v0, LX/3wl;->serverMessageIds:Ljava/util/List;

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v4

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_1
    :goto_0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/16 v6, 0x10

    const-string/jumbo v16, "newsletterMessageStore"

    if-eqz v1, :cond_3

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    invoke-static {v10}, LX/0yQ;->A0D(Ljava/lang/Object;)J

    move-result-wide v1

    iget-object v3, v0, LX/3wl;->A03:LX/2rY;

    if-nez v3, :cond_2

    invoke-static/range {v16 .. v16}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_2
    invoke-virtual {v3, v7, v1, v2}, LX/2rY;->A00(LX/1Z7;J)LX/36P;

    move-result-object v5

    const-wide/16 v8, 0x0

    cmp-long v3, v1, v8

    if-lez v3, :cond_1

    if-eqz v5, :cond_1

    iget v1, v5, LX/36P;->A0D:I

    if-eq v1, v6, :cond_1

    invoke-virtual {v4, v10}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    invoke-virtual {v4}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_9c

    invoke-static {v7}, LX/2hl;->A00(Lcom/whatsapp/jid/Jid;)LX/2hl;

    move-result-object v3

    const-string/jumbo v11, "receipt"

    iput-object v11, v3, LX/2hl;->A05:Ljava/lang/String;

    const-string/jumbo v2, "view"

    iput-object v2, v3, LX/2hl;->A08:Ljava/lang/String;

    iget-object v1, v0, LX/3wl;->receiptStanzaId:Ljava/lang/String;

    iput-object v1, v3, LX/2hl;->A07:Ljava/lang/String;

    invoke-virtual {v3}, LX/2hl;->A01()LX/3C4;

    move-result-object v8

    iget-object v1, v0, LX/3wl;->receiptStanzaId:Ljava/lang/String;

    const/4 v5, 0x0

    move-object/from16 v19, v5

    move-object/from16 v22, v5

    move-object/from16 v18, v5

    move-object/from16 v20, v1

    move-object/from16 v21, v2

    move-object/from16 v17, v7

    invoke-static/range {v17 .. v22}, LX/38N;->A08(Lcom/whatsapp/jid/Jid;Lcom/whatsapp/jid/Jid;Lcom/whatsapp/jid/UserJid;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[LX/3C7;

    move-result-object v10

    invoke-static {v10}, LX/0yP;->A0j(Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v14

    invoke-virtual {v4}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_1
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v13, 0x0

    if-eqz v1, :cond_4

    invoke-static {v15}, LX/0yL;->A03(Ljava/util/Iterator;)J

    move-result-wide v1

    invoke-static {}, LX/0yU;->A0i()[LX/3C7;

    move-result-object v12

    const-string/jumbo v9, "server_id"

    new-instance v3, LX/3C7;

    invoke-direct {v3, v9, v1, v2}, LX/3C7;-><init>(Ljava/lang/String;J)V

    aput-object v3, v12, v13

    const-string v1, "item"

    invoke-static {v1, v14, v12}, LX/381;->A0S(Ljava/lang/String;Ljava/util/AbstractCollection;[LX/3C7;)V

    goto :goto_1

    :cond_4
    invoke-static {v14, v13}, LX/0yN;->A1a(Ljava/util/AbstractCollection;I)[LX/381;

    move-result-object v2

    const-string/jumbo v1, "list"

    invoke-static {v1, v5, v2}, LX/381;->A0K(Ljava/lang/String;[LX/3C7;[LX/381;)LX/381;

    move-result-object v1

    invoke-static {v1, v11, v10}, LX/381;->A0G(LX/381;Ljava/lang/String;[LX/3C7;)LX/381;

    move-result-object v3

    iget-object v2, v0, LX/3wl;->A02:LX/34u;

    if-nez v2, :cond_5

    const-string/jumbo v0, "messageClient"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_5
    const/16 v1, 0x197

    invoke-virtual {v2, v3, v8, v1}, LX/34u;->A08(LX/381;LX/3C4;I)Ljava/util/concurrent/Future;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    invoke-virtual {v4}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_6
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_9c

    invoke-static {v4}, LX/0yL;->A03(Ljava/util/Iterator;)J

    move-result-wide v2

    iget-object v1, v0, LX/3wl;->A03:LX/2rY;

    if-nez v1, :cond_7

    invoke-static/range {v16 .. v16}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_7
    invoke-virtual {v1, v7, v2, v3}, LX/2rY;->A00(LX/1Z7;J)LX/36P;

    move-result-object v1

    if-eqz v1, :cond_6

    iget-object v2, v0, LX/3wl;->A00:LX/30t;

    if-nez v2, :cond_8

    const-string/jumbo v0, "messageStatusStoreBridge"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_8
    iget-object v1, v1, LX/36P;->A1J:LX/30N;

    invoke-virtual {v2, v5, v1, v6}, LX/30t;->A01(LX/2EZ;LX/30N;I)V

    goto :goto_2

    :cond_9
    instance-of v1, v0, LX/1bD;

    if-eqz v1, :cond_c

    check-cast v0, LX/1bD;

    iget-boolean v1, v0, LX/3wc;->isCancelled:Z

    if-nez v1, :cond_9c

    const-string v1, "NewsletterSubscribersGraphqlJob/onRun"

    invoke-static {v1}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    new-instance v5, Lcom/whatsapp/infra/graphql/generated/newsletter/calls/XWA2NewsletterSubscribersInput;

    invoke-direct {v5}, Lcom/whatsapp/infra/graphql/generated/newsletter/calls/XWA2NewsletterSubscribersInput;-><init>()V

    iget-object v1, v0, LX/1bD;->newsletterJid:LX/1Z7;

    invoke-virtual {v1}, Lcom/whatsapp/jid/Jid;->getRawString()Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v1, "newsletter_id"

    invoke-virtual {v5, v1, v2}, Lcom/facebook/graphql/calls/GraphQlCallInput;->A07(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v3, v0, LX/1bD;->typeOfFetch:LX/1vM;

    sget-object v2, LX/1vM;->A03:LX/1vM;

    const/16 v1, 0x9c4

    if-ne v3, v2, :cond_a

    const/16 v1, 0xa

    :cond_a
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v1, "count"

    invoke-virtual {v5, v1, v2}, Lcom/facebook/graphql/calls/GraphQlCallInput;->A06(Ljava/lang/String;Ljava/lang/Integer;)V

    new-instance v1, Lcom/whatsapp/infra/graphql/generated/newsletter/NewsletterSubscribersQueryImpl$Builder;

    invoke-direct {v1}, Lcom/whatsapp/infra/graphql/generated/newsletter/NewsletterSubscribersQueryImpl$Builder;-><init>()V

    iget-object v4, v1, Lcom/whatsapp/infra/graphql/generated/newsletter/NewsletterSubscribersQueryImpl$Builder;->A00:LX/7Uh;

    const-string v2, "input"

    iget-object v1, v4, LX/7Uh;->A00:LX/6Pe;

    invoke-virtual {v1, v5, v2}, Lcom/facebook/graphql/calls/GraphQlCallInput;->A05(Lcom/facebook/graphql/calls/GraphQlCallInput;Ljava/lang/String;)V

    const-string v3, "NewsletterSubscribers"

    const-class v1, Lcom/whatsapp/infra/graphql/generated/newsletter/NewsletterSubscribersResponseImpl;

    new-instance v2, LX/7Ir;

    invoke-direct {v2, v4, v1, v3}, LX/7Ir;-><init>(LX/7Uh;Ljava/lang/Class;Ljava/lang/String;)V

    iget-object v1, v0, LX/1bD;->A02:LX/2g9;

    if-nez v1, :cond_b

    const-string v0, "graphqlClient"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_b
    invoke-virtual {v1, v2}, LX/2g9;->A01(LX/7Ir;)LX/2eT;

    move-result-object v2

    new-instance v1, LX/3uh;

    invoke-direct {v1, v0}, LX/3uh;-><init>(LX/1bD;)V

    invoke-virtual {v2, v1}, LX/2eT;->A01(LX/8wI;)V

    return-void

    :cond_c
    instance-of v1, v0, LX/1bA;

    if-eqz v1, :cond_f

    check-cast v0, LX/1bA;

    iget-boolean v1, v0, LX/3wc;->isCancelled:Z

    if-nez v1, :cond_9c

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v1, "GetNewsletterMyAddOnsMessagesJob/onRun "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v0, LX/1bA;->newsletterJid:LX/1Z7;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x20

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-wide v1, v0, LX/1bA;->count:J

    invoke-static {v3, v1, v2}, LX/0yK;->A1F(Ljava/lang/StringBuilder;J)V

    iget-object v1, v0, LX/1bA;->A02:LX/34u;

    const-string/jumbo v5, "messageClient"

    if-nez v1, :cond_d

    invoke-static {v5}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_d
    invoke-virtual {v1}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v6

    iget-wide v1, v0, LX/1bA;->count:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    iget-object v3, v0, LX/1bA;->newsletterJid:LX/1Z7;

    const/16 v2, 0x18

    new-instance v1, LX/1qG;

    invoke-direct {v1, v6, v2}, LX/1qG;-><init>(Ljava/lang/String;I)V

    new-instance v2, LX/1qF;

    invoke-direct {v2, v1}, LX/1qF;-><init>(LX/1qG;)V

    new-instance v1, LX/1qk;

    invoke-direct {v1, v3, v2, v4}, LX/1qk;-><init>(LX/1Z7;LX/1qF;Ljava/lang/Long;)V

    iget-object v3, v0, LX/1bA;->A02:LX/34u;

    if-nez v3, :cond_e

    invoke-static {v5}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_e
    const/16 v7, 0x170

    iget-object v5, v1, LX/2VU;->A00:LX/381;

    invoke-static {v5}, LX/7nJ;->A0O(Ljava/lang/Object;)V

    new-instance v4, LX/49d;

    invoke-direct {v4, v0, v1}, LX/49d;-><init>(LX/1bA;LX/1qk;)V

    const-wide/16 v8, 0x7d00

    invoke-virtual/range {v3 .. v9}, LX/34u;->A0E(LX/43r;LX/381;Ljava/lang/String;IJ)V

    return-void

    :cond_f
    instance-of v1, v0, LX/1bB;

    if-eqz v1, :cond_18

    check-cast v0, LX/1bB;

    iget-object v7, v0, LX/1bB;->beforeServerId:Ljava/lang/Long;

    const-string v9, "crashLogs"

    const/4 v8, 0x0

    const/4 v2, 0x0

    if-eqz v7, :cond_10

    invoke-virtual {v7}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    const-wide/16 v3, 0x0

    cmp-long v1, v5, v3

    if-gez v1, :cond_10

    iget-object v1, v0, LX/1bB;->A00:LX/2qa;

    if-nez v1, :cond_17

    invoke-static {v9}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_10
    iget-wide v3, v0, LX/1bB;->count:J

    const-wide/16 v5, 0x1

    cmp-long v1, v3, v5

    if-ltz v1, :cond_15

    const-wide/16 v5, 0x12c

    cmp-long v1, v3, v5

    if-gtz v1, :cond_15

    iget-boolean v1, v0, LX/3wc;->isCancelled:Z

    if-nez v1, :cond_9c

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "GetNewsletterMessagesUpdatesJob/onRun "

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-static {v2, v1, v7}, LX/0yP;->A1J(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/Object;)V

    iget-object v1, v0, LX/1bB;->afterServerId:Ljava/lang/Long;

    invoke-static {v1, v2}, LX/0yK;->A0p(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    iget-object v1, v0, LX/1bB;->A02:LX/34u;

    const-string/jumbo v7, "messageClient"

    if-nez v1, :cond_11

    invoke-static {v7}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_11
    invoke-virtual {v1}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v8

    iget-wide v1, v0, LX/1bB;->count:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    iget-wide v1, v0, LX/1bB;->sinceMs:J

    invoke-static {v1, v2}, LX/0yN;->A0S(J)Ljava/lang/Long;

    move-result-object v5

    iget-object v3, v0, LX/1bB;->newsletterJid:LX/1Z7;

    const/16 v2, 0x18

    new-instance v1, LX/1qG;

    invoke-direct {v1, v8, v2}, LX/1qG;-><init>(Ljava/lang/String;I)V

    new-instance v4, LX/1qG;

    invoke-direct {v4, v3, v1}, LX/1qG;-><init>(LX/1Z7;LX/1qG;)V

    iget-object v3, v0, LX/1bB;->beforeServerId:Ljava/lang/Long;

    if-eqz v3, :cond_12

    const/4 v1, 0x1

    :goto_3
    new-instance v2, LX/1qK;

    invoke-direct {v2, v3, v1}, LX/1qK;-><init>(Ljava/lang/Long;I)V

    new-instance v1, LX/1ql;

    invoke-direct {v1, v4, v2, v6, v5}, LX/1ql;-><init>(LX/1qG;LX/1qK;Ljava/lang/Long;Ljava/lang/Long;)V

    iget-object v5, v0, LX/1bB;->A02:LX/34u;

    if-nez v5, :cond_13

    invoke-static {v7}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_12
    iget-object v3, v0, LX/1bB;->afterServerId:Ljava/lang/Long;

    if-eqz v3, :cond_14

    const/4 v1, 0x0

    goto :goto_3

    :cond_13
    const/16 v9, 0x170

    iget-object v7, v1, LX/2VU;->A00:LX/381;

    invoke-static {v7}, LX/7nJ;->A0O(Ljava/lang/Object;)V

    new-instance v6, LX/49d;

    invoke-direct {v6, v0, v1}, LX/49d;-><init>(LX/1bB;LX/1ql;)V

    const-wide/16 v10, 0x7d00

    invoke-virtual/range {v5 .. v11}, LX/34u;->A0E(LX/43r;LX/381;Ljava/lang/String;IJ)V

    return-void

    :cond_14
    const-string v0, "GetNewsletterMessagesUpdatesJob/invalid before/after one of them must be set"

    invoke-static {v0}, LX/001;->A0g(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v0

    throw v0

    :cond_15
    iget-object v1, v0, LX/1bB;->A00:LX/2qa;

    if-nez v1, :cond_16

    invoke-static {v9}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_16
    const-string v0, "GetNewsletterMessagesUpdatesJob/invalid params - count"

    goto :goto_4

    :cond_17
    const-string v0, "GetNewsletterMessagesUpdatesJob/invalid params - beforeServerId"

    :goto_4
    invoke-virtual {v1, v0, v8, v2}, LX/2qa;->A0C(Ljava/lang/String;ZLjava/lang/String;)V

    return-void

    :cond_18
    instance-of v1, v0, LX/1bC;

    if-eqz v1, :cond_27

    check-cast v0, LX/1bC;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v1, "GetNewsletterMessagesJob/onRun "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, v0, LX/1bC;->count:J

    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v0, LX/1bC;->beforeServerId:Ljava/lang/Long;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v0, LX/1bC;->afterServerId:Ljava/lang/Long;

    invoke-static {v1, v3}, LX/0yK;->A0p(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    iget-object v1, v0, LX/1bC;->beforeServerId:Ljava/lang/Long;

    const-string v8, "crashLogs"

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_1a

    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    move-result-wide v6

    const-wide/16 v2, 0x0

    cmp-long v1, v6, v2

    if-gez v1, :cond_1a

    iget-object v1, v0, LX/1bC;->A00:LX/2qa;

    if-nez v1, :cond_19

    invoke-static {v8}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_19
    const-string v0, "GetNewsletterMessagesJob/invalid params - beforeServerId"

    goto/16 :goto_8

    :cond_1a
    iget-wide v6, v0, LX/1bC;->count:J

    const-wide/16 v2, 0x1

    cmp-long v1, v6, v2

    if-ltz v1, :cond_25

    const-wide/16 v2, 0x12c

    cmp-long v1, v6, v2

    if-gtz v1, :cond_25

    iget-object v2, v0, LX/1bC;->A01:LX/2ss;

    if-nez v2, :cond_1b

    const-string v0, "chatsCache"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_1b
    iget-object v1, v0, LX/1bC;->newsletterJid:LX/1Z7;

    invoke-virtual {v2, v1, v4}, LX/2ss;->A0B(LX/1ZJ;Z)LX/31w;

    move-result-object v2

    instance-of v1, v2, LX/1NE;

    if-eqz v1, :cond_1c

    check-cast v2, LX/1NE;

    if-eqz v2, :cond_1c

    iget-object v5, v2, LX/1NE;->A07:LX/1vd;

    :cond_1c
    iget-object v1, v0, LX/1bC;->A03:LX/34u;

    const-string/jumbo v7, "messageClient"

    if-nez v1, :cond_1d

    invoke-static {v7}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_1d
    invoke-virtual {v1}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v8

    iget-object v3, v0, LX/1bC;->newsletterJid:LX/1Z7;

    if-eqz v5, :cond_23

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    if-eq v2, v4, :cond_22

    const/4 v1, 0x1

    if-eq v2, v1, :cond_21

    const/4 v1, 0x2

    if-eq v2, v1, :cond_20

    const/4 v1, 0x3

    if-ne v2, v1, :cond_23

    const-string/jumbo v2, "owner"

    :goto_5
    new-instance v1, LX/1qV;

    invoke-direct {v1, v3, v2}, LX/1qV;-><init>(LX/1Z7;Ljava/lang/String;)V

    new-instance v6, LX/1qF;

    invoke-direct {v6, v1}, LX/1qF;-><init>(LX/1qV;)V

    iget-wide v1, v0, LX/1bC;->count:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    iget-object v3, v0, LX/1bC;->beforeServerId:Ljava/lang/Long;

    if-eqz v3, :cond_1e

    const/4 v2, 0x1

    :goto_6
    new-instance v1, LX/1qJ;

    invoke-direct {v1, v3, v2}, LX/1qJ;-><init>(Ljava/lang/Long;I)V

    :goto_7
    new-instance v3, LX/1qG;

    invoke-direct {v3, v1, v5}, LX/1qG;-><init>(LX/1qJ;Ljava/lang/Long;)V

    const/16 v1, 0x18

    new-instance v2, LX/1qG;

    invoke-direct {v2, v8, v1}, LX/1qG;-><init>(Ljava/lang/String;I)V

    new-instance v1, LX/1qF;

    invoke-direct {v1, v2}, LX/1qF;-><init>(LX/1qG;)V

    new-instance v2, LX/1qG;

    invoke-direct {v2, v3, v6, v1}, LX/1qG;-><init>(LX/1qG;LX/1qF;LX/1qF;)V

    new-instance v1, LX/1qk;

    invoke-direct {v1, v2, v4}, LX/1qk;-><init>(LX/1qG;I)V

    iget-object v5, v0, LX/1bC;->A03:LX/34u;

    if-nez v5, :cond_24

    invoke-static {v7}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_1e
    iget-object v3, v0, LX/1bC;->afterServerId:Ljava/lang/Long;

    if-eqz v3, :cond_1f

    const/4 v2, 0x0

    goto :goto_6

    :cond_1f
    const/4 v1, 0x0

    goto :goto_7

    :cond_20
    const-string v2, "admin"

    goto :goto_5

    :cond_21
    const-string/jumbo v2, "subscriber"

    goto :goto_5

    :cond_22
    const-string v2, "guest"

    goto :goto_5

    :cond_23
    const/4 v2, 0x0

    goto :goto_5

    :cond_24
    const/16 v9, 0x170

    iget-object v7, v1, LX/2VU;->A00:LX/381;

    invoke-static {v7}, LX/7nJ;->A0O(Ljava/lang/Object;)V

    new-instance v6, LX/49d;

    invoke-direct {v6, v0, v1}, LX/49d;-><init>(LX/1bC;LX/1qk;)V

    const-wide/16 v10, 0x7d00

    invoke-virtual/range {v5 .. v11}, LX/34u;->A0E(LX/43r;LX/381;Ljava/lang/String;IJ)V

    return-void

    :cond_25
    iget-object v1, v0, LX/1bC;->A00:LX/2qa;

    if-nez v1, :cond_26

    invoke-static {v8}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_26
    const-string v0, "GetNewsletterMessagesJob/invalid params - count"

    :goto_8
    invoke-virtual {v1, v0, v4, v5}, LX/2qa;->A0C(Ljava/lang/String;ZLjava/lang/String;)V

    return-void

    :cond_27
    instance-of v1, v0, LX/3wg;

    if-eqz v1, :cond_28

    check-cast v0, LX/3wg;

    iget-object v2, v0, LX/3wg;->A00:LX/369;

    iget-object v1, v0, LX/3wg;->fileToDelete:Ljava/io/File;

    iget-byte v0, v0, LX/3wg;->messageType:B

    invoke-static {v1}, LX/38j;->A0P(Ljava/io/File;)Z

    invoke-virtual {v2, v1, v0}, LX/369;->A07(Ljava/io/File;B)V

    return-void

    :cond_28
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;

    if-eqz v1, :cond_35

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;->A00:LX/3jF;

    invoke-virtual {v1}, LX/3jF;->A03()LX/3eM;

    move-result-object v22

    :try_start_1
    invoke-virtual/range {v22 .. v22}, LX/3eM;->A04()LX/3eL;

    move-result-object v21
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_b

    :try_start_2
    iget-object v3, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;->A01:LX/2pv;

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;->rowId:J

    invoke-static {v3, v1, v2}, LX/2pU;->A00(LX/2pv;J)LX/36P;

    move-result-object v6

    invoke-virtual/range {v21 .. v21}, LX/3eL;->A00()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_9

    :try_start_3
    invoke-virtual/range {v21 .. v21}, LX/3eL;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_b

    invoke-virtual/range {v22 .. v22}, LX/3eM;->close()V

    if-eqz v6, :cond_9c

    instance-of v5, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;

    if-eqz v5, :cond_29

    move-object v2, v0

    check-cast v2, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;

    iget-object v1, v2, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;->A06:LX/2nF;

    invoke-static {v6, v1}, LX/32d;->A02(LX/36P;LX/2nF;)Ljava/util/List;

    move-result-object v7

    if-eqz v7, :cond_2a

    :try_start_4
    iget-object v6, v2, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;->A02:LX/2iX;

    iget-object v4, v2, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;->A00:LX/3J5;

    iget-object v3, v2, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;->A01:LX/34w;

    iget-object v2, v2, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;->A03:LX/34x;

    new-instance v1, LX/5Y9;

    invoke-direct {v1, v4, v3, v6, v2}, LX/5Y9;-><init>(LX/3J5;LX/34w;LX/2iX;LX/34x;)V

    invoke-virtual {v1, v7}, LX/5Y9;->A01(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    goto :goto_9
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    :cond_29
    move-object v4, v0

    check-cast v4, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageTokenizationJob;

    const-string v1, "ftsMessageStore/backgroundTokenize"

    invoke-static {v1}, LX/34W;->A01(Ljava/lang/String;)LX/34W;

    move-result-object v3

    iget-object v1, v4, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageTokenizationJob;->A00:LX/3QZ;

    invoke-virtual {v1, v6}, LX/3QZ;->A0D(LX/36P;)Ljava/lang/String;

    move-result-object v2

    iget-object v1, v4, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageTokenizationJob;->A00:LX/3QZ;

    iget-object v1, v1, LX/3QZ;->A07:LX/34x;

    invoke-static {v1, v2}, LX/5aS;->A01(LX/34x;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3}, LX/34W;->A06()J

    goto :goto_9

    :catch_1
    move-exception v3

    const-string/jumbo v2, "processvcard/error constructing contacts"

    new-instance v1, LX/1xc;

    invoke-direct {v1, v3}, LX/1xc;-><init>(Ljava/lang/Throwable;)V

    invoke-static {v2, v1}, Lcom/whatsapp/util/Log;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_2a
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v2

    :goto_9
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;->A00:LX/3jF;

    invoke-virtual {v1}, LX/3jF;->A03()LX/3eM;

    move-result-object v22

    :try_start_5
    invoke-virtual/range {v22 .. v22}, LX/3eM;->A04()LX/3eL;

    move-result-object v21
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_b

    :try_start_6
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;->A01:LX/2pv;

    iget-wide v3, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;->rowId:J

    invoke-static {v1, v3, v4}, LX/2pU;->A00(LX/2pv;J)LX/36P;

    move-result-object v8

    if-eqz v8, :cond_34

    iget-boolean v1, v8, LX/36P;->A1N:Z

    if-nez v1, :cond_34

    if-eqz v5, :cond_33

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;

    check-cast v2, Ljava/util/List;

    instance-of v1, v8, LX/1ev;

    if-eqz v1, :cond_2b

    move-object v1, v8

    check-cast v1, LX/1ev;

    iput-object v2, v1, LX/1ev;->A02:Ljava/util/List;

    :cond_2b
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;->A04:LX/3QZ;

    invoke-virtual {v1, v8}, LX/3QZ;->A0K(LX/36P;)V

    iget-object v9, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/ProcessVCardMessageJob;->A05:LX/31g;

    iget-object v3, v8, LX/36P;->A1J:LX/30N;

    iget-boolean v0, v3, LX/30N;->A02:Z

    if-eqz v0, :cond_2c

    iget-object v0, v9, LX/31g;->A00:LX/2sr;

    invoke-static {v0}, LX/2sr;->A04(LX/2sr;)Lcom/whatsapp/jid/PhoneUserJid;

    move-result-object v7

    goto :goto_a

    :cond_2c
    invoke-virtual {v8}, LX/36P;->A0n()Lcom/whatsapp/jid/UserJid;

    move-result-object v7

    :goto_a
    if-eqz v7, :cond_34

    iget-object v0, v9, LX/31g;->A01:LX/3J5;

    invoke-virtual {v0, v7}, LX/3J5;->A06(LX/1ZJ;)LX/3ep;

    move-result-object v1

    iget-object v0, v9, LX/31g;->A00:LX/2sr;

    invoke-virtual {v0, v7}, LX/2sr;->A0Z(LX/1ZJ;)Z

    move-result v0

    if-nez v0, :cond_2d

    if-eqz v1, :cond_34

    iget-object v0, v1, LX/3ep;->A0G:LX/2jd;

    if-nez v0, :cond_2d

    goto/16 :goto_12

    :cond_2d
    iget-object v6, v3, LX/30N;->A00:LX/1ZJ;

    iget-object v5, v9, LX/31g;->A0A:LX/3jF;

    invoke-virtual {v5}, LX/3jF;->A03()LX/3eM;

    move-result-object v20
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_9

    :try_start_7
    invoke-virtual/range {v20 .. v20}, LX/3eM;->A04()LX/3eL;

    move-result-object v19
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_6

    :try_start_8
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :goto_b
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_32

    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, LX/2J2;

    iget-object v4, v10, LX/2J2;->A00:Ljava/lang/String;

    iget-object v2, v10, LX/2J2;->A01:LX/5Zj;

    iget-wide v0, v8, LX/36P;->A1L:J

    iget-object v3, v2, LX/5Zj;->A06:Ljava/util/List;

    if-eqz v3, :cond_31

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_2e
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_31

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LX/5LJ;

    iget-object v3, v3, LX/5LJ;->A01:Lcom/whatsapp/jid/UserJid;

    if-eqz v3, :cond_2e

    invoke-static {}, LX/0yT;->A0C()Landroid/content/ContentValues;

    move-result-object v3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    const-string/jumbo v13, "message_row_id"

    invoke-virtual {v3, v13, v14}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string/jumbo v0, "sender_jid"

    invoke-static {v3, v7, v0}, LX/0yM;->A0m(Landroid/content/ContentValues;Lcom/whatsapp/jid/Jid;Ljava/lang/String;)V

    const-string v1, "chat_jid"

    invoke-static {v6}, LX/38f;->A05(Lcom/whatsapp/jid/Jid;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v1, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v0, "vcard"

    invoke-virtual {v3, v0, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v5}, LX/3jF;->A03()LX/3eM;

    move-result-object v11
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    :try_start_9
    invoke-virtual {v11}, LX/3eM;->A04()LX/3eL;

    move-result-object v17
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    :try_start_a
    iget-object v12, v11, LX/3eM;->A02:LX/2sd;

    const-string/jumbo v1, "messages_vcards"

    const-string v0, "insertIntoLegacyTables/INSERT_MESSAGES_VCARDS"

    invoke-virtual {v12, v1, v0, v3}, LX/2sd;->A06(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    move-result-wide v3

    iget-object v0, v2, LX/5Zj;->A06:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :cond_2f
    :goto_c
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_30

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, LX/5LJ;

    iget-object v0, v15, LX/5LJ;->A01:Lcom/whatsapp/jid/UserJid;

    if-eqz v0, :cond_2f

    invoke-static {}, LX/0yT;->A0C()Landroid/content/ContentValues;

    move-result-object v2

    invoke-virtual {v2, v13, v14}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string/jumbo v0, "vcard_row_id"

    invoke-static {v2, v0, v3, v4}, LX/0yL;->A0m(Landroid/content/ContentValues;Ljava/lang/String;J)V

    const-string/jumbo v1, "vcard_jid"

    iget-object v0, v15, LX/5LJ;->A01:Lcom/whatsapp/jid/UserJid;

    invoke-static {v0}, LX/38f;->A05(Lcom/whatsapp/jid/Jid;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v1, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v1, "messages_vcards_jids"

    const-string v0, "insertIntoLegacyTables/INSERT_MESSAGES_VCARDS_JIDS"

    invoke-virtual {v12, v1, v0, v2}, LX/2sd;->A06(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    goto :goto_c

    :cond_30
    invoke-virtual/range {v17 .. v17}, LX/3eL;->A00()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    :try_start_b
    invoke-virtual/range {v17 .. v17}, LX/3eL;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_2

    :try_start_c
    invoke-virtual {v11}, LX/3eM;->close()V

    :cond_31
    iget-wide v0, v8, LX/36P;->A1L:J

    invoke-virtual {v9, v10, v0, v1}, LX/31g;->A08(LX/2J2;J)V

    goto/16 :goto_b
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    :catchall_0
    move-exception v1

    :try_start_d
    invoke-virtual/range {v17 .. v17}, LX/3eL;->close()V

    goto :goto_d
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_1

    :catchall_1
    move-exception v0

    :try_start_e
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_d
    throw v1
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_2

    :catchall_2
    move-exception v1

    :try_start_f
    invoke-virtual {v11}, LX/3eM;->close()V

    goto :goto_e
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_3

    :catchall_3
    :try_start_10
    move-exception v0

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_e
    throw v1

    :cond_32
    invoke-virtual/range {v19 .. v19}, LX/3eL;->A00()V
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_4

    :try_start_11
    invoke-virtual/range {v19 .. v19}, LX/3eL;->close()V
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_6

    :try_start_12
    invoke-virtual/range {v20 .. v20}, LX/3eM;->close()V

    goto :goto_12
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_9

    :catchall_4
    move-exception v1

    :try_start_13
    invoke-virtual/range {v19 .. v19}, LX/3eL;->close()V

    goto :goto_f
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_5

    :catchall_5
    move-exception v0

    :try_start_14
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_f
    throw v1
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_6

    :catchall_6
    move-exception v1

    :try_start_15
    invoke-virtual/range {v20 .. v20}, LX/3eM;->close()V

    goto :goto_10
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_8

    :cond_33
    :try_start_16
    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageTokenizationJob;

    check-cast v2, Ljava/lang/String;

    iget-object v5, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageTokenizationJob;->A00:LX/3QZ;

    invoke-virtual {v5}, LX/3QZ;->A03()J

    move-result-wide v6

    iget-wide v3, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;->sortId:J

    iget-wide v0, v0, Lcom/gbwhatsapp/jobqueue/job/messagejob/AsyncMessageJob;->rowId:J

    const/4 v15, 0x1

    new-instance v14, LX/2vq;

    move-wide/from16 v16, v3

    move-wide/from16 v18, v0

    invoke-direct/range {v14 .. v19}, LX/2vq;-><init>(IJJ)V

    iget-object v0, v5, LX/3QZ;->A0F:LX/3jF;

    invoke-virtual {v0}, LX/3jF;->A03()LX/3eM;

    move-result-object v3
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_9

    :try_start_17
    invoke-static {v15}, LX/0yU;->A02(I)Landroid/content/ContentValues;

    move-result-object v9

    const-string v0, "content"

    invoke-virtual {v9, v0, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v8, v3, LX/3eM;->A02:LX/2sd;

    const-string/jumbo v10, "message_ftsv2"

    const-string v11, "docid = ?"

    new-array v13, v15, [Ljava/lang/String;

    iget-wide v0, v14, LX/2vq;->A02:J

    invoke-static {v13, v0, v1}, LX/0yK;->A1W([Ljava/lang/Object;J)V

    const-string v12, "UPDATE_FTS_TEXT"

    invoke-virtual/range {v8 .. v13}, LX/2sd;->A04(Landroid/content/ContentValues;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_7

    :try_start_18
    invoke-virtual {v3}, LX/3eM;->close()V

    const-wide/16 v3, 0x1

    cmp-long v0, v6, v3

    if-nez v0, :cond_34

    goto :goto_11
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_9

    :catchall_7
    move-exception v1

    :try_start_19
    invoke-virtual {v3}, LX/3eM;->close()V

    goto :goto_10
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_8

    :catchall_8
    :try_start_1a
    move-exception v0

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_10
    throw v1

    :goto_11
    invoke-virtual {v5, v14, v2}, LX/3QZ;->A05(LX/2vq;Ljava/lang/String;)LX/2vq;

    :cond_34
    :goto_12
    invoke-virtual/range {v21 .. v21}, LX/3eL;->A00()V
    :try_end_1a
    .catchall {:try_start_1a .. :try_end_1a} :catchall_9

    :try_start_1b
    invoke-virtual/range {v21 .. v21}, LX/3eL;->close()V
    :try_end_1b
    .catchall {:try_start_1b .. :try_end_1b} :catchall_b

    invoke-virtual/range {v22 .. v22}, LX/3eM;->close()V

    return-void

    :catchall_9
    move-exception v1

    :try_start_1c
    invoke-virtual/range {v21 .. v21}, LX/3eL;->close()V

    goto :goto_13
    :try_end_1c
    .catchall {:try_start_1c .. :try_end_1c} :catchall_a

    :catchall_a
    move-exception v0

    :try_start_1d
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_13
    throw v1
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_b

    :catchall_b
    move-exception v1

    :try_start_1e
    invoke-virtual/range {v22 .. v22}, LX/3eM;->close()V
    :try_end_1e
    .catchall {:try_start_1e .. :try_end_1e} :catchall_13

    throw v1

    :cond_35
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;

    if-eqz v1, :cond_39

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;

    const-string v1, "SyncdTableEmptyKeyCheckJob/onRun/start"

    invoke-static {v1}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;->A01:LX/36M;

    invoke-static {v1}, LX/0zm;->A02(LX/36M;)LX/3eM;

    move-result-object v4

    :try_start_1f
    iget-object v3, v4, LX/3eM;->A02:LX/2sd;

    const-string v2, "SELECT 1 as has_empty_key FROM syncd_mutations WHERE device_id = 0  AND epoch = 0  LIMIT 1 "

    const-string v1, "SyncdMutationsTable.HAS_EMPTY_KEY_EXIST_STATE"

    invoke-static {v3, v2, v1}, LX/2sd;->A02(LX/2sd;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v3
    :try_end_1f
    .catchall {:try_start_1f .. :try_end_1f} :catchall_e

    :try_start_20
    invoke-interface {v3}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    const/4 v1, 0x0

    if-eqz v2, :cond_36

    const-string v1, "has_empty_key"

    invoke-static {v3, v1}, LX/0yM;->A02(Landroid/database/Cursor;Ljava/lang/String;)I

    move-result v1
    :try_end_20
    .catchall {:try_start_20 .. :try_end_20} :catchall_c

    invoke-static {v1}, LX/0yQ;->A1U(I)Z

    move-result v1

    :cond_36
    :try_start_21
    invoke-interface {v3}, Landroid/database/Cursor;->close()V
    :try_end_21
    .catchall {:try_start_21 .. :try_end_21} :catchall_e

    invoke-virtual {v4}, LX/3eM;->close()V

    if-eqz v1, :cond_37

    const-string v1, "SyncdTableEmptyKeyCheckJob/onRun/hasEmptyKeyMutation"

    invoke-static {v1}, Lcom/whatsapp/util/Log;->e(Ljava/lang/String;)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncdTableEmptyKeyCheckJob;->A00:LX/31Z;

    const/4 v0, 0x7

    invoke-virtual {v1, v0}, LX/31Z;->A04(I)V

    return-void

    :cond_37
    const-string v0, "SyncdTableEmptyKeyCheckJob/onRun/end"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->i(Ljava/lang/String;)V

    return-void

    :catchall_c
    move-exception v1

    if-eqz v3, :cond_38

    :try_start_22
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    goto :goto_14
    :try_end_22
    .catchall {:try_start_22 .. :try_end_22} :catchall_d

    :catchall_d
    move-exception v0

    :try_start_23
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_38
    :goto_14
    throw v1
    :try_end_23
    .catchall {:try_start_23 .. :try_end_23} :catchall_e

    :catchall_e
    move-exception v1

    :try_start_24
    invoke-virtual {v4}, LX/3eM;->close()V
    :try_end_24
    .catchall {:try_start_24 .. :try_end_24} :catchall_13

    throw v1

    :cond_39
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;

    if-eqz v1, :cond_3e

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;

    iget v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;->type:I

    invoke-static {v1}, LX/001;->A1T(I)Z

    move-result v3

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;->jids:[Ljava/lang/String;

    invoke-static {v1}, LX/38f;->A0A([Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    const-string v1, "jid list is empty"

    invoke-static {v1, v2}, LX/38Z;->A0A(Ljava/lang/String;Ljava/util/Collection;)V

    :try_start_25
    iget-object v7, v0, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;->A00:LX/3GH;

    if-eqz v3, :cond_3c

    sget-object v1, LX/1vw;->A06:LX/1vw;

    :goto_15
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    new-instance v6, LX/2zx;

    invoke-direct {v6, v1}, LX/2zx;-><init>(LX/1vw;)V

    const/4 v1, 0x1

    iput-boolean v1, v6, LX/2zx;->A02:Z

    sget-object v1, LX/2y4;->A0N:LX/2y4;

    iput-object v1, v6, LX/2zx;->A00:LX/2y4;

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_3a
    :goto_16
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3d

    invoke-static {v5}, LX/0yQ;->A0V(Ljava/util/Iterator;)Lcom/whatsapp/jid/UserJid;

    move-result-object v4

    iget-object v3, v7, LX/3GH;->A0H:LX/1Pl;

    const/16 v2, 0xcef

    sget-object v1, LX/2vP;->A02:LX/2vP;

    invoke-virtual {v3, v1, v2}, LX/2sp;->A0W(LX/2vP;I)Z

    move-result v1

    if-nez v1, :cond_3b

    iget-object v1, v7, LX/3GH;->A09:LX/3J5;

    invoke-virtual {v1, v4}, LX/3J5;->A0B(LX/1ZJ;)LX/3ep;

    :cond_3b
    if-eqz v4, :cond_3a

    iget-object v1, v6, LX/2zx;->A07:Ljava/util/Set;

    invoke-interface {v1, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_16

    :cond_3c
    sget-object v1, LX/1vw;->A07:LX/1vw;

    goto :goto_15

    :cond_3d
    invoke-virtual {v6}, LX/2zx;->A02()LX/308;

    move-result-object v2

    const/4 v1, 0x0

    invoke-virtual {v7, v2, v1}, LX/3GH;->A03(LX/308;Z)LX/3iz;

    move-result-object v1

    invoke-virtual {v1}, LX/3iz;->get()Ljava/lang/Object;

    return-void
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_25 .. :try_end_25} :catch_2

    :catch_2
    move-exception v3

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "SyncProfilePictureJob/onRun/error, param="

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SyncProfilePictureJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1G(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    throw v3

    :cond_3e
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;

    if-eqz v1, :cond_3f

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;

    :try_start_26
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "SyncDevicesJob/onRun/start sync device. param="

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->A00:LX/3GH;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->jids:[Ljava/lang/String;

    invoke-static {v1}, LX/38f;->A0A([Ljava/lang/String;)Ljava/util/List;

    move-result-object v5

    const-string v1, "jid list is empty"

    invoke-static {v1, v5}, LX/38Z;->A0A(Ljava/lang/String;Ljava/util/Collection;)V

    iget v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->syncType:I

    packed-switch v1, :pswitch_data_0

    sget-object v4, LX/1vw;->A0C:LX/1vw;

    :goto_17
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    sget-object v3, LX/2y4;->A0H:LX/2y4;

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual/range {v2 .. v7}, LX/3GH;->A02(LX/2y4;LX/1vw;Ljava/util/Collection;ZZ)LX/3iz;

    move-result-object v1

    invoke-virtual {v1}, LX/3iz;->get()Ljava/lang/Object;

    goto :goto_18

    :pswitch_0
    sget-object v4, LX/1vw;->A0G:LX/1vw;

    goto :goto_17

    :pswitch_1
    sget-object v4, LX/1vw;->A0I:LX/1vw;

    goto :goto_17

    :pswitch_2
    sget-object v4, LX/1vw;->A05:LX/1vw;

    goto :goto_17

    :pswitch_3
    sget-object v4, LX/1vw;->A0N:LX/1vw;

    goto :goto_17

    :pswitch_4
    sget-object v4, LX/1vw;->A0F:LX/1vw;

    goto :goto_17

    :pswitch_5
    sget-object v4, LX/1vw;->A0E:LX/1vw;

    goto :goto_17
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_26 .. :try_end_26} :catch_3
    .catchall {:try_start_26 .. :try_end_26} :catchall_f

    :goto_18
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->A01:LX/2fx;

    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->jids:[Ljava/lang/String;

    invoke-virtual {v1, v0}, LX/2fx;->A00([Ljava/lang/String;)V

    return-void

    :catch_3
    move-exception v3

    :try_start_27
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "SyncDevicesJob/onRun/error, param="

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1G(Ljava/lang/StringBuilder;Ljava/lang/String;)V
    :try_end_27
    .catchall {:try_start_27 .. :try_end_27} :catchall_f

    :try_start_28
    throw v3
    :try_end_28
    .catchall {:try_start_28 .. :try_end_28} :catchall_16

    :catchall_f
    move-exception v2

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->A01:LX/2fx;

    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesJob;->jids:[Ljava/lang/String;

    invoke-virtual {v1, v0}, LX/2fx;->A00([Ljava/lang/String;)V

    throw v2

    :cond_3f
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;

    if-eqz v1, :cond_40

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "SyncDevicesAndSendInvisibleMessageJob/onRun/param="

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    :try_start_29
    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A00:LX/3GH;

    iget-object v5, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A05:Ljava/util/Set;

    const-string v1, "jid list is empty"

    invoke-static {v1, v5}, LX/38Z;->A0A(Ljava/lang/String;Ljava/util/Collection;)V

    sget-object v4, LX/1vw;->A0G:LX/1vw;

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    sget-object v3, LX/2y4;->A0H:LX/2y4;

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual/range {v2 .. v7}, LX/3GH;->A02(LX/2y4;LX/1vw;Ljava/util/Collection;ZZ)LX/3iz;

    move-result-object v1

    invoke-virtual {v1}, LX/3iz;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LX/30i;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "SyncDevicesAndSendInvisibleMessageJob/onRun/sync is success="

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, LX/30i;->A00()Z

    move-result v1

    invoke-static {v2, v1}, LX/0yK;->A1U(Ljava/lang/StringBuilder;Z)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->rawGroupJid:Ljava/lang/String;

    invoke-static {v1}, LX/33R;->A02(Ljava/lang/String;)Lcom/whatsapp/jid/GroupJid;

    move-result-object v2

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->messageId:Ljava/lang/String;

    invoke-static {v2, v1, v6}, LX/30N;->A05(LX/1ZJ;Ljava/lang/String;Z)LX/30N;

    move-result-object v5

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A02:LX/2sJ;

    invoke-virtual {v1}, LX/2sJ;->A0H()J

    move-result-wide v3

    new-instance v2, LX/1f4;

    invoke-direct {v2, v5, v3, v4}, LX/1f4;-><init>(LX/30N;J)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A03:LX/3Qa;

    invoke-virtual {v1, v2}, LX/3Qa;->A0X(LX/36P;)V

    return-void
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_29 .. :try_end_29} :catch_4

    :catch_4
    move-exception v3

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "SyncDevicesAndSendInvisibleMessageJob/onRun/error, param="

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SyncDevicesAndSendInvisibleMessageJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1G(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    throw v3

    :cond_40
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;

    if-eqz v1, :cond_45

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;->jids:[Ljava/lang/String;

    invoke-static {v1}, LX/38f;->A0A([Ljava/lang/String;)Ljava/util/List;

    move-result-object v6

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;->A00:LX/1cv;

    iget v2, v1, LX/1cv;->A04:I

    const/4 v1, 0x2

    invoke-static {v2, v1}, LX/000;->A1U(II)Z

    move-result v1

    const/4 v5, 0x0

    if-eqz v1, :cond_41

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;->A00:LX/1cv;

    invoke-virtual {v1}, LX/1cv;->A09()Z

    move-result v1

    const/4 v4, 0x1

    if-eqz v1, :cond_42

    :cond_41
    const/4 v4, 0x0

    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_42

    return-void

    :cond_42
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;->A02:LX/354;

    invoke-static {v1}, LX/0yM;->A0C(LX/354;)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-static {}, LX/001;->A0z()Ljava/util/HashSet;

    move-result-object v1

    const-string v3, "adv_validating_users_to_sync"

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v2

    invoke-static {v2}, LX/38Z;->A07(Ljava/lang/Object;)V

    new-array v1, v5, [Ljava/lang/String;

    invoke-interface {v2, v1}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/String;

    invoke-static {v1}, LX/38f;->A0A([Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    invoke-static {v1}, LX/0yT;->A1B(Ljava/util/Collection;)Ljava/util/HashSet;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    move-result v1

    if-eqz v1, :cond_43

    invoke-static {v7}, LX/38f;->A0N(Ljava/util/Collection;)[Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, LX/0yM;->A0f([Ljava/lang/Object;)Ljava/util/HashSet;

    move-result-object v2

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;->A02:LX/354;

    invoke-static {v1}, LX/0yL;->A04(LX/354;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-static {v1, v3, v2}, LX/0yP;->A0u(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/util/Set;)V

    :cond_43
    invoke-virtual {v7}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_9c

    if-eqz v4, :cond_9c

    :try_start_2a
    iget-object v4, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;->A01:LX/3GH;

    sget-object v6, LX/1vw;->A05:LX/1vw;

    invoke-interface {v7}, Ljava/util/Collection;->size()I

    sget-object v5, LX/2y4;->A0H:LX/2y4;

    const/4 v8, 0x1

    move v9, v8

    invoke-virtual/range {v4 .. v9}, LX/3GH;->A02(LX/2y4;LX/1vw;Ljava/util/Collection;ZZ)LX/3iz;

    move-result-object v1

    invoke-virtual {v1}, LX/3iz;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LX/30i;

    invoke-virtual {v1}, LX/30i;->A00()Z

    move-result v1

    if-eqz v1, :cond_44

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;->A02:LX/354;

    invoke-static {v1, v3}, LX/0yK;->A0O(LX/354;Ljava/lang/String;)V

    goto :goto_19
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_2a .. :try_end_2a} :catch_5

    :catch_5
    move-exception v3

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "DeviceSyncManager/syncDeviceForAdvValidation/error ex="

    invoke-static {v2, v1, v3}, LX/0yK;->A1O(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/Object;)V

    :cond_44
    :goto_19
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;->A02:LX/354;

    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/SyncDeviceForAdvValidationJob;->A03:LX/31v;

    iget-object v0, v0, LX/31v;->A02:LX/2sJ;

    invoke-virtual {v0}, LX/2sJ;->A0F()J

    move-result-wide v2

    invoke-static {v1}, LX/0yL;->A04(LX/354;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v0, "adv_last_device_job_ts"

    invoke-static {v1, v0, v2, v3}, LX/0yL;->A0r(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;J)V

    return-void

    :cond_45
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;

    if-eqz v1, :cond_4d

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;

    sget-wide v4, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A01:J

    iget-wide v2, v0, Lorg/whispersystems/jobqueue/Job;->A01:J

    cmp-long v1, v4, v2

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    if-eqz v1, :cond_46

    const-string/jumbo v1, "skip send status privacy job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "; lastJobId="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-wide v0, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A01:J

    invoke-static {v2, v0, v1}, LX/0yK;->A1F(Ljava/lang/StringBuilder;J)V

    return-void

    :cond_46
    const-string/jumbo v1, "run send status privacy job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    invoke-static {}, LX/0yU;->A0c()Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v15

    iget-object v13, v0, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A00:LX/2wL;

    iget v14, v0, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->statusDistribution:I

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->jids:Ljava/util/Collection;

    if-nez v2, :cond_47

    const/4 v12, 0x0

    :goto_1a
    const/4 v1, 0x6

    new-instance v11, LX/49d;

    invoke-direct {v11, v15, v1, v0}, LX/49d;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    new-instance v10, LX/15f;

    invoke-direct {v10}, LX/15f;-><init>()V

    iget-object v1, v13, LX/2wL;->A03:LX/34u;

    move-object/from16 v16, v1

    invoke-virtual/range {v16 .. v16}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v9

    const/16 v20, 0x78

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x0

    if-eqz v12, :cond_48

    invoke-virtual {v12}, Ljava/util/AbstractCollection;->size()I

    move-result v1

    if-lez v1, :cond_48

    invoke-virtual {v12}, Ljava/util/AbstractCollection;->size()I

    move-result v1

    new-array v5, v1, [LX/381;

    const/4 v4, 0x0

    :goto_1b
    invoke-virtual {v12}, Ljava/util/AbstractCollection;->size()I

    move-result v1

    if-ge v4, v1, :cond_49

    new-array v3, v7, [LX/3C7;

    invoke-virtual {v12, v4}, Ljava/util/AbstractList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/whatsapp/jid/Jid;

    const-string v1, "jid"

    invoke-static {v2, v1, v3, v8}, LX/3C7;->A04(Lcom/whatsapp/jid/Jid;Ljava/lang/String;[Ljava/lang/Object;I)V

    const-string/jumbo v1, "user"

    invoke-static {v1, v3, v5, v4}, LX/381;->A0V(Ljava/lang/String;[LX/3C7;[Ljava/lang/Object;I)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_1b

    :cond_47
    const-class v1, LX/1ZJ;

    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v12

    invoke-static {v1, v2, v12}, LX/38f;->A0D(Ljava/lang/Class;Ljava/util/Collection;Ljava/util/Collection;)V

    goto :goto_1a

    :cond_48
    move-object v5, v6

    :cond_49
    new-array v3, v7, [LX/3C7;

    if-nez v14, :cond_4a

    const-string v2, "contacts"

    :goto_1c
    const-string/jumbo v1, "type"

    invoke-static {v1, v2, v3, v8}, LX/3C7;->A0B(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;I)V

    const-string/jumbo v1, "list"

    invoke-static {v1, v3, v5}, LX/381;->A0K(Ljava/lang/String;[LX/3C7;[LX/381;)LX/381;

    move-result-object v2

    const-string/jumbo v1, "privacy"

    invoke-static {v2, v1, v6}, LX/381;->A0G(LX/381;Ljava/lang/String;[LX/3C7;)LX/381;

    move-result-object v4

    invoke-static {v9, v8}, LX/3C7;->A0J(Ljava/lang/String;I)[LX/3C7;

    move-result-object v3

    const-string/jumbo v2, "xmlns"

    const-string/jumbo v1, "status"

    invoke-static {v2, v1, v3, v7}, LX/3C7;->A0B(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;I)V

    const-string/jumbo v1, "set"

    invoke-static {v1, v3}, LX/3C7;->A0E(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-static {v4, v3}, LX/381;->A0H(LX/381;[LX/3C7;)LX/381;

    move-result-object v18

    const/16 v2, 0x13

    new-instance v1, LX/49W;

    invoke-direct {v1, v11, v13, v10, v2}, LX/49W;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-wide/16 v21, 0x7d00

    move-object/from16 v17, v1

    move-object/from16 v19, v9

    invoke-virtual/range {v16 .. v22}, LX/34u;->A0L(LX/43r;LX/381;Ljava/lang/String;IJ)Z

    invoke-virtual {v10}, LX/6gB;->get()Ljava/lang/Object;

    invoke-virtual {v15}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v3

    const/16 v1, 0x1f4

    if-eq v3, v1, :cond_4c

    if-eqz v3, :cond_9c

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "server error code returned during send status privacy job; errorCode="

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_4a
    if-ne v14, v7, :cond_4b

    const-string/jumbo v2, "whitelist"

    goto :goto_1c

    :cond_4b
    const-string v2, "blacklist"

    goto :goto_1c

    :cond_4c
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "server 500 error during send status privacy job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendStatusPrivacyListJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v1

    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_4d
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;

    if-eqz v1, :cond_52

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;

    iget v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->localRegistrationId:I

    invoke-static {v1}, LX/37n;->A01(I)[B

    move-result-object v19

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->jid:Ljava/lang/String;

    sget-object v2, Lcom/whatsapp/jid/Jid;->Companion:LX/33S;

    invoke-virtual {v2, v1}, LX/33S;->A04(Ljava/lang/String;)Lcom/whatsapp/jid/Jid;

    move-result-object v12

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->participant:Ljava/lang/String;

    invoke-virtual {v2, v1}, LX/33S;->A04(Ljava/lang/String;)Lcom/whatsapp/jid/Jid;

    move-result-object v13

    const/4 v5, 0x0

    invoke-static {v5, v12, v13}, LX/37Y;->A05(Lcom/whatsapp/jid/DeviceJid;Lcom/whatsapp/jid/Jid;Lcom/whatsapp/jid/Jid;)Landroid/util/Pair;

    move-result-object v3

    new-instance v2, LX/2hl;

    invoke-direct {v2}, LX/2hl;-><init>()V

    iget-object v1, v3, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Lcom/whatsapp/jid/Jid;

    iput-object v1, v2, LX/2hl;->A02:Lcom/whatsapp/jid/Jid;

    const-string/jumbo v1, "receipt"

    iput-object v1, v2, LX/2hl;->A05:Ljava/lang/String;

    const-string/jumbo v1, "retry"

    iput-object v1, v2, LX/2hl;->A08:Ljava/lang/String;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->id:Ljava/lang/String;

    iput-object v1, v2, LX/2hl;->A07:Ljava/lang/String;

    iget-object v1, v3, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Lcom/whatsapp/jid/Jid;

    iput-object v1, v2, LX/2hl;->A01:Lcom/whatsapp/jid/Jid;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->category:Ljava/lang/String;

    if-eqz v1, :cond_4e

    iput-object v1, v2, LX/2hl;->A04:Ljava/lang/String;

    :cond_4e
    invoke-virtual {v2}, LX/2hl;->A01()LX/3C4;

    move-result-object v3

    iget v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->retryCount:I

    const/16 v23, 0x1

    if-lez v1, :cond_51

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->A02:LX/351;

    invoke-virtual {v1}, LX/351;->A0X()Z

    move-result v1

    if-eqz v1, :cond_50

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->A08()Landroid/util/Pair;

    move-result-object v1

    :goto_1d
    iget-object v4, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v4, [B

    iget-object v2, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v2, [LX/2LU;

    const/4 v1, 0x0

    aget-object v15, v2, v1

    aget-object v16, v2, v23

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->A00:LX/2sr;

    invoke-virtual {v1}, LX/2sr;->A0X()Z

    move-result v1

    if-eqz v1, :cond_4f

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->A01:LX/2pp;

    invoke-virtual {v1}, LX/2pp;->A03()[B

    move-result-object v5

    :cond_4f
    iget-object v10, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->id:Ljava/lang/String;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->recipientJid:Ljava/lang/String;

    invoke-static {v1}, LX/33V;->A05(Ljava/lang/String;)Lcom/whatsapp/jid/UserJid;

    move-result-object v14

    iget-wide v6, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->timestamp:J

    iget v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->retryCount:I

    add-int v23, v23, v1

    const/16 v22, 0x5

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->loggableStanzaId:J

    iget-object v9, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->category:Ljava/lang/String;

    iget v8, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->retryErrorCode:I

    new-instance v11, LX/2S5;

    move/from16 v24, v8

    move-wide/from16 v25, v6

    move-wide/from16 v27, v1

    move-object/from16 v20, v4

    move-object/from16 v21, v5

    move-object/from16 v18, v9

    move-object/from16 v17, v10

    invoke-direct/range {v11 .. v28}, LX/2S5;-><init>(Lcom/whatsapp/jid/Jid;Lcom/whatsapp/jid/Jid;Lcom/whatsapp/jid/UserJid;LX/2LU;LX/2LU;Ljava/lang/String;Ljava/lang/String;[B[B[BBIIJJ)V

    :goto_1e
    iget-object v4, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->A05:LX/2aZ;

    const/4 v2, 0x0

    const/16 v1, 0xb

    const/4 v0, 0x0

    invoke-static {v2, v0, v1, v0, v11}, Landroid/os/Message;->obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    iget-object v0, v1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, LX/2S5;

    invoke-virtual {v4, v0}, LX/2aZ;->A00(LX/2S5;)V

    iget-object v0, v4, LX/2aZ;->A04:LX/34u;

    invoke-virtual {v0, v1, v3}, LX/34u;->A06(Landroid/os/Message;LX/3C4;)Ljava/util/concurrent/Future;

    move-result-object v0

    :goto_1f
    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    return-void

    :cond_50
    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->A03:LX/2f6;

    const/16 v1, 0xb

    invoke-static {v2, v0, v1}, LX/2f6;->A00(LX/2f6;Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/util/Pair;

    goto :goto_1d

    :cond_51
    iget-object v8, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->id:Ljava/lang/String;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->recipientJid:Ljava/lang/String;

    invoke-static {v1}, LX/33V;->A05(Ljava/lang/String;)Lcom/whatsapp/jid/UserJid;

    move-result-object v14

    iget-wide v4, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->timestamp:J

    iget v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->retryCount:I

    add-int v23, v23, v1

    const/4 v15, 0x0

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->loggableStanzaId:J

    iget-object v7, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->category:Ljava/lang/String;

    iget v6, v0, Lcom/gbwhatsapp/jobqueue/job/SendRetryReceiptJob;->retryErrorCode:I

    const/16 v22, 0x0

    new-instance v11, LX/2S5;

    move-object/from16 v20, v15

    move-object/from16 v21, v15

    move-object/from16 v16, v15

    move/from16 v24, v6

    move-wide/from16 v25, v4

    move-wide/from16 v27, v1

    move-object/from16 v18, v7

    move-object/from16 v17, v8

    invoke-direct/range {v11 .. v28}, LX/2S5;-><init>(Lcom/whatsapp/jid/Jid;Lcom/whatsapp/jid/Jid;Lcom/whatsapp/jid/UserJid;LX/2LU;LX/2LU;Ljava/lang/String;Ljava/lang/String;[B[B[BBIIJJ)V

    goto :goto_1e

    :cond_52
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;

    if-eqz v1, :cond_56

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->A08()Ljava/lang/String;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->jid:Ljava/lang/String;

    sget-object v2, LX/1ZJ;->A00:LX/33Q;

    invoke-virtual {v2, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v7

    instance-of v1, v7, LX/1ZB;

    if-eqz v1, :cond_55

    const/4 v8, 0x0

    :goto_20
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->remoteSender:Ljava/lang/String;

    invoke-static {v1}, Lcom/whatsapp/jid/DeviceJid;->getNullable(Ljava/lang/String;)Lcom/whatsapp/jid/DeviceJid;

    move-result-object v9

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->recipient:Ljava/lang/String;

    invoke-static {v1}, LX/33V;->A05(Ljava/lang/String;)Lcom/whatsapp/jid/UserJid;

    move-result-object v10

    iget-object v11, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->A01:LX/2qw;

    iget-object v5, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->messageIds:[Ljava/lang/String;

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->originalMessageTimestamp:J

    iget-boolean v4, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->shouldForceReadSelfReceipt:Z

    iget-object v3, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->A03:Ljava/lang/Throwable;

    move-object v12, v7

    move-object v13, v3

    move-object v14, v5

    move-wide v15, v1

    move/from16 v17, v4

    invoke-virtual/range {v11 .. v17}, LX/2qw;->A04(LX/1ZJ;Ljava/lang/Throwable;[Ljava/lang/String;JZ)Z

    move-result v1

    if-eqz v1, :cond_9c

    iget-object v6, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->A01:LX/2qw;

    iget-object v11, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->messageIds:[Ljava/lang/String;

    iget-boolean v14, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->shouldForceReadSelfReceipt:Z

    iget-wide v12, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->loggableStanzaId:J

    invoke-virtual/range {v6 .. v14}, LX/2qw;->A00(LX/1ZJ;LX/1ZJ;Lcom/whatsapp/jid/DeviceJid;Lcom/whatsapp/jid/UserJid;[Ljava/lang/String;JZ)LX/2Qi;

    move-result-object v6

    invoke-static {v9, v7, v8}, LX/37Y;->A05(Lcom/whatsapp/jid/DeviceJid;Lcom/whatsapp/jid/Jid;Lcom/whatsapp/jid/Jid;)Landroid/util/Pair;

    move-result-object v4

    new-instance v3, LX/2hl;

    invoke-direct {v3}, LX/2hl;-><init>()V

    iget-object v1, v4, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Lcom/whatsapp/jid/Jid;

    iput-object v1, v3, LX/2hl;->A02:Lcom/whatsapp/jid/Jid;

    invoke-static {v7}, Lcom/abuarab/gold/Gold;->CheckHideRead(LX/1ZJ;)Z

    move-result v1

    if-eqz v1, :cond_53

    return-void

    :cond_53
    const-string/jumbo v1, "receipt"

    iput-object v1, v3, LX/2hl;->A05:Ljava/lang/String;

    iget-object v1, v6, LX/2Qi;->A06:Ljava/lang/String;

    iput-object v1, v3, LX/2hl;->A08:Ljava/lang/String;

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->messageIds:[Ljava/lang/String;

    const/4 v1, 0x0

    aget-object v1, v2, v1

    iput-object v1, v3, LX/2hl;->A07:Ljava/lang/String;

    iget-object v1, v4, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Lcom/whatsapp/jid/Jid;

    iput-object v1, v3, LX/2hl;->A01:Lcom/whatsapp/jid/Jid;

    iput-object v10, v3, LX/2hl;->A03:Lcom/whatsapp/jid/UserJid;

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->loggableStanzaId:J

    iput-wide v1, v3, LX/2hl;->A00:J

    invoke-virtual {v3}, LX/2hl;->A01()LX/3C4;

    move-result-object v5

    iget-object v4, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->A02:LX/2qy;

    iget-wide v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->loggableStanzaId:J

    const/4 v1, 0x0

    invoke-virtual {v4, v1, v2, v3}, LX/2qy;->A01(IJ)LX/2ra;

    move-result-object v2

    if-eqz v2, :cond_54

    const/4 v1, 0x6

    invoke-virtual {v2, v1}, LX/2ra;->A03(I)V

    :cond_54
    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->A00:LX/34u;

    const/16 v1, 0x59

    invoke-static {v1, v6}, LX/0yP;->A0F(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v2, v1, v5}, LX/34u;->A06(Landroid/os/Message;LX/3C4;)Ljava/util/concurrent/Future;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->A08()Ljava/lang/String;

    return-void

    :cond_55
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendReadReceiptJob;->participant:Ljava/lang/String;

    invoke-virtual {v2, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v8

    goto/16 :goto_20

    :cond_56
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;

    if-eqz v1, :cond_5c

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->toRawJid:Ljava/lang/String;

    invoke-static {v1}, LX/33Q;->A03(Ljava/lang/String;)LX/1ZJ;

    move-result-object v4

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->participantRawJid:Ljava/lang/String;

    sget-object v2, LX/1ZJ;->A00:LX/33Q;

    invoke-virtual {v2, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v3

    const/4 v1, 0x0

    invoke-static {v1, v4, v3}, LX/37Y;->A05(Lcom/whatsapp/jid/DeviceJid;Lcom/whatsapp/jid/Jid;Lcom/whatsapp/jid/Jid;)Landroid/util/Pair;

    move-result-object v3

    iget-object v4, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->A02:LX/2qw;

    iget-object v1, v3, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Lcom/whatsapp/jid/Jid;

    invoke-static {v1}, LX/33Q;->A01(Lcom/whatsapp/jid/Jid;)LX/1ZJ;

    move-result-object v1

    invoke-virtual {v4, v1}, LX/2qw;->A02(LX/1ZJ;)Z

    move-result v1

    const/4 v7, 0x0

    if-eqz v1, :cond_59

    iget-object v1, v3, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Lcom/whatsapp/jid/Jid;

    invoke-static {v1}, LX/33Q;->A01(Lcom/whatsapp/jid/Jid;)LX/1ZJ;

    move-result-object v1

    instance-of v1, v1, LX/1Z7;

    if-nez v1, :cond_59

    const/4 v1, 0x1

    const-string/jumbo v8, "played"

    :goto_21
    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->A08()Ljava/lang/String;

    if-nez v1, :cond_5b

    iget-object v13, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->A00:LX/2G9;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->toRawJid:Ljava/lang/String;

    invoke-static {v1}, LX/33Q;->A03(Ljava/lang/String;)LX/1ZJ;

    move-result-object v5

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->participantRawJid:Ljava/lang/String;

    invoke-virtual {v2, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v4

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->messageRowIds:[Ljava/lang/Long;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->messageIds:[Ljava/lang/String;

    new-instance v12, LX/2Zx;

    invoke-direct {v12, v5, v4, v2, v1}, LX/2Zx;-><init>(LX/1ZJ;LX/1ZJ;[Ljava/lang/Long;[Ljava/lang/String;)V

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "PlayedSelfReceiptStore/insertPlayedSelfReceipt/toJid = "

    invoke-static {v2, v1, v12}, LX/0yK;->A1L(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/Object;)V

    invoke-static {}, LX/0yT;->A0C()Landroid/content/ContentValues;

    move-result-object v11

    const/4 v6, 0x0

    :goto_22
    iget-object v4, v12, LX/2Zx;->A03:[Ljava/lang/String;

    array-length v1, v4

    if-ge v6, v1, :cond_5a

    invoke-virtual {v11}, Landroid/content/ContentValues;->clear()V

    iget-object v5, v13, LX/2G9;->A00:LX/36H;

    iget-object v1, v12, LX/2Zx;->A01:LX/1ZJ;

    invoke-static {v5, v1}, LX/36H;->A03(LX/36H;Lcom/whatsapp/jid/Jid;)Ljava/lang/Long;

    move-result-object v2

    const-string/jumbo v1, "to_jid_row_id"

    invoke-virtual {v11, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    iget-object v1, v12, LX/2Zx;->A00:LX/1ZJ;

    if-eqz v1, :cond_57

    invoke-static {v5, v1}, LX/36H;->A03(LX/36H;Lcom/whatsapp/jid/Jid;)Ljava/lang/Long;

    move-result-object v2

    const-string/jumbo v1, "participant_jid_row_id"

    invoke-virtual {v11, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    :cond_57
    iget-object v1, v12, LX/2Zx;->A02:[Ljava/lang/Long;

    aget-object v2, v1, v6

    const-string/jumbo v1, "message_row_id"

    invoke-virtual {v11, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    aget-object v2, v4, v6

    const-string/jumbo v1, "message_id"

    invoke-virtual {v11, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v1, v13, LX/2G9;->A01:LX/3jF;

    invoke-virtual {v1}, LX/3jF;->A03()LX/3eM;

    move-result-object v2

    :try_start_2b
    invoke-virtual {v2}, LX/3eM;->A04()LX/3eL;

    move-result-object v14
    :try_end_2b
    .catchall {:try_start_2b .. :try_end_2b} :catchall_12

    :try_start_2c
    iget-object v5, v2, LX/3eM;->A02:LX/2sd;

    const-string/jumbo v4, "played_self_receipt"

    const-string v1, "PlayedSelfReceiptStore/INSERT_PLAYED_SELF_RECEIPT"

    invoke-virtual {v5, v4, v1, v11}, LX/2sd;->A06(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    move-result-wide v9

    const-wide/16 v4, -0x1

    cmp-long v1, v9, v4

    if-nez v1, :cond_58

    const-string v1, "PlayedSelfReceiptStore/insertPlayedSelfReceipt fail to insert"

    invoke-static {v1}, Lcom/whatsapp/util/Log;->w(Ljava/lang/String;)V

    :cond_58
    invoke-virtual {v14}, LX/3eL;->A00()V
    :try_end_2c
    .catchall {:try_start_2c .. :try_end_2c} :catchall_10

    :try_start_2d
    invoke-virtual {v14}, LX/3eL;->close()V
    :try_end_2d
    .catchall {:try_start_2d .. :try_end_2d} :catchall_12

    invoke-virtual {v2}, LX/3eM;->close()V

    add-int/lit8 v6, v6, 0x1

    goto :goto_22

    :cond_59
    const/4 v1, 0x0

    const-string/jumbo v8, "played-self"

    goto/16 :goto_21

    :cond_5a
    iget-boolean v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->playedSelfFromPeer:Z

    if-eqz v1, :cond_5b

    return-void

    :cond_5b
    new-instance v2, LX/2hl;

    invoke-direct {v2}, LX/2hl;-><init>()V

    iget-object v1, v3, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Lcom/whatsapp/jid/Jid;

    iput-object v1, v2, LX/2hl;->A02:Lcom/whatsapp/jid/Jid;

    const-string/jumbo v1, "receipt"

    iput-object v1, v2, LX/2hl;->A05:Ljava/lang/String;

    iput-object v8, v2, LX/2hl;->A08:Ljava/lang/String;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->messageIds:[Ljava/lang/String;

    aget-object v1, v1, v7

    iput-object v1, v2, LX/2hl;->A07:Ljava/lang/String;

    iget-object v1, v3, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Lcom/whatsapp/jid/Jid;

    iput-object v1, v2, LX/2hl;->A01:Lcom/whatsapp/jid/Jid;

    invoke-virtual {v2}, LX/2hl;->A01()LX/3C4;

    move-result-object v6

    iget-object v5, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->A01:LX/34u;

    iget-object v1, v3, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Lcom/whatsapp/jid/Jid;

    invoke-static {v1}, LX/33Q;->A01(Lcom/whatsapp/jid/Jid;)LX/1ZJ;

    move-result-object v4

    iget-object v1, v3, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Lcom/whatsapp/jid/Jid;

    invoke-static {v1}, LX/33Q;->A01(Lcom/whatsapp/jid/Jid;)LX/1ZJ;

    move-result-object v3

    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJobV2;->messageIds:[Ljava/lang/String;

    const/4 v2, 0x0

    new-instance v1, LX/2NP;

    invoke-direct {v1, v4, v3, v8, v0}, LX/2NP;-><init>(LX/1ZJ;LX/1ZJ;Ljava/lang/String;[Ljava/lang/String;)V

    const/16 v0, 0x26

    invoke-static {v2, v7, v0, v7, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v5, v0, v6}, LX/34u;->A06(Landroid/os/Message;LX/3C4;)Ljava/util/concurrent/Future;

    move-result-object v0

    goto/16 :goto_1f

    :cond_5c
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;

    if-eqz v1, :cond_5f

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;->remoteJidRawJid:Ljava/lang/String;

    invoke-static {v1}, LX/33Q;->A03(Ljava/lang/String;)LX/1ZJ;

    move-result-object v9

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;->remoteResourceRawJid:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_5e

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;->remoteResourceRawJid:Ljava/lang/String;

    invoke-static {v1}, LX/33Q;->A02(Ljava/lang/String;)LX/1ZJ;

    move-result-object v2

    :goto_23
    iget-object v3, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;->messageId:Ljava/lang/String;

    instance-of v1, v2, LX/1ZQ;

    move-object v8, v2

    if-nez v1, :cond_5d

    move-object v8, v9

    move-object v9, v2

    :cond_5d
    invoke-static {v8}, LX/2hl;->A00(Lcom/whatsapp/jid/Jid;)LX/2hl;

    move-result-object v2

    const-string/jumbo v1, "receipt"

    iput-object v1, v2, LX/2hl;->A05:Ljava/lang/String;

    const-string/jumbo v7, "played"

    iput-object v7, v2, LX/2hl;->A08:Ljava/lang/String;

    iput-object v3, v2, LX/2hl;->A07:Ljava/lang/String;

    iput-object v9, v2, LX/2hl;->A01:Lcom/whatsapp/jid/Jid;

    invoke-virtual {v2}, LX/2hl;->A01()LX/3C4;

    move-result-object v6

    iget-object v5, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;->A00:LX/34u;

    invoke-static {}, LX/0yT;->A1Z()[Ljava/lang/String;

    move-result-object v4

    const/4 v3, 0x0

    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/SendPlayedReceiptJob;->messageId:Ljava/lang/String;

    aput-object v0, v4, v3

    const/4 v2, 0x0

    new-instance v1, LX/2NP;

    invoke-direct {v1, v8, v9, v7, v4}, LX/2NP;-><init>(LX/1ZJ;LX/1ZJ;Ljava/lang/String;[Ljava/lang/String;)V

    const/16 v0, 0x26

    invoke-static {v2, v3, v0, v3, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v5, v0, v6}, LX/34u;->A06(Landroid/os/Message;LX/3C4;)Ljava/util/concurrent/Future;

    move-result-object v0

    goto/16 :goto_1f

    :cond_5e
    const/4 v2, 0x0

    goto :goto_23

    :cond_5f
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;

    if-eqz v1, :cond_60

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->jid:Ljava/lang/String;

    sget-object v2, LX/1ZJ;->A00:LX/33Q;

    invoke-virtual {v2, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v3

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->participant:Ljava/lang/String;

    invoke-virtual {v2, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v6

    invoke-static {v3}, LX/2hl;->A00(Lcom/whatsapp/jid/Jid;)LX/2hl;

    move-result-object v2

    iput-object v6, v2, LX/2hl;->A01:Lcom/whatsapp/jid/Jid;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->messageKeyId:Ljava/lang/String;

    iput-object v1, v2, LX/2hl;->A07:Ljava/lang/String;

    const-string v1, "error"

    iput-object v1, v2, LX/2hl;->A08:Ljava/lang/String;

    const-string/jumbo v1, "receipt"

    iput-object v1, v2, LX/2hl;->A05:Ljava/lang/String;

    invoke-virtual {v2}, LX/2hl;->A01()LX/3C4;

    move-result-object v5

    iget-object v4, v0, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->A00:LX/34u;

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendPermanentFailureReceiptJob;->messageKeyId:Ljava/lang/String;

    const/16 v0, 0xa3

    invoke-static {v0, v3}, LX/0yP;->A0F(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v3

    invoke-virtual {v3}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v1

    const-string/jumbo v0, "messageKeyId"

    invoke-virtual {v1, v0, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v3}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v2

    const-string/jumbo v1, "remoteResource"

    invoke-static {v6}, LX/38f;->A05(Lcom/whatsapp/jid/Jid;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v1, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v4, v3, v5}, LX/34u;->A06(Landroid/os/Message;LX/3C4;)Ljava/util/concurrent/Future;

    move-result-object v0

    goto/16 :goto_1f

    :cond_60
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;

    if-eqz v1, :cond_61

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;->jid:Ljava/lang/String;

    invoke-static {v1}, LX/33Q;->A02(Ljava/lang/String;)LX/1ZJ;

    move-result-object v6

    invoke-static {v6}, LX/2hl;->A00(Lcom/whatsapp/jid/Jid;)LX/2hl;

    move-result-object v2

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;->messageKeyId:Ljava/lang/String;

    iput-object v1, v2, LX/2hl;->A07:Ljava/lang/String;

    const-string v1, "error"

    iput-object v1, v2, LX/2hl;->A08:Ljava/lang/String;

    const-string/jumbo v1, "receipt"

    iput-object v1, v2, LX/2hl;->A05:Ljava/lang/String;

    invoke-virtual {v2}, LX/2hl;->A01()LX/3C4;

    move-result-object v5

    iget-object v4, v0, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;->A00:LX/34u;

    iget-object v3, v0, Lcom/gbwhatsapp/jobqueue/job/SendOrderStatusUpdateFailureReceiptJob;->messageKeyId:Ljava/lang/String;

    const/16 v0, 0x127

    invoke-static {v0, v6}, LX/0yP;->A0F(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v1

    const-string/jumbo v0, "messageKeyId"

    invoke-virtual {v1, v0, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v4, v2, v5}, LX/34u;->A06(Landroid/os/Message;LX/3C4;)Ljava/util/concurrent/Future;

    move-result-object v0

    goto/16 :goto_1f

    :cond_61
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;

    if-eqz v1, :cond_68

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->remoteJidRawJid:Ljava/lang/String;

    sget-object v2, LX/1ZJ;->A00:LX/33Q;

    invoke-virtual {v2, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v8

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->remoteResourceRawJid:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x0

    if-nez v1, :cond_67

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->remoteResourceRawJid:Ljava/lang/String;

    invoke-virtual {v2, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v9

    :goto_24
    instance-of v2, v9, LX/1ZQ;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->myPrimaryJid:Ljava/lang/String;

    if-eqz v1, :cond_65

    const/4 v6, 0x1

    invoke-static {v1}, LX/33Q;->A03(Ljava/lang/String;)LX/1ZJ;

    move-result-object v7

    invoke-static {v8}, LX/38Z;->A07(Ljava/lang/Object;)V

    :goto_25
    invoke-static {v8}, LX/38f;->A0I(Lcom/whatsapp/jid/Jid;)Z

    move-result v1

    if-nez v1, :cond_62

    instance-of v1, v8, LX/1Z3;

    if-nez v1, :cond_62

    move-object v9, v3

    if-eqz v2, :cond_62

    move-object v9, v8

    :cond_62
    invoke-static {v7}, LX/2hl;->A00(Lcom/whatsapp/jid/Jid;)LX/2hl;

    move-result-object v2

    const-string/jumbo v1, "receipt"

    iput-object v1, v2, LX/2hl;->A05:Ljava/lang/String;

    const-string/jumbo v1, "server-error"

    iput-object v1, v2, LX/2hl;->A08:Ljava/lang/String;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->messageId:Ljava/lang/String;

    iput-object v1, v2, LX/2hl;->A07:Ljava/lang/String;

    if-nez v6, :cond_63

    move-object v3, v9

    :cond_63
    iput-object v3, v2, LX/2hl;->A01:Lcom/whatsapp/jid/Jid;

    invoke-virtual {v2}, LX/2hl;->A01()LX/3C4;

    move-result-object v3

    const/16 v1, 0xc

    invoke-static {v1}, LX/23R;->A01(I)[B

    move-result-object v12

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->messageId:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-static {v2, v1}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    new-instance v1, LX/2vC;

    invoke-direct {v1, v2}, LX/2vC;-><init>(Ljava/lang/String;)V

    iget-object v5, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->mediaKey:[B

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->messageId:Ljava/lang/String;

    invoke-static {v5, v2}, LX/0yK;->A0U(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v5, v12}, LX/2xP;->A00([B[B)V

    const/4 v4, 0x0

    iget-object v1, v1, LX/2vC;->A00:Lcom/facebook/simplejni/NativeHolder;

    invoke-static {v4, v2, v1, v5, v12}, Lcom/whatsapp/wamsys/JniBridge;->jvidispatchOOOOO(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, [B

    if-eqz v6, :cond_64

    iget-object v10, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->messageId:Ljava/lang/String;

    iget-boolean v13, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->mediaFromMe:Z

    new-instance v6, LX/2Qj;

    invoke-direct/range {v6 .. v13}, LX/2Qj;-><init>(LX/1ZJ;LX/1ZJ;LX/1ZJ;Ljava/lang/String;[B[BZ)V

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/16 v1, 0x147

    invoke-static {v4, v2, v1, v2, v6}, Landroid/os/Message;->obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    :goto_26
    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->A01:LX/34u;

    invoke-virtual {v0, v1, v3}, LX/34u;->A06(Landroid/os/Message;LX/3C4;)Ljava/util/concurrent/Future;

    move-result-object v0

    goto/16 :goto_1f

    :cond_64
    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->messageId:Ljava/lang/String;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendMediaErrorReceiptJob;->category:Ljava/lang/String;

    new-instance v5, LX/2Pz;

    move-object v6, v7

    move-object v7, v9

    move-object v8, v2

    move-object v9, v1

    move-object v10, v11

    move-object v11, v12

    invoke-direct/range {v5 .. v11}, LX/2Pz;-><init>(LX/1ZJ;LX/1ZJ;Ljava/lang/String;Ljava/lang/String;[B[B)V

    const/4 v2, 0x0

    const/16 v1, 0x4d

    invoke-static {v2, v4, v1, v4, v5}, Landroid/os/Message;->obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    goto :goto_26

    :cond_65
    const/4 v6, 0x0

    move-object v7, v8

    if-eqz v2, :cond_66

    move-object v7, v9

    :cond_66
    invoke-static {v7}, LX/38Z;->A07(Ljava/lang/Object;)V

    goto/16 :goto_25

    :cond_67
    move-object v9, v3

    goto/16 :goto_24

    :cond_68
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;

    if-eqz v1, :cond_69

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A00:LX/2sr;

    invoke-static {v1}, LX/2sr;->A05(LX/2sr;)Lcom/whatsapp/jid/PhoneUserJid;

    move-result-object v1

    new-instance v3, LX/2p8;

    invoke-direct {v3, v1}, LX/2p8;-><init>(Lcom/whatsapp/jid/UserJid;)V

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->latitude:D

    iput-wide v1, v3, LX/2p8;->A00:D

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->longitude:D

    iput-wide v1, v3, LX/2p8;->A01:D

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->timestamp:J

    iput-wide v1, v3, LX/2p8;->A05:J

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "run send final live location retry job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A04:LX/4u9;

    iget v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->timeOffset:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v2, v3, v1}, LX/368;->A02(LX/2p8;Ljava/lang/Integer;)LX/1Eb;

    move-result-object v4

    goto/16 :goto_2e

    :cond_69
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;

    if-eqz v1, :cond_6a

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A00:LX/2sr;

    invoke-static {v1}, LX/2sr;->A05(LX/2sr;)Lcom/whatsapp/jid/PhoneUserJid;

    move-result-object v1

    new-instance v9, LX/2p8;

    invoke-direct {v9, v1}, LX/2p8;-><init>(Lcom/whatsapp/jid/UserJid;)V

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->latitude:D

    iput-wide v1, v9, LX/2p8;->A00:D

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->longitude:D

    iput-wide v1, v9, LX/2p8;->A01:D

    iget-wide v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->timestamp:J

    iput-wide v1, v9, LX/2p8;->A05:J

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "run send final live location job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A09()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v10, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A04:LX/353;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->rawJid:Ljava/lang/String;

    sget-object v5, LX/1ZJ;->A00:LX/33Q;

    invoke-virtual {v5, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v2

    invoke-static {v2}, LX/38Z;->A07(Ljava/lang/Object;)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->msgId:Ljava/lang/String;

    invoke-static {v2, v1}, LX/30N;->A04(LX/1ZJ;Ljava/lang/String;)LX/30N;

    move-result-object v1

    invoke-virtual {v10, v1}, LX/353;->A08(LX/30N;)LX/1ff;

    move-result-object v8

    if-eqz v8, :cond_83

    iget-object v4, v10, LX/353;->A0R:Ljava/lang/Object;

    monitor-enter v4

    goto/16 :goto_33

    :cond_6a
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;

    if-eqz v1, :cond_6b

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;

    sget-object v2, LX/1ZJ;->A00:LX/33Q;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->jidStr:Ljava/lang/String;

    invoke-virtual {v2, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v7

    instance-of v1, v7, LX/1Z3;

    if-eqz v1, :cond_85

    iget-wide v4, v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->originalMessageTimestamp:J

    const-wide/16 v2, 0x0

    cmp-long v1, v4, v2

    if-lez v1, :cond_85

    const-wide/32 v1, 0x5265c00

    add-long/2addr v4, v1

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->A00:LX/2sJ;

    if-nez v1, :cond_84

    const-string/jumbo v0, "time"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_6b
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;

    if-eqz v1, :cond_6c

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;->rawJid:Ljava/lang/String;

    invoke-static {v1}, LX/33Q;->A02(Ljava/lang/String;)LX/1ZJ;

    move-result-object v12

    if-nez v12, :cond_89

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "skip disable live location job; invalid jid: "

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;->rawJid:Ljava/lang/String;

    invoke-static {v2, v0}, LX/0yK;->A1G(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_6c
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;

    if-eqz v1, :cond_6d

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;

    new-instance v2, LX/2hv;

    invoke-direct {v2}, LX/2hv;-><init>()V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;->A01:LX/2BY;

    iput-object v1, v2, LX/2hv;->A01:LX/2BY;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;->mediaEncHash:Ljava/lang/String;

    iput-object v1, v2, LX/2hv;->A08:Ljava/lang/String;

    const-string/jumbo v5, "md-msg-hist"

    iput-object v5, v2, LX/2hv;->A07:Ljava/lang/String;

    const/4 v8, 0x0

    iput-boolean v8, v2, LX/2hv;->A0A:Z

    invoke-virtual {v2}, LX/2hv;->A01()LX/1iu;

    move-result-object v3

    iget-object v4, v0, Lcom/gbwhatsapp/jobqueue/job/SendDeleteHistorySyncMmsJob;->A02:LX/1cD;

    const/4 v6, 0x0

    move-object v7, v6

    move v9, v8

    invoke-virtual/range {v4 .. v9}, LX/1cD;->A08(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZ)LX/2Wl;

    move-result-object v2

    new-instance v1, LX/49n;

    invoke-direct {v1, v0, v8, v3}, LX/49n;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v2, v1}, LX/2Wl;->A00(LX/3zm;)Ljava/lang/Object;

    return-void

    :cond_6d
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;

    if-eqz v1, :cond_71

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "starting rotate signed pre key job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A01:LX/351;

    invoke-virtual {v1}, LX/351;->A0X()Z

    move-result v1

    if-eqz v1, :cond_70

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A01:LX/351;

    invoke-virtual {v1}, LX/351;->A0D()LX/2LU;

    move-result-object v1

    :goto_27
    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->id:[B

    iget-object v1, v1, LX/2LU;->A01:[B

    invoke-static {v2, v1}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v1

    if-nez v1, :cond_6e

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "aborting rotate signed pre key job due to id mismatch with latest"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_28
    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_6e
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A04:LX/34u;

    invoke-virtual {v1}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v8

    invoke-static {}, LX/0yU;->A0c()Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v7

    new-instance v4, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v4}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    iget-object v6, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A04:LX/34u;

    iget-object v5, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->id:[B

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->data:[B

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->signature:[B

    new-instance v3, LX/2LU;

    invoke-direct {v3, v5, v2, v1}, LX/2LU;-><init>([B[B[B)V

    new-instance v1, LX/1fK;

    invoke-direct {v1, v0, v7, v4}, LX/1fK;-><init>(Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;Ljava/util/concurrent/atomic/AtomicInteger;Ljava/util/concurrent/atomic/AtomicReference;)V

    new-instance v2, LX/2L8;

    invoke-direct {v2, v1, v3, v8}, LX/2L8;-><init>(LX/2o1;LX/2LU;Ljava/lang/String;)V

    const/16 v1, 0x56

    invoke-static {v1, v2}, LX/0yP;->A0F(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v6, v1, v8}, LX/34u;->A07(Landroid/os/Message;Ljava/lang/String;)Ljava/util/concurrent/Future;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v3

    const/16 v1, 0x1f7

    if-eq v3, v1, :cond_8c

    const/16 v2, 0x199

    const-string/jumbo v1, "server error code returned during rotate signed pre key job; errorCode="

    if-ne v3, v2, :cond_6f

    invoke-static {v3, v1}, LX/0yL;->A0b(ILjava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [B

    if-eqz v4, :cond_9c

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A01:LX/351;

    invoke-virtual {v1}, LX/351;->A0X()Z

    move-result v1

    if-eqz v1, :cond_8b

    invoke-virtual {v0, v4}, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A09([B)V

    return-void

    :cond_6f
    if-eqz v3, :cond_9c

    invoke-static {v3, v1}, LX/0yL;->A0b(ILjava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    goto :goto_28

    :cond_70
    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A02:LX/2f6;

    const/16 v1, 0xa

    invoke-static {v2, v0, v1}, LX/2f6;->A00(LX/2f6;Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LX/2LU;

    goto/16 :goto_27

    :cond_71
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;

    if-eqz v1, :cond_73

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "ReceiptProcessingJob/onRun/start param="

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->keyId:[Ljava/lang/String;

    array-length v7, v1

    invoke-static {v7}, LX/001;->A0x(I)Ljava/util/ArrayList;

    move-result-object v5

    const/4 v6, 0x0

    const/4 v4, 0x0

    :goto_29
    if-ge v4, v7, :cond_8d

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->keyRemoteChatJidRawString:[Ljava/lang/String;

    aget-object v1, v1, v4

    invoke-static {v1}, LX/33Q;->A02(Ljava/lang/String;)LX/1ZJ;

    move-result-object v3

    if-eqz v3, :cond_72

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->keyFromMe:[Z

    aget-boolean v2, v1, v4

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->keyId:[Ljava/lang/String;

    aget-object v1, v1, v4

    invoke-static {v3, v1, v2}, LX/30N;->A05(LX/1ZJ;Ljava/lang/String;Z)LX/30N;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_72
    add-int/lit8 v4, v4, 0x1

    goto :goto_29

    :cond_73
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;

    if-eqz v1, :cond_75

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "ReceiptMultiTargetProcessingJob/onRun/start param="

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->keyRemoteChatJidRawString:Ljava/lang/String;

    invoke-static {v1}, LX/33Q;->A03(Ljava/lang/String;)LX/1ZJ;

    move-result-object v3

    iget-boolean v2, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->keyFromMe:Z

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->keyId:Ljava/lang/String;

    invoke-static {v3, v1, v2}, LX/30N;->A05(LX/1ZJ;Ljava/lang/String;Z)LX/30N;

    move-result-object v7

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->remoteJidString:Ljava/lang/String;

    invoke-static {v1}, LX/33S;->A02(Ljava/lang/String;)Lcom/whatsapp/jid/Jid;

    move-result-object v6

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->participantDeviceJidRawString:[Ljava/lang/String;

    array-length v5, v1

    invoke-static {v5}, LX/001;->A0x(I)Ljava/util/ArrayList;

    move-result-object v10

    const/4 v4, 0x0

    :goto_2a
    if-ge v4, v5, :cond_8e

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->participantDeviceJidRawString:[Ljava/lang/String;

    aget-object v1, v1, v4

    invoke-static {v1}, Lcom/whatsapp/jid/DeviceJid;->getNullable(Ljava/lang/String;)Lcom/whatsapp/jid/DeviceJid;

    move-result-object v3

    if-eqz v3, :cond_74

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->timestamp:[J

    aget-wide v1, v1, v4

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-static {v3, v1, v10}, LX/0yL;->A1E(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/AbstractCollection;)V

    :cond_74
    add-int/lit8 v4, v4, 0x1

    goto :goto_2a

    :cond_75
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;

    if-eqz v1, :cond_76

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;

    goto/16 :goto_39

    :cond_76
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/GetStatusPrivacyJob;

    if-eqz v1, :cond_79

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/GetStatusPrivacyJob;

    invoke-static {}, LX/0yU;->A0c()Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v2

    iget-object v6, v0, Lcom/gbwhatsapp/jobqueue/job/GetStatusPrivacyJob;->A02:LX/2wL;

    new-instance v5, LX/2Gn;

    invoke-direct {v5, v0, v2}, LX/2Gn;-><init>(Lcom/gbwhatsapp/jobqueue/job/GetStatusPrivacyJob;Ljava/util/concurrent/atomic/AtomicInteger;)V

    new-instance v1, LX/15f;

    invoke-direct {v1}, LX/15f;-><init>()V

    iget-object v11, v6, LX/2wL;->A03:LX/34u;

    invoke-virtual {v11}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v15

    iget-object v10, v6, LX/2wL;->A02:LX/1Pl;

    const/16 v4, 0xf05

    sget-object v3, LX/2vP;->A02:LX/2vP;

    invoke-virtual {v10, v3, v4}, LX/2sp;->A0W(LX/2vP;I)Z

    move-result v3

    if-eqz v3, :cond_77

    iget-object v9, v6, LX/2wL;->A04:LX/8CH;

    invoke-virtual {v15}, Ljava/lang/String;->hashCode()I

    move-result v8

    const v7, 0x9351b2b

    invoke-virtual {v9, v7, v8}, LX/8CH;->markerStart(II)V

    const-string v4, "iq_type"

    const/16 v3, 0x79

    invoke-virtual {v9, v7, v8, v4, v3}, LX/8CH;->markerAnnotate(IILjava/lang/String;I)V

    :cond_77
    sget-object v4, LX/2vP;->A01:LX/2vP;

    const/16 v3, 0xf03

    invoke-virtual {v10, v4, v3}, LX/2sp;->A0W(LX/2vP;I)Z

    move-result v3

    if-eqz v3, :cond_78

    iget-object v12, v6, LX/2wL;->A01:LX/2sJ;

    invoke-static {}, LX/0yU;->A0j()[LX/3C7;

    move-result-object v7

    const-string v3, "id"

    invoke-static {v3, v15, v7}, LX/3C7;->A06(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const-string/jumbo v4, "xmlns"

    const-string/jumbo v3, "status"

    invoke-static {v4, v3, v7}, LX/3C7;->A07(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const-string v3, "get"

    invoke-static {v3, v7}, LX/3C7;->A0E(Ljava/lang/String;[Ljava/lang/Object;)V

    const-string/jumbo v3, "privacy"

    invoke-static {v3}, LX/381;->A0I(Ljava/lang/String;)LX/381;

    move-result-object v3

    invoke-static {v3, v7}, LX/381;->A0H(LX/381;[LX/3C7;)LX/381;

    move-result-object v14

    const/16 v3, 0x12

    new-instance v13, LX/49W;

    invoke-direct {v13, v1, v6, v5, v3}, LX/49W;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 v16, 0x79

    const-wide/16 v18, 0x7d00

    const/4 v3, 0x1

    invoke-static {v12, v3}, LX/7nJ;->A0U(Ljava/lang/Object;I)V

    const/16 v17, 0x0

    invoke-virtual/range {v11 .. v19}, LX/34u;->A0D(LX/2sJ;LX/43r;LX/381;Ljava/lang/String;IIJ)V

    :goto_2b
    const-wide/16 v4, 0x7d00

    sget-object v3, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v1, v4, v5, v3}, LX/6gB;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v2

    const/16 v1, 0x1f4

    if-ne v2, v1, :cond_9c

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "server 500 error during get status privacy job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v1, v0}, LX/0yL;->A1I(Ljava/lang/StringBuilder;Lorg/whispersystems/jobqueue/Job;)V

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v1

    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_78
    invoke-static {}, LX/0yU;->A0j()[LX/3C7;

    move-result-object v7

    const-string v3, "id"

    invoke-static {v3, v15, v7}, LX/3C7;->A06(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const-string/jumbo v4, "xmlns"

    const-string/jumbo v3, "status"

    invoke-static {v4, v3, v7}, LX/3C7;->A07(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const-string v3, "get"

    invoke-static {v3, v7}, LX/3C7;->A0E(Ljava/lang/String;[Ljava/lang/Object;)V

    const-string/jumbo v3, "privacy"

    invoke-static {v3}, LX/381;->A0I(Ljava/lang/String;)LX/381;

    move-result-object v3

    invoke-static {v3, v7}, LX/381;->A0H(LX/381;[LX/3C7;)LX/381;

    move-result-object v10

    const/16 v4, 0x12

    new-instance v3, LX/49W;

    invoke-direct {v3, v1, v6, v5, v4}, LX/49W;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-wide/16 v13, 0x7d00

    const/16 v12, 0x79

    move-object v8, v11

    move-object v9, v3

    move-object v11, v15

    invoke-virtual/range {v8 .. v14}, LX/34u;->A0L(LX/43r;LX/381;Ljava/lang/String;IJ)Z

    goto :goto_2b

    :cond_79
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;

    if-eqz v1, :cond_7a

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A01:Lcom/whatsapp/jid/UserJid;

    if-nez v2, :cond_8f

    const-string v0, "GeneratePrivacyTokenJob/onRun Stored UserJid String was invalid"

    invoke-static {v0}, Lcom/whatsapp/util/Log;->e(Ljava/lang/String;)V

    return-void

    :cond_7a
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/DeleteAccountFromHsmServerJob;

    if-eqz v1, :cond_7b

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/DeleteAccountFromHsmServerJob;

    invoke-static {}, LX/0yU;->A0c()Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v6

    iget-object v5, v0, Lcom/gbwhatsapp/jobqueue/job/DeleteAccountFromHsmServerJob;->A01:LX/454;

    iget-object v4, v0, Lcom/gbwhatsapp/jobqueue/job/DeleteAccountFromHsmServerJob;->A00:LX/7lo;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/DeleteAccountFromHsmServerJob;->A02:Ljava/util/Random;

    new-instance v3, LX/2ym;

    invoke-direct {v3, v1}, LX/2ym;-><init>(Ljava/util/Random;)V

    new-instance v2, LX/3YS;

    invoke-direct {v2, v0, v6}, LX/3YS;-><init>(Lcom/gbwhatsapp/jobqueue/job/DeleteAccountFromHsmServerJob;Ljava/util/concurrent/atomic/AtomicInteger;)V

    new-instance v1, LX/0EB;

    invoke-direct {v1, v2, v4, v3, v5}, LX/0EB;-><init>(LX/8vJ;LX/7lo;LX/2ym;LX/454;)V

    invoke-virtual {v1}, LX/0iw;->A05()V

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v1

    if-eqz v1, :cond_9c

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v2

    const/16 v1, 0x194

    if-eq v2, v1, :cond_9c

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "retriable error during delete account from hsm server job"

    invoke-static {v1, v2}, LX/0yO;->A0t(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v1, v0}, LX/0yL;->A1I(Ljava/lang/StringBuilder;Lorg/whispersystems/jobqueue/Job;)V

    invoke-static {v1, v2}, LX/000;->A1A(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_7b
    instance-of v1, v0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;

    if-eqz v1, :cond_92

    check-cast v0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "starting bulk get pre key job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->A01:LX/34u;

    invoke-virtual {v1}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v6

    const-class v2, Lcom/whatsapp/jid/DeviceJid;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->jids:[Ljava/lang/String;

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-static {v2, v1}, LX/38f;->A09(Ljava/lang/Class;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v4

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->identityChangedJids:[Ljava/lang/String;

    if-eqz v1, :cond_7d

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-static {v2, v1}, LX/38f;->A09(Ljava/lang/Class;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v3

    :goto_2c
    iget v1, v0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->context:I

    if-eqz v1, :cond_7c

    new-instance v2, LX/1Sc;

    invoke-direct {v2}, LX/1Sc;-><init>()V

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v1

    invoke-static {v1}, LX/0yT;->A0k(Z)Ljava/lang/Boolean;

    move-result-object v1

    iput-object v1, v2, LX/1Sc;->A00:Ljava/lang/Boolean;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v1

    invoke-static {v1}, LX/0yT;->A0o(I)Ljava/lang/Long;

    move-result-object v1

    iput-object v1, v2, LX/1Sc;->A02:Ljava/lang/Long;

    iget v1, v0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->context:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iput-object v1, v2, LX/1Sc;->A01:Ljava/lang/Integer;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->A00:LX/44u;

    invoke-interface {v1, v2}, LX/44u;->Bfn(LX/3eo;)V

    :cond_7c
    iget-object v5, v0, Lcom/gbwhatsapp/jobqueue/job/BulkGetPreKeyJob;->A01:LX/34u;

    const/4 v1, 0x0

    new-array v0, v1, [Lcom/whatsapp/jid/DeviceJid;

    invoke-interface {v4, v0}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Lcom/whatsapp/jid/Jid;

    new-array v0, v1, [Lcom/whatsapp/jid/DeviceJid;

    invoke-interface {v3, v0}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Lcom/whatsapp/jid/Jid;

    const/16 v0, 0x57

    invoke-static {v0}, LX/0yS;->A08(I)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v1

    const-string v0, "id"

    invoke-virtual {v1, v0, v6}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v2}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v1

    const-string v0, "jids"

    invoke-virtual {v1, v0, v4}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    invoke-virtual {v2}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v1

    const-string v0, "identityJids"

    invoke-virtual {v1, v0, v3}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    invoke-virtual {v5, v2, v6}, LX/34u;->A07(Landroid/os/Message;Ljava/lang/String;)Ljava/util/concurrent/Future;

    move-result-object v0

    goto/16 :goto_1f

    :cond_7d
    invoke-static {}, LX/001;->A0w()Ljava/util/ArrayList;

    move-result-object v3

    goto :goto_2c

    :catchall_10
    move-exception v1

    :try_start_2e
    invoke-virtual {v14}, LX/3eL;->close()V

    goto :goto_2d
    :try_end_2e
    .catchall {:try_start_2e .. :try_end_2e} :catchall_11

    :catchall_11
    move-exception v0

    :try_start_2f
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2d
    throw v1
    :try_end_2f
    .catchall {:try_start_2f .. :try_end_2f} :catchall_12

    :catchall_12
    move-exception v1

    :try_start_30
    invoke-virtual {v2}, LX/3eM;->close()V
    :try_end_30
    .catchall {:try_start_30 .. :try_end_30} :catchall_13

    throw v1

    :catchall_13
    move-exception v0

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v1

    :goto_2e
    :try_start_31
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A02:LX/351;

    invoke-virtual {v1}, LX/351;->A0X()Z

    move-result v1

    if-eqz v1, :cond_7e

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->rawDeviceJid:Ljava/lang/String;

    invoke-static {v1}, Lcom/whatsapp/jid/DeviceJid;->getNullable(Ljava/lang/String;)Lcom/whatsapp/jid/DeviceJid;

    move-result-object v1

    invoke-static {v1}, LX/37y;->A02(Lcom/whatsapp/jid/DeviceJid;)LX/2oX;

    move-result-object v3

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A02:LX/351;

    invoke-virtual {v4}, LX/86q;->A0F()[B

    move-result-object v1

    invoke-static {v3, v2, v1}, LX/20A;->A01(LX/2oX;LX/351;[B)LX/2Yj;

    move-result-object v5

    :goto_2f
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->rawDeviceJid:Ljava/lang/String;

    invoke-static {v1}, Lcom/whatsapp/jid/DeviceJid;->getNullable(Ljava/lang/String;)Lcom/whatsapp/jid/DeviceJid;

    move-result-object v1

    invoke-static {v1}, LX/38Z;->A07(Ljava/lang/Object;)V

    iget-object v3, v1, Lcom/whatsapp/jid/DeviceJid;->userJid:Lcom/whatsapp/jid/UserJid;

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A05:LX/30V;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->contextRawJid:Ljava/lang/String;

    if-nez v1, :cond_7f

    goto :goto_30

    :cond_7e
    iget-object v3, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A03:LX/2f6;

    const/4 v2, 0x3

    new-instance v1, LX/47X;

    invoke-direct {v1, v0, v2, v4}, LX/47X;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-static {v3, v1}, LX/2f6;->A01(LX/2f6;Ljava/util/concurrent/Callable;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LX/2Yj;

    goto :goto_2f

    :goto_30
    const/4 v4, 0x0

    goto :goto_31

    :cond_7f
    invoke-static {v1}, LX/33Q;->A02(Ljava/lang/String;)LX/1ZJ;

    move-result-object v4

    :goto_31
    iget-object v6, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->msgId:Ljava/lang/String;

    iget v7, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->retryCount:I

    invoke-virtual/range {v2 .. v7}, LX/30V;->A00(LX/1ZJ;LX/1ZJ;LX/2Yj;Ljava/lang/String;I)Ljava/util/concurrent/Future;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    goto :goto_32
    :try_end_31
    .catch Ljava/lang/InterruptedException; {:try_start_31 .. :try_end_31} :catch_6
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_31 .. :try_end_31} :catch_6

    :catch_6
    move-exception v2

    const-string v1, "LocationSharingManager/encryptAndSendLocation error"

    invoke-static {v1, v2}, Lcom/whatsapp/util/Log;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_32
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "sent final live location notifications"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationRetryJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :goto_33
    :try_start_32
    iget-object v2, v8, LX/1ff;->A02:LX/2p8;

    invoke-virtual {v9, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_81

    if-eqz v2, :cond_80

    iget-wide v6, v9, LX/2p8;->A05:J

    iget-wide v2, v2, LX/2p8;->A05:J

    cmp-long v1, v6, v2

    if-gez v1, :cond_80

    monitor-exit v4

    goto :goto_35

    :cond_80
    invoke-virtual {v10, v9, v8}, LX/353;->A0W(LX/2p8;LX/1ff;)V

    :cond_81
    monitor-exit v4
    :try_end_32
    .catchall {:try_start_32 .. :try_end_32} :catchall_14

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A03:LX/368;

    iget v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->timeOffset:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v2, v9, v1}, LX/368;->A02(LX/2p8;Ljava/lang/Integer;)LX/1Eb;

    move-result-object v4

    :try_start_33
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A01:LX/351;

    invoke-virtual {v1}, LX/351;->A0X()Z

    move-result v1

    if-eqz v1, :cond_82

    invoke-virtual {v0, v4}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A08(LX/1Eb;)LX/2Yj;

    move-result-object v4

    :goto_34
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->rawJid:Ljava/lang/String;

    invoke-virtual {v5, v1}, LX/33Q;->A04(Ljava/lang/String;)LX/1ZJ;

    move-result-object v2

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A05:LX/30V;

    const/4 v3, 0x0

    iget-object v5, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->msgId:Ljava/lang/String;

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v6}, LX/30V;->A00(LX/1ZJ;LX/1ZJ;LX/2Yj;Ljava/lang/String;I)Ljava/util/concurrent/Future;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    goto :goto_36

    :cond_82
    iget-object v3, v0, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A02:LX/2f6;

    const/4 v2, 0x2

    new-instance v1, LX/47X;

    invoke-direct {v1, v0, v2, v4}, LX/47X;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-static {v3, v1}, LX/2f6;->A01(LX/2f6;Ljava/util/concurrent/Callable;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LX/2Yj;

    goto :goto_34
    :try_end_33
    .catch Ljava/lang/InterruptedException; {:try_start_33 .. :try_end_33} :catch_7
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_33 .. :try_end_33} :catch_7

    :catchall_14
    :try_start_34
    move-exception v0

    monitor-exit v4
    :try_end_34
    .catchall {:try_start_34 .. :try_end_34} :catchall_14

    throw v0

    :cond_83
    :goto_35
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "skip sending final live location job, final live location notification already sent"

    goto :goto_37

    :catch_7
    move-exception v2

    const-string v1, "LocationSharingManager/encryptAndSendLocation error"

    invoke-static {v1, v2}, Lcom/whatsapp/util/Log;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_36
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "sent final live location notifications"

    :goto_37
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendFinalLiveLocationNotificationJob;->A09()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_84
    invoke-virtual {v1}, LX/2sJ;->A0H()J

    move-result-wide v2

    cmp-long v1, v4, v2

    if-gez v1, :cond_85

    return-void

    :cond_85
    invoke-static {v7}, LX/2hl;->A00(Lcom/whatsapp/jid/Jid;)LX/2hl;

    move-result-object v6

    const-string/jumbo v5, "receipt"

    iput-object v5, v6, LX/2hl;->A05:Ljava/lang/String;

    const-string v2, "engaged"

    iput-object v2, v6, LX/2hl;->A08:Ljava/lang/String;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->messageId:Ljava/lang/String;

    iput-object v1, v6, LX/2hl;->A07:Ljava/lang/String;

    iget-wide v3, v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->loggableStanzaId:J

    iput-wide v3, v6, LX/2hl;->A00:J

    invoke-virtual {v6}, LX/2hl;->A01()LX/3C4;

    move-result-object v3

    const-string/jumbo v1, "null cannot be cast to non-null type com.whatsapp.jid.UserJid"

    invoke-static {v7, v1}, LX/7nJ;->A0V(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v7, Lcom/whatsapp/jid/UserJid;

    const/16 v1, 0xf

    new-instance v4, LX/1qF;

    invoke-direct {v4, v7, v1}, LX/1qF;-><init>(Lcom/whatsapp/jid/UserJid;I)V

    invoke-static {v5}, LX/2rK;->A04(Ljava/lang/String;)LX/2rK;

    move-result-object v1

    invoke-static {v1, v4}, LX/2VU;->A05(LX/2rK;LX/2VU;)LX/381;

    move-result-object v4

    iget-object v8, v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->messageId:Ljava/lang/String;

    invoke-static {v5}, LX/2rK;->A04(Ljava/lang/String;)LX/2rK;

    move-result-object v6

    const/4 v13, 0x0

    const-wide/16 v9, 0x0

    const-wide v11, 0x1fffffffffffffL

    invoke-static/range {v8 .. v13}, LX/38V;->A0N(Ljava/lang/String;JJZ)Z

    move-result v1

    if-eqz v1, :cond_86

    const-string v1, "id"

    invoke-static {v6, v1, v8}, LX/2rK;->A0C(LX/2rK;Ljava/lang/String;Ljava/lang/String;)V

    :cond_86
    invoke-virtual {v6}, LX/2rK;->A0E()LX/381;

    move-result-object v6

    iget-object v14, v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->value:Ljava/lang/String;

    iget-object v10, v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->source:Ljava/lang/String;

    const-string v9, "biz"

    invoke-static {v9}, LX/2rK;->A04(Ljava/lang/String;)LX/2rK;

    move-result-object v8

    const-string/jumbo v7, "source"

    sget-object v1, LX/1q9;->A00:Ljava/util/ArrayList;

    invoke-virtual {v8, v10, v7, v1}, LX/2rK;->A0K(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    invoke-virtual {v8}, LX/2rK;->A0E()LX/381;

    move-result-object v8

    invoke-static {v5}, LX/2rK;->A04(Ljava/lang/String;)LX/2rK;

    move-result-object v7

    const-string/jumbo v1, "type"

    invoke-static {v7, v1, v2}, LX/2rK;->A0C(LX/2rK;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v9}, LX/2rK;->A04(Ljava/lang/String;)LX/2rK;

    move-result-object v2

    const-wide/16 v15, 0x1

    move-wide/from16 v17, v11

    move/from16 v19, v13

    invoke-static/range {v14 .. v19}, LX/38V;->A0N(Ljava/lang/String;JJZ)Z

    move-result v1

    if-eqz v1, :cond_87

    const-string/jumbo v1, "value"

    invoke-static {v2, v1, v14}, LX/2rK;->A0C(LX/2rK;Ljava/lang/String;Ljava/lang/String;)V

    :cond_87
    invoke-virtual {v2, v8}, LX/2rK;->A0H(LX/381;)V

    invoke-static {v2, v7}, LX/2rK;->A06(LX/2rK;LX/2rK;)V

    invoke-virtual {v7}, LX/2rK;->A0E()LX/381;

    move-result-object v2

    invoke-static {v5}, LX/2rK;->A04(Ljava/lang/String;)LX/2rK;

    move-result-object v1

    invoke-virtual {v1, v4}, LX/2rK;->A0H(LX/381;)V

    invoke-virtual {v1, v6}, LX/2rK;->A0H(LX/381;)V

    invoke-virtual {v1, v2}, LX/2rK;->A0H(LX/381;)V

    invoke-virtual {v1}, LX/2rK;->A0E()LX/381;

    move-result-object v2

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendEngagedReceiptJob;->A01:LX/34u;

    if-nez v1, :cond_88

    const-string/jumbo v0, "messageClient"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_88
    const/16 v0, 0x168

    invoke-virtual {v1, v2, v3, v0}, LX/34u;->A08(LX/381;LX/3C4;I)Ljava/util/concurrent/Future;

    return-void

    :cond_89
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;->A00:LX/353;

    invoke-virtual {v1, v12}, LX/353;->A0d(LX/1ZJ;)Z

    move-result v1

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    if-eqz v1, :cond_8a

    const-string/jumbo v1, "skip disable live location job; sharing is currently enabled"

    :goto_38
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_8a
    const-string/jumbo v1, "starting disable live location job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;->A01:LX/30V;

    iget-wide v3, v0, Lcom/gbwhatsapp/jobqueue/job/SendDisableLiveLocationJob;->sequenceNumber:J

    iget-object v7, v1, LX/30V;->A02:LX/34u;

    invoke-virtual {v7}, LX/34u;->A05()Ljava/lang/String;

    move-result-object v5

    invoke-static {v12}, LX/2hl;->A00(Lcom/whatsapp/jid/Jid;)LX/2hl;

    move-result-object v1

    const-string/jumbo v9, "notification"

    iput-object v9, v1, LX/2hl;->A05:Ljava/lang/String;

    const-string/jumbo v2, "location"

    iput-object v2, v1, LX/2hl;->A08:Ljava/lang/String;

    iput-object v5, v1, LX/2hl;->A07:Ljava/lang/String;

    invoke-virtual {v1}, LX/2hl;->A01()LX/3C4;

    move-result-object v6

    const/4 v1, 0x3

    new-array v8, v1, [LX/3C7;

    const-string v11, "id"

    invoke-static {v11, v5, v8}, LX/3C7;->A0H(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Z

    move-result v10

    const-string/jumbo v1, "type"

    invoke-static {v1, v2, v8}, LX/3C7;->A0I(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Z

    move-result v5

    const-string/jumbo v1, "to"

    new-instance v2, LX/3C7;

    invoke-direct {v2, v12, v1}, LX/3C7;-><init>(Lcom/whatsapp/jid/Jid;Ljava/lang/String;)V

    const/4 v1, 0x2

    aput-object v2, v8, v1

    new-array v2, v5, [LX/3C7;

    invoke-static {v3, v4}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v1

    invoke-static {v11, v1, v2, v10}, LX/3C7;->A0B(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;I)V

    const-string v1, "disable"

    invoke-static {v1, v2}, LX/381;->A0J(Ljava/lang/String;[LX/3C7;)LX/381;

    move-result-object v1

    invoke-static {v1, v9, v8}, LX/381;->A0G(LX/381;Ljava/lang/String;[LX/3C7;)LX/381;

    move-result-object v2

    const/16 v1, 0x51

    invoke-virtual {v7, v2, v6, v1}, LX/34u;->A08(LX/381;LX/3C4;I)Ljava/util/concurrent/Future;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "done disable live location job"

    goto :goto_38

    :cond_8b
    iget-object v3, v0, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A02:LX/2f6;

    const/16 v2, 0x16

    new-instance v1, LX/3hY;

    invoke-direct {v1, v0, v2, v4}, LX/3hY;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    iget-object v0, v3, LX/2f6;->A00:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/AbstractExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    return-void

    :cond_8c
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v1, "server 503 error during rotate signed pre key job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/RotateSignedPreKeyJob;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v1

    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8d
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->remoteJidRawString:Ljava/lang/String;

    invoke-static {v1}, LX/33S;->A01(Ljava/lang/String;)Lcom/whatsapp/jid/Jid;

    move-result-object v8

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->participantDeviceJidRawString:Ljava/lang/String;

    invoke-static {v1}, Lcom/whatsapp/jid/DeviceJid;->getNullable(Ljava/lang/String;)Lcom/whatsapp/jid/DeviceJid;

    move-result-object v7

    new-array v1, v6, [LX/30N;

    invoke-virtual {v5, v1}, Ljava/util/AbstractCollection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v11

    check-cast v11, [LX/30N;

    iget v12, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->status:I

    iget-wide v13, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->timestamp:J

    const/4 v10, 0x0

    const/4 v15, 0x0

    iget-object v9, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->receiptPrivacyMode:LX/3ej;

    new-instance v6, LX/3VS;

    invoke-direct/range {v6 .. v15}, LX/3VS;-><init>(Lcom/whatsapp/jid/DeviceJid;Lcom/whatsapp/jid/Jid;LX/3ej;LX/3C4;[LX/30N;IJZ)V

    iget-object v4, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptProcessingJob;->A00:LX/3VN;

    new-instance v3, LX/3iz;

    invoke-direct {v3}, LX/3iz;-><init>()V

    iget-object v2, v4, LX/3VN;->A0Q:LX/2lj;

    const/16 v0, 0x27

    new-instance v1, LX/3fj;

    invoke-direct {v1, v4, v6, v3, v0}, LX/3fj;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 v0, 0xd

    invoke-virtual {v2, v1, v0}, LX/2lj;->A02(Ljava/lang/Runnable;I)V

    invoke-virtual {v3}, LX/3iz;->get()Ljava/lang/Object;

    return-void

    :cond_8e
    iget v11, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->status:I

    const/4 v9, 0x0

    const/4 v12, 0x0

    iget-object v8, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->receiptPrivacyMode:LX/3ej;

    new-instance v5, LX/3VR;

    invoke-direct/range {v5 .. v12}, LX/3VR;-><init>(Lcom/whatsapp/jid/Jid;LX/30N;LX/3ej;LX/3C4;Ljava/util/List;IZ)V

    iget-object v4, v0, Lcom/gbwhatsapp/jobqueue/job/ReceiptMultiTargetProcessingJob;->A00:LX/3VN;

    new-instance v3, LX/3iz;

    invoke-direct {v3}, LX/3iz;-><init>()V

    iget-object v2, v4, LX/3VN;->A0Q:LX/2lj;

    const/16 v0, 0x27

    new-instance v1, LX/3fj;

    invoke-direct {v1, v4, v5, v3, v0}, LX/3fj;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 v0, 0xd

    invoke-virtual {v2, v1, v0}, LX/2lj;->A02(Ljava/lang/Runnable;I)V

    invoke-virtual {v3}, LX/3iz;->get()Ljava/lang/Object;

    return-void

    :goto_39
    :try_start_35
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "GetVNameCertificateJob/onRun, starting get vname certificate job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v2, v0, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A01:LX/2cN;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->jid:Ljava/lang/String;

    invoke-static {v1}, LX/33V;->A06(Ljava/lang/String;)Lcom/whatsapp/jid/UserJid;

    move-result-object v1

    invoke-virtual {v2, v1}, LX/2cN;->A00(Lcom/whatsapp/jid/UserJid;)Ljava/util/concurrent/Future;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "GetVNameCertificateJob/onRun, finished get vname certificate job"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A08()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, LX/0yK;->A1H(Ljava/lang/StringBuilder;Ljava/lang/String;)V
    :try_end_35
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_35} :catch_8
    .catchall {:try_start_35 .. :try_end_35} :catchall_15

    sget-object v1, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A02:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->jid:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :catchall_15
    move-exception v2

    sget-object v1, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->A02:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/GetVNameCertificateJob;->jid:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    throw v2

    :catch_8
    move-exception v0

    :try_start_36
    throw v0
    :try_end_36
    .catchall {:try_start_36 .. :try_end_36} :catchall_16

    :catchall_16
    move-exception v2

    throw v2

    :cond_8f
    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A00:LX/2sM;

    invoke-virtual {v1, v2}, LX/2sM;->A05(Lcom/whatsapp/jid/UserJid;)LX/2Ff;

    move-result-object v1

    if-eqz v1, :cond_90

    iget-wide v2, v1, LX/2Ff;->A00:J

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v12

    if-eqz v12, :cond_91

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A00:LX/2sM;

    invoke-virtual {v1}, LX/2sM;->A02()J

    move-result-wide v4

    cmp-long v1, v2, v4

    if-ltz v1, :cond_91

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A02:LX/34u;

    invoke-virtual {v1}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v14

    new-instance v10, LX/3iz;

    invoke-direct {v10}, LX/3iz;-><init>()V

    iget-object v15, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A02:LX/34u;

    const/16 v19, 0x12b

    iget-object v13, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A01:Lcom/whatsapp/jid/UserJid;

    const-string/jumbo v11, "trusted_contact"

    const-string v9, "jid"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const-string/jumbo v6, "type"

    const/4 v5, 0x1

    const/4 v4, 0x0

    new-array v1, v8, [LX/3C7;

    invoke-static {v13, v9, v1, v4}, LX/3C7;->A04(Lcom/whatsapp/jid/Jid;Ljava/lang/String;[Ljava/lang/Object;I)V

    invoke-static {v6, v11, v1, v5}, LX/3C7;->A0B(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;I)V

    const-string/jumbo v11, "t"

    new-instance v9, LX/3C7;

    invoke-direct {v9, v11, v2, v3}, LX/3C7;-><init>(Ljava/lang/String;J)V

    aput-object v9, v1, v7

    const-string/jumbo v2, "token"

    invoke-static {v2, v1}, LX/381;->A0J(Ljava/lang/String;[LX/3C7;)LX/381;

    move-result-object v3

    const-string/jumbo v2, "tokens"

    const/4 v1, 0x0

    invoke-static {v3, v2, v1}, LX/381;->A0G(LX/381;Ljava/lang/String;[LX/3C7;)LX/381;

    move-result-object v9

    invoke-static {v14, v4}, LX/3C7;->A0J(Ljava/lang/String;I)[LX/3C7;

    move-result-object v3

    invoke-static {v3, v5}, LX/3C7;->A0F([Ljava/lang/Object;I)V

    const-string/jumbo v2, "xmlns"

    const-string/jumbo v1, "privacy"

    invoke-static {v2, v1, v3, v7}, LX/3C7;->A0B(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;I)V

    const-string/jumbo v1, "set"

    invoke-static {v6, v1, v3, v8}, LX/3C7;->A0B(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;I)V

    invoke-static {v9, v3}, LX/381;->A0H(LX/381;[LX/3C7;)LX/381;

    move-result-object v17

    const/16 v2, 0x8

    new-instance v1, LX/49W;

    invoke-direct {v1, v10, v0, v12, v2}, LX/49W;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-wide/16 v20, 0x7d00

    move-object/from16 v18, v14

    move-object/from16 v16, v1

    invoke-virtual/range {v15 .. v21}, LX/34u;->A0L(LX/43r;LX/381;Ljava/lang/String;IJ)Z

    :try_start_37
    invoke-virtual {v10}, LX/3iz;->get()Ljava/lang/Object;

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A03:LX/2ot;

    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A01:Lcom/whatsapp/jid/UserJid;

    invoke-virtual {v1, v0}, LX/2ot;->A01(Lcom/whatsapp/jid/UserJid;)V

    return-void
    :try_end_37
    .catch Ljava/lang/Exception; {:try_start_37 .. :try_end_37} :catch_9

    :catch_9
    move-exception v1

    const-string v0, "GeneratePrivacyTokenJob/onRun Failed to deliver Privacy Token generate request"

    goto/16 :goto_3b

    :cond_90
    const/4 v12, 0x0

    :cond_91
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "GeneratePrivacyTokenJob/onRun Token timestamp "

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " missing or too old to send"

    invoke-static {v2, v1}, LX/0yK;->A1I(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    iget-object v1, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A03:LX/2ot;

    iget-object v0, v0, Lcom/gbwhatsapp/jobqueue/job/GeneratePrivacyTokenJob;->A01:Lcom/whatsapp/jid/UserJid;

    invoke-virtual {v1, v0}, LX/2ot;->A01(Lcom/whatsapp/jid/UserJid;)V

    return-void

    :cond_92
    instance-of v1, v0, LX/3wu;

    if-eqz v1, :cond_96

    check-cast v0, LX/3wu;

    iget v3, v0, LX/3wu;->round:I

    iget v2, v0, LX/3wu;->maxNumberOfRounds:I

    if-lt v3, v2, :cond_93

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v0, "GroupInfoBatchProcessor/FetchTruncatedGroupsJob/fetching additional\n          | group info; Giving up after "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " rounds"

    invoke-static {v0, v1}, LX/000;->A0Y(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LX/3wu;->A00(Ljava/lang/String;)Ljava/lang/String;

    return-void

    :cond_93
    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "GroupInfoBatchProcessor/FetchTruncatedGroupsJob/fetching additional\n          | group info; round="

    invoke-static {v1, v2, v3}, LX/000;->A0Z(Ljava/lang/String;Ljava/lang/StringBuilder;I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, LX/3wu;->A00(Ljava/lang/String;)Ljava/lang/String;

    new-instance v1, LX/3iz;

    invoke-direct {v1}, LX/3iz;-><init>()V

    iget-object v7, v0, LX/3wu;->A03:LX/2Gc;

    if-eqz v7, :cond_95

    iget-object v2, v0, LX/3wu;->groupsToFetch:Ljava/util/List;

    invoke-static {v2}, LX/3lK;->A0Y(Ljava/lang/Iterable;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_3a
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_94

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LX/3eg;

    iget-object v2, v3, LX/3eg;->first:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, LX/35n;->A05(Ljava/lang/String;)LX/1ZI;

    move-result-object v4

    iget-object v3, v3, LX/3eg;->second:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Integer;

    new-instance v2, LX/2zh;

    invoke-direct {v2, v4, v3}, LX/2zh;-><init>(LX/1ZI;Ljava/lang/Integer;)V

    invoke-virtual {v6, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_3a

    :cond_94
    new-instance v4, LX/3vE;

    invoke-direct {v4, v0, v1}, LX/3vE;-><init>(LX/3wu;LX/3iz;)V

    iget-object v8, v7, LX/2Gc;->A01:LX/34u;

    invoke-virtual {v8}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v11

    new-instance v3, LX/3dm;

    invoke-direct {v3, v11, v6}, LX/3dm;-><init>(Ljava/lang/String;Ljava/util/List;)V

    iget-object v2, v7, LX/2Gc;->A00:LX/2Wb;

    const/4 v7, 0x0

    new-instance v5, LX/1zA;

    invoke-direct {v5, v2, v7}, LX/1zA;-><init>(Ljava/lang/Object;I)V

    const/4 v0, 0x1

    new-instance v6, LX/1zA;

    invoke-direct {v6, v2, v0}, LX/1zA;-><init>(Ljava/lang/Object;I)V

    const/16 v12, 0x14

    const-wide/16 v13, 0x7d00

    iget-object v0, v3, LX/3dm;->A02:LX/6Cs;

    invoke-interface {v0}, LX/6Cs;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LX/2VU;

    iget-object v10, v0, LX/2VU;->A00:LX/381;

    invoke-static {v10}, LX/7nJ;->A0O(Ljava/lang/Object;)V

    new-instance v2, LX/46q;

    invoke-direct/range {v2 .. v7}, LX/46q;-><init>(LX/3y3;LX/8wI;LX/8wJ;LX/8wJ;I)V

    move-object v9, v2

    invoke-virtual/range {v8 .. v14}, LX/34u;->A0L(LX/43r;LX/381;Ljava/lang/String;IJ)Z

    invoke-virtual {v1}, LX/3iz;->get()Ljava/lang/Object;

    return-void

    :cond_95
    const-string v0, "batchGetGroupInfoProtocolHelper"

    invoke-static {v0}, LX/0yL;->A0S(Ljava/lang/String;)Ljava/lang/RuntimeException;

    move-result-object v0

    throw v0

    :cond_96
    instance-of v1, v0, LX/3wh;

    if-eqz v1, :cond_97

    check-cast v0, LX/3wh;

    iget-object v6, v0, LX/3wh;->A02:LX/34u;

    if-eqz v6, :cond_9c

    iget-object v1, v0, LX/3wh;->A01:LX/2oL;

    if-eqz v1, :cond_9c

    iget-object v0, v0, LX/3wh;->groupJidRawString:Ljava/lang/String;

    invoke-static {v0}, LX/35n;->A05(Ljava/lang/String;)LX/1ZI;

    move-result-object v5

    new-instance v4, LX/3iz;

    invoke-direct {v4}, LX/3iz;-><init>()V

    const/4 v0, 0x1

    new-instance v7, LX/49d;

    invoke-direct {v7, v1, v0, v4}, LX/49d;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v6}, LX/34u;->A04()Ljava/lang/String;

    move-result-object v9

    const-string/jumbo v0, "membership_approval_requests"

    invoke-static {v0}, LX/381;->A0I(Ljava/lang/String;)LX/381;

    move-result-object v3

    invoke-static {}, LX/0yU;->A0j()[LX/3C7;

    move-result-object v2

    const-string/jumbo v1, "xmlns"

    const-string/jumbo v0, "w:g2"

    invoke-static {v1, v0, v2}, LX/3C7;->A06(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const-string v0, "id"

    invoke-static {v0, v9, v2}, LX/3C7;->A0A(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-static {v5, v3, v2}, LX/381;->A0B(Lcom/whatsapp/jid/Jid;LX/381;[LX/3C7;)LX/381;

    move-result-object v8

    const/16 v10, 0x163

    const-wide/16 v11, 0x7d00

    invoke-virtual/range {v6 .. v12}, LX/34u;->A0L(LX/43r;LX/381;Ljava/lang/String;IJ)Z

    :try_start_38
    invoke-virtual {v4}, LX/3iz;->get()Ljava/lang/Object;

    goto :goto_3c
    :try_end_38
    .catch Ljava/lang/Exception; {:try_start_38 .. :try_end_38} :catch_a

    :catch_a
    move-exception v1

    const-string v0, "GroupFetchAllMembershipApprovalRequestsJob/onRun Failed to fetch pending requests"

    :goto_3b
    invoke-static {v0}, Lcom/whatsapp/util/Log;->e(Ljava/lang/String;)V

    throw v1

    :goto_3c
    return-void

    :cond_97
    check-cast v0, LX/3wk;

    iget-object v4, v0, LX/3wk;->A01:Lcom/gbwhatsapp/community/membersuggestedgroups/MemberSuggestedGroupsManager;

    if-nez v4, :cond_98

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "MemberSuggestedGroupsSyncJob/missing memberSuggestedGroupsManager; "

    :goto_3d
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, LX/3wk;->A08()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, LX/0yK;->A1G(Ljava/lang/StringBuilder;Ljava/lang/String;)V

    return-void

    :cond_98
    iget-object v2, v0, LX/3wk;->A00:LX/2so;

    if-eqz v2, :cond_99

    iget-object v1, v0, LX/3wk;->A03:LX/1ZI;

    invoke-virtual {v2, v1}, LX/2so;->A00(LX/1ZI;)Lcom/whatsapp/jid/GroupJid;

    move-result-object v1

    :goto_3e
    invoke-static {v1}, LX/35n;->A03(Lcom/whatsapp/jid/Jid;)LX/1ZI;

    move-result-object v3

    if-nez v3, :cond_9a

    invoke-static {}, LX/001;->A0r()Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v1, "MemberSuggestedGroupsSyncJob/missing hintJid; "

    goto :goto_3d

    :cond_99
    const/4 v1, 0x0

    goto :goto_3e

    :cond_9a
    invoke-virtual {v0}, LX/3wk;->A08()Ljava/lang/String;

    iget-object v2, v0, LX/3wk;->A03:LX/1ZI;

    iget-object v1, v0, LX/3wk;->A02:LX/2Ug;

    const/4 v0, 0x0

    if-eqz v1, :cond_9b

    invoke-virtual {v1}, LX/2Ug;->A00()Z

    move-result v0

    :cond_9b
    invoke-virtual {v4, v2, v3, v0}, Lcom/gbwhatsapp/community/membersuggestedgroups/MemberSuggestedGroupsManager;->A05(LX/1ZI;LX/1ZI;Z)V

    :cond_9c
    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch
.end method
