.class public final synthetic Lcom/google/android/gms/internal/ads/zzap;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/internal/ads/zzj;


# static fields
.field public static final synthetic zza:Lcom/google/android/gms/internal/ads/zzap;


# direct methods
.method public static synthetic constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/ads/zzap;

    invoke-direct {v0}, Lcom/google/android/gms/internal/ads/zzap;-><init>()V

    sput-object v0, Lcom/google/android/gms/internal/ads/zzap;->zza:Lcom/google/android/gms/internal/ads/zzap;

    return-void
.end method

.method private synthetic constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
