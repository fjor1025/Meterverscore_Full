.class public interface abstract Lcom/google/android/gms/internal/ads/zzafc;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract zza(ILcom/google/android/gms/internal/ads/zzafb;)Lcom/google/android/gms/internal/ads/zzafe;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end method
